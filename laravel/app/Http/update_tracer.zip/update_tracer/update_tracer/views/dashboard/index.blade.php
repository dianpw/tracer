@extends('template')
@section('konten')

<div class="m-grid__item m-grid__item--fluid m-wrapper" style="margin:10px">
<div class="m-portlet ">
							<div class="m-portlet__body  m-portlet__body--no-padding">
								<div class="row m-row--no-padding m-row--col-separator-xl">


                                        <div class="col-md-12 col-lg-6 col-xl-4">

                                            <!--begin::New Orders-->
                                            <div class="m-widget24">
                                                <div class="m-widget24__item">
                                                    <h4 class="m-widget24__title">
                                                        Mahasiswa Alumni
                                                    </h4><br>
                                                    <span class="m-widget24__desc">
                                                        Total Mahasiswa Alumni
                                                    </span>
                                                    <span class="m-widget24__stats m--font-success">
                                                       {{$total_mhs}}
                                                    </span>
                                                    <div class="m--space-10"></div>
                                                    <div class="progress m-progress--sm">
                                                        <div class="progress-bar m--bg-success" role="progressbar" style="width: 100%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                    <span class="m-widget24__change">
                                                        Preview
                                                    </span>

                                                </div>
                                            </div>

                                            <!--end::New Orders-->
                                        </div>
                                        <div class="col-md-12 col-lg-6 col-xl-4">

                                            <!--begin::New Users-->
                                            <div class="m-widget24">
                                                <div class="m-widget24__item">
                                                    <h4 class="m-widget24__title">
                                                       Sudah mengisi tracer
                                                    </h4><br>
                                                    <span class="m-widget24__desc">
                                                        Total sudah mengisi tracer
                                                    </span>
                                                    <span class="m-widget24__stats m--font-warning">
                                                        {{$total_sdh_mengisi}}
                                                    </span>
                                                    <div class="m--space-10"></div>
                                                    <div class="progress m-progress--sm">
                                                        @php
                                                            $persen_sudah_mengisi = ($total_sdh_mengisi !=0)? ($total_sdh_mengisi / $total_mhs * 100):0;

                                                        @endphp
                                                        <div class="progress-bar m--bg-warning" role="progressbar" style="width: {{$persen_sudah_mengisi.'%'}}" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                    <span class="m-widget24__change">
                                                        Persentase sudah mengisi : <b>{{round($persen_sudah_mengisi, 2).' %'}}</b>
                                                    </span>

                                                </div>
                                            </div>

                                            <!--end::New Users-->
                                        </div>
                                        <div class="col-md-12 col-lg-6 col-xl-4">

                                            <!--begin::New Users-->
                                            <div class="m-widget24">
                                                <div class="m-widget24__item">
                                                    <h4 class="m-widget24__title">
                                                        Belum mengisi tracer
                                                    </h4><br>
                                                    <span class="m-widget24__desc">
                                                        Total belum mengisi tracer
                                                    </span>
                                                    <span class="m-widget24__stats m--font-danger">
                                                        {{$belum_mengisi}}
                                                    </span>
                                                    @php
                                                        $result_belum_mengisi = 100 - $persen_sudah_mengisi;
                                                    @endphp
                                                    <div class="m--space-10"></div>
                                                    <div class="progress m-progress--sm">
                                                        <div class="progress-bar m--bg-danger" role="progressbar" style="width: {{$result_belum_mengisi.'%'}};" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                    <span class="m-widget24__change">
                                                        Persentase belum mengisi: <b>{{round($result_belum_mengisi, 2).' %'}}</b>
                                                    </span>

                                                </div>
                                            </div>

                                            <!--end::New Users-->
                                        </div>

								</div>
							</div>
</div>

<div class="m-portlet m-portlet--bordered-semi m-portlet--full-height ">
    <div class="m-portlet__head">
        <div class="m-portlet__head-caption">
            <div class="m-portlet__head-title">
                <h3 class="m-portlet__head-text">
                    Activity Tracer
                </h3>
            </div>
        </div>

    </div>
    <div class="m-portlet__body">
        <div id="graph_dashboard"></div>
    </div>
</div>

</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
<script src="https://code.highcharts.com/highcharts.src.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script>
    $(document).ready(function(){
        $.ajax({
            url: "{{url('graph-dashboard')}}",
            type: 'GET',
            dataType: 'JSON',
            success:function(response){

            Highcharts.chart('graph_dashboard', {
                chart: {
                    type: 'bar'
                },
                title: {
                    text: 'Pengisian Tracer Study'
                },
                subtitle: {
                    text: 'Source: <a href="">http://localhost/quisioner_alumni/public/</a>'
                },
                xAxis: {

                    categories: ['Sudah Mengisi',
                                'Belum Mengisi',

                                ],
                    title: {
                        text: null
                    }
                },


                yAxis: {
                    min: 0,
                    title: {
                        text: 'Total ',
                        align: 'high'
                    },
                    labels: {
                        overflow: 'justify'
                    }
                },
                tooltip: {
                    valueSuffix: ' Data'
                },
                plotOptions: {
                    bar: {
                        dataLabels: {
                            enabled: true
                        }
                    }
                },
                legend: {
                    layout: 'horizontal',
                    align: 'right',
                    verticalAlign: 'top',
                    x: -40,
                    y: 80,
                    floating: true,
                    borderWidth: 1,
                    backgroundColor:
                        Highcharts.defaultOptions.legend.backgroundColor || '#FFFFFF',
                    shadow: true
                },
                credits: {
                    enabled: false
                },

                series: [
                         {
                            name: 'Sudah Mengisi',
                            data: [response.sudah_mengisi[0],''],
                            color: '#ffb822 '
                        }, {
                            name: 'Belum Mengisi',
                            data: ['',response.belum_mengisi[0]],
                            color: '#f4516c'
                        }
                                      ]

                });
            }
        });

    });
</script>

@endsection
