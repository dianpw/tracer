@extends('template')
@section('konten')
<head>
    <link href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
</head>



<div class="m-portlet">
    <div class="m-portlet__head">
        <div class="m-portlet__head-caption">
            <div class="m-portlet__head-title">
                <h3 class="m-portlet__head-text">
                    Penekanan Metode Pembelajaran Pada Bidang Studi
                </h3>
            </div>
        </div>
    </div>
    <div class="m-portlet__body">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active show" data-toggle="tab" href="#m_tabs_1_3"><i class="flaticon-edit-1"></i>
                    Data Tracer Alumni</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#" data-target="#m_tabs_1_1"><i class="flaticon-analytics"></i>
                    Grafik</a>
            </li>



        </ul>

        <div class="tab-content">
            <div class="tab-pane" id="m_tabs_1_1" role="tabpanel">
                <div class="col-md-12">
                    <div id="chart_penekanan_metode_pembelajaran"></div>
                </div>
            </div>

            <div class="tab-pane active show" id="m_tabs_1_3" role="tabpanel">
                <div class="row">
                    <div class="col-md-9">
                        <div class="m-alert m-alert--icon m-alert--air alert alert-dismissible fade show" role="alert" style="background-color: #95a57e36">
                            <div class="m-alert__icon">
                                <i class="la 
                                la-question
                                 "></i>
                            </div>
                            <div class="m-alert__text">
                                <strong>Pertanyaan : </strong>
                                
                                Menurut Anda seberapa besar penekanan pada metode pembelajaran di bawah ini dilaksanakan di program studi Anda?
                            </div>
                           
                        </div>
                    </div>
                    <div class="col-md-3 text-right">
                        <a href="{{url('export_penekanan_metode_pembelajaran')}}" class="btn btn-success m-btn m-btn--custom m-btn--icon">
                            <span>
                                <i class="la la-file-excel-o"></i>
                                <span>Export Excell</span>
                            </span>
                        </a>
                    </div>
                </div>
               

                   
       
            <br>
                <table cellpadding="0" class="table-striped tabel_show table table-bordered nowrap" cellspacing="0" width="100%">
                    <thead style="background-image: url('https://www.transparenttextures.com/patterns/sos.png');background-color: #349d44;color: #e5f6dd;">
                        <tr>
                            <th style="5%">No.</th>
                            <th style="15%">NPM</th>
                            <th style="25%">Nama</th>
                            <th style="25%">Prodi</th>
                            <th style="15%">Tahun lulus</th>
                            <th style="15%">perkuliahan</th>
                            <th style="15%">Responsi</th>
                            <th style="15%">Seminar</th>
                            <th style="15%">praktikum</th>
                            <th style="15%">praktek lap</th>
                            <th style="15%">penelitian</th>
                            <th style="15%">pelatihan</th>
                            <th style="15%">pertukaran pelajar</th>
                            <th style="15%">magang</th>
                            <th style="15%">Wirausaha</th>
                            <th style="15%">pengabdian</th>

                            <th style="15%">Created</th>

                        </tr>
                    </thead>

                </table>
            </div>

        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
<script src ="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
<script src="https://code.highcharts.com/highcharts.src.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script>

    $(document).ready(function(){
        var table_evaluasi_pegawai = $('.tabel_show').DataTable({
            responsive:true,
            paging: true,
            info: true,
            searching: true,
            "aaSorting": [],
            "ordering": true,

            ajax: {
                url: '{{url("datatable-penekanan-metode-pembelajaran")}}',
                dataSrc: 'result',
            },
            scrollX:        true,

            autoWidth:         true,

        });

        var data = {"name":"Percentage","data":[50,28,150,125,34,75]};
        var categories = [5600, 5700,5800,5900,6000,6100];
        Highcharts.setOptions({
            chart: {
                style:{
                        fontFamily:'Arial, Helvetica, sans-serif',
                        fontSize: '1em',
                        color:'#f00'
                    }
            }
        });
        $.ajax({
            url: "{{url('graph-penekanan-metode-pembelajaran')}}",
            type: 'GET',
            dataType: 'JSON',
            success:function(response){

            Highcharts.chart('chart_penekanan_metode_pembelajaran', {
                    chart: {
                    type: 'column'
                    },
                    backgroundColor: '#000000',
                    credits: {
                            text: '',
                        },
                    title: {
                        text: 'Penekanan Metode Pembelajaran Pada Bidang Studi'
                    },

                    xAxis: {
                        type: 'category'
                    },

                    yAxis: {
                        title: {
                            text: 'Penekanan Metode Pembelajaran'
                        }
                    },
                    colors : ['#00a65a'],
                    legend: {
                        layout: 'vertical',
                        align: 'right',
                        verticalAlign: 'middle'
                    },

                    plotOptions: {
                        column :{
                            stacking : '',
                            dataLabels:{
                                enabled:false
                            }
                        }
                    },

                    series: [
                            {
                                "data": [
                                            [ 'Perkuliahan', response['perkuliahan'][0].sangatbesar],
                                            ['Responsi dan tutorial', response['Responsidantutorial'][0].sangatbesar],
                                            ['Seminar', response['Seminar'][0].sangatbesar],
                                            ['praktikum', response['praktikum'][0].sangatbesar],
                                            ['praktek lapangan', response['praktek_lapangan'][0].sangatbesar],
                                            ['penelitian', response['penelitian'][0].sangatbesar],
                                            ['pelatihan', response['pelatihan'][0].sangatbesar],
                                            ['pertukaran pelajar', response['pertukaran_pelajar'][0].sangatbesar],
                                            ['magang', response['magang'][0].sangatbesar],
                                            ['Wirausaha', response['Wirausaha'][0].sangatbesar],
                                            ['pengabdian kepada masyarakat', response['pengabdiankepadamasyarakat'][0].sangatbesar]
                                        ],
                                "name": 'Sangat Besar',
                                "color" : '#4169E1'
                            },
                            {
                                "data": [
                                            [ 'Perkuliahan', response['perkuliahan'][1].besar],
                                            ['Responsi dan tutorial',  response['Responsidantutorial'][1].besar],
                                            ['Seminar',  response['Seminar'][1].besar],
                                            ['praktikum',  response['praktikum'][1].besar],
                                            ['praktek lapangan',  response['praktek_lapangan'][1].besar],
                                            ['penelitian',  response['penelitian'][1].besar],
                                            ['pelatihan',  response['pelatihan'][1].besar],
                                            ['pertukaran pelajar', response['pertukaran_pelajar'][1].besar],
                                            ['magang', response['magang'][1].besar],
                                            ['Wirausaha', response['Wirausaha'][1].besar],
                                            ['pengabdian kepada masyarakat', response['pengabdiankepadamasyarakat'][1].besar]

                                        ],
                                "name": 'Besar',
                                "color" : '#CD5C5C'
                            },
                            {
                                "data": [
                                            [ 'Perkuliahan', response['perkuliahan'][2].cukupbesar],
                                            ['Responsi dan tutorial',  response['Responsidantutorial'][2].cukupbesar],
                                            ['Seminar',  response['Seminar'][2].cukupbesar],
                                            ['praktikum',  response['praktikum'][2].cukupbesar],
                                            ['praktek lapangan',  response['praktek_lapangan'][2].cukupbesar],
                                            ['penelitian',  response['penelitian'][2].cukupbesar],
                                            ['pelatihan',  response['pelatihan'][2].cukupbesar],
                                            ['pertukaran pelajar', response['pertukaran_pelajar'][2].cukupbesar],
                                            ['magang', response['magang'][2].cukupbesar],
                                            ['Wirausaha', response['Wirausaha'][2].cukupbesar],
                                            ['pengabdian kepada masyarakat', response['pengabdiankepadamasyarakat'][2].cukupbesar]
                                        ],
                                "name": 'Cukup Besar',
                                "color" : "#D2B48C"
                            },
                            {
                                "data": [
                                            [ 'Perkuliahan', response['perkuliahan'][3].kurang],
                                            ['Responsi dan tutorial',  response['Responsidantutorial'][3].kurang],
                                            ['Seminar',  response['Seminar'][1].kurang],
                                            ['praktikum',  response['praktikum'][3].kurang],
                                            ['praktek lapangan',  response['praktek_lapangan'][3].kurang],
                                            ['penelitian',  response['penelitian'][3].kurang],
                                            ['pelatihan',  response['pelatihan'][3].kurang],
                                            ['pertukaran pelajar', response['pertukaran_pelajar'][3].kurang],
                                            ['magang', response['magang'][3].kurang],
                                            ['Wirausaha', response['Wirausaha'][3].kurang],
                                            ['pengabdian kepada masyarakat', response['pengabdiankepadamasyarakat'][3].kurang]
                                        ],
                                "name": 'Kurang',
                                "color": '#90EE90'
                            },
                            {
                                "data": [
                                            [ 'Perkuliahan', response['perkuliahan'][4].tidak_sama_sekali],
                                            ['Responsi dan tutorial',  response['Responsidantutorial'][4].tidak_sama_sekali],
                                            ['Seminar',  response['Seminar'][4].tidak_sama_sekali],
                                            ['praktikum',  response['praktikum'][4].tidak_sama_sekali],
                                            ['praktek lapangan',  response['praktek_lapangan'][4].tidak_sama_sekali],
                                            ['penelitian',  response['penelitian'][4].tidak_sama_sekali],
                                            ['pelatihan',  response['pelatihan'][4].tidak_sama_sekali],
                                            ['pertukaran pelajar', response['pertukaran_pelajar'][4].tidak_sama_sekali],
                                            ['magang', response['magang'][4].tidak_sama_sekali],
                                            ['Wirausaha', response['Wirausaha'][4].tidak_sama_sekali],
                                            ['pengabdian kepada masyarakat', response['pengabdiankepadamasyarakat'][4].tidak_sama_sekali]
                                        ],
                                "name": 'Tidak Sama Sekali',
                                "color": '#FFE4B5'
                            }




                            ],

                    responsive: {
                        rules: [{
                            condition: {
                                maxWidth: 500
                            },

                        }]
                    }

                });
            }
        });

    });

</script>
@endsection
