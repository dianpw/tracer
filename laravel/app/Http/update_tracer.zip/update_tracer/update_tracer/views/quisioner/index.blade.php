<!DOCTYPE html>

<html lang="en">

	<!-- begin::Head -->
	<head>
        <meta charset="utf-8" />
        <title>Sistem Tracer Study - UNISMA</title>
        <link rel = "icon" href ="public/images/logounisma.png">
		<meta name="description" content="Latest updates and statistic charts">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <style>
            .isi_quisioner{
                display:none;
            }
            .m-portlet.m-portlet--creative {
                padding-top: 3.5rem;
                margin-top: 2.5rem;
            }
            .swal-footer {
                background-color: rgb(245, 248, 250);
                margin-top: 32px;
                border-top: 1px solid #E9EEF1;
                overflow: hidden;
              }
              .fade-in {
                animation: fadeIn ease 1s;
                -webkit-animation: fadeIn ease 1s;
                -moz-animation: fadeIn ease 1s;
                -o-animation: fadeIn ease 1s;
                -ms-animation: fadeIn ease 1s;
              }


              @keyframes fadeIn{
                0% {
                  opacity:0;
                }
                100% {
                  opacity:1;
                }
              }

              @-moz-keyframes fadeIn {
                0% {
                  opacity:0;
                }
                100% {
                  opacity:1;
                }
              }

              @-webkit-keyframes fadeIn {
                0% {
                  opacity:0;
                }
                100% {
                  opacity:1;
                }
              }

              @-o-keyframes fadeIn {
                0% {
                  opacity:0;
                }
                100% {
                  opacity:1;
                }
              }

              @-ms-keyframes fadeIn {
                0% {
                  opacity:0;
                }
                100% {
                  opacity:1;
                }
              }

              /* The style below is just for the appearance of the example div */

              .style {
                width:90vw; height:90vh;
                text-align:center;
                padding-top:calc(50vh - 50px);
                margin-left:5vw;
                border:4px double #F00;
                background-color:#000;
              }
              .style p {
                color:#fff;
                font-size:50px;
              }
        </style>
        <!--begin::Web font -->
		<script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
		<script>

			WebFont.load({
            google: {"families":["Poppins:300,400,500,600,700","Roboto:300,400,500,600,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
          });
        </script>
        <style>
            @import url(https://fonts.googleapis.com/css?family=Passion+One);
              .m-menu__link:hover {
                background-color: #f1f3ea;
                color: #95ec16;
              }
              .m-aside-menu.m-aside-menu--skin-dark .m-menu__nav > .m-menu__item.m-menu__item--active > .m-menu__heading .m-menu__link-text, .m-aside-menu.m-aside-menu--skin-dark .m-menu__nav > .m-menu__item.m-menu__item--active > .m-menu__link .m-menu__link-text {
                color: #1d9d19;
            }
             .m-footer{
                position: fixed;
                left: 0;
                bottom: 0;
                width: 100%;
                background-color: #e5e6e3;
                color: black;
                text-align: left;
              }
            @media only screen and (max-width: 600px) {
                #m_header_topbar{
                    margin-top: -50px;
                }
                .m-footer{
                position: fixed;
                left: 0;
                bottom: 0;
                width: 100%;
                background-color: #e5e6e3;
                color: black;
                text-align: left;
                margin-top:20px;
              }
              }
              @media only screen and (max-width: 700px) {
                #m_header_topbar{
                    margin-top: -50px;
                }
              }
              @media only screen and (max-width: 850px) {
                #m_header_topbar{
                    margin-top: -50px;
                }
              }
              @media only screen and (max-width: 930px) {
                #m_header_topbar{
                    margin-top: -50px;
                }
              }



        </style>
		<!--end::Web font -->

		<!--begin:: Global Mandatory Vendors -->
		<link href="../vendors/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" type="text/css" />

		<!--end:: Global Mandatory ../Vendors -->

		<!--begin:: Global Optional ../Vendors -->
		<link href="../public/vendors/tether/dist/css/tether.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/bootstrap-datetime-picker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/bootstrap-timepicker/css/bootstrap-timepicker.min.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/bootstrap-switch/dist/css/bootstrap3/bootstrap-switch.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/bootstrap-select/dist/css/bootstrap-select.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/select2/dist/css/select2.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/nouislider/distribute/nouislider.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/owl.carousel/dist/assets/owl.carousel.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/owl.carousel/dist/assets/owl.theme.default.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/ion-rangeslider/css/ion.rangeSlider.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/ion-rangeslider/css/ion.rangeSlider.skinFlat.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/dropzone/dist/dropzone.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/summernote/dist/summernote.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/bootstrap-markdown/css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/animate.css/animate.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/toastr/build/toastr.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/jstree/dist/themes/default/style.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/morris.js/morris.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/chartist/dist/chartist.min.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/socicon/css/socicon.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/vendors/line-awesome/css/line-awesome.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/vendors/flaticon/css/flaticon.css" rel="stylesheet" type="text/css" />
		<link href="../public/vendors/vendors/metronic/css/styles.css" rel="stylesheet" type="text/css" />
        <link href="../public/vendors/vendors/fontawesome5/css/all.min.css" rel="stylesheet" type="text/css" />
        <link href="../public/assets/vendors/custom/datatables/datatables.bundle.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="../public/assets/libs/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.12/js/select2.full.min.js" rel="stylesheet"/>
		<!--end:: Global Optional Vendors -->

		<!--begin::Global Theme Styles -->
		<link href="../public/assets/demo/base/style.bundle.css" rel="stylesheet" type="text/css" />

		<!--RTL version:<link href="../public/assets/demo/base/style.bundle.rtl.css" rel="stylesheet" type="text/css" />-->

		<!--end::Global Theme Styles -->

		<!--begin::Page Vendors Styles -->
		<link href="../public/assets/vendors/custom/fullcalendar/fullcalendar.bundle.css" rel="stylesheet" type="text/css" />

        <link href="../public/assets/vendors/custom/fullcalendar/fullcalendar.bundle.rtl.css" rel="stylesheet" type="text/css" />-->

		<!--end::Page Vendors Styles -->
		<link rel="shortcut icon" href="../public/assets/demo/media/img/logo/favicon.ico" />
	</head>

	<!-- end::Head -->

    <!-- begin::Body -->
    <!DOCTYPE html>

	<body style="background-image: ../public/images/logounisma.png" class="m-page--fluid m--skin- m-content--skin-light2 m-header--fixed m-header--fixed-mobile m-aside-left--enabled m-aside-left--skin-dark m-aside-left--fixed m-aside-left--offcanvas m-footer--push m-aside--offcanvas-default">

		<!-- begin:: Page -->
		<div class="m-grid m-grid--hor m-grid--root m-page">

			<!-- BEGIN: Header -->
			<header id="m_header" class="m-grid__item    m-header " m-minimize-offset="200" m-minimize-mobile-offset="200">
				<div class="m-container m-container--fluid m-container--full-height">
					<div class="m-stack m-stack--ver m-stack--desktop">

						<!-- BEGIN: Brand -->
						<div class="m-stack__item m-brand  m-brand--skin-dark " style="background: #3d8a49;">
							<div class="m-stack m-stack--ver m-stack--general">
								<div class="m-stack__item m-stack__item--middle m-brand__logo" style="width: 185px">

                                    <H4 style="padding-top:8px;padding-right:10px;font-size:17px;color: whitesmoke">
                                        <img src="../public/images/logounisma.png" style="width: 47px">&nbsp&nbsp
                                        <a style="font-size: 23px;color:#f0f0e9;font-family: 'Passion One';">Tracer Study</a></H4>

								</div>
								<div class="m-stack__item m-stack__item--middle m-brand__tools" >

									<!-- BEGIN: Left Aside Minimize Toggle -->


									<!-- END -->

									<!-- BEGIN: Responsive Aside Left Menu Toggler -->


									<!-- END -->

									<!-- BEGIN: Responsive Header Menu Toggler -->


									<!-- END -->

									<!-- BEGIN: Topbar Toggler -->
									@php
								   $str_nama = explode(" ", $data_mhs->nama);
								   $str= $str_nama[0];
									@endphp
									<a id="click_alumni2" style="color: white" id="m_aside_header_topbar_mobile_toggle" href="javascript:;" class="m-brand__icon m--visible-tablet-and-mobile-inline-block">


										<div style="margin-bottom:11px;"><b><i class="la la-user"></i> </b> Alumni,</div><br><br><br>
										<b >
										{{$str}}</b>
									</a>

									<!-- BEGIN: Topbar Toggler -->
								</div>
							</div>
						</div>

						<!-- END: Brand -->
						<div class="m-stack__item m-stack__item--fluid m-header-head" style="background-color: #3d8a49" id="m_header_nav">

							<!-- BEGIN: Horizontal Menu -->
							<button class="m-aside-header-menu-mobile-close  m-aside-header-menu-mobile-close--skin-dark " id="m_aside_header_menu_mobile_close_btn"><i class="la la-close"></i></button>
							<div id="m_header_menu" class="m-header-menu m-aside-header-menu-mobile m-aside-header-menu-mobile--offcanvas  m-header-menu--skin-light m-header-menu--submenu-skin-light m-aside-header-menu-mobile--skin-dark m-aside-header-menu-mobile--submenu-skin-dark ">
								<ul class="m-menu__nav  m-menu__nav--submenu-arrow ">

								</ul>
							</div>

							<!-- END: Horizontal Menu -->

							<!-- BEGIN: Topbar -->
							<div id="m_header_topbar" class="m-topbar  m-stack m-stack--ver m-stack--general m-stack--fluid" >
								<div class="m-stack__item m-topbar__nav-wrapper" style="margin-top:-150px">
                                <a id="click_alumni" href="javascript:;">
                                  <b style="color:whitesmoke"><i class="la la-user"></i> Alumni, {{$data_mhs->npm .' | '.$data_mhs->nama}}</b> <b style="color: gray"></b>
                                </a>
                                  <ul class="m-topbar__nav m-nav m-nav--inline">

										<li class="m-nav__item m-topbar__user-profile m-topbar__user-profile--img  m-dropdown m-dropdown--medium m-dropdown--arrow m-dropdown--header-bg-fill m-dropdown--align-right m-dropdown--mobile-full-width m-dropdown--skin-light"
										 m-dropdown-toggle="click">


										</li>

									</ul>
								</div>
							</div>

							<!-- END: Topbar -->
						</div>
					</div>
				</div>
			</header>

			<!-- END: Header -->

			<!-- begin::Body -->
			<div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body" style="padding-left:0px">

				<!-- BEGIN: Left Aside -->
				<button class="m-aside-left-close  m-aside-left-close--skin-dark " id="m_aside_left_close_btn"><i class="la la-close"></i></button>


				<!-- END: Left Aside -->
				<div class="m-grid__item m-grid__item--fluid m-wrapper" >
					<div class="m-content" style="margin-top: -40px; margin-bottom:-15px">
                        <div class="isi_biodata">
                            <form id="survey-form" method="POST" action="{{url('submit-tracer')}}">

                            @csrf
                            <input type="hidden" value="{{$data_mhs->npm}}" name="npm">
                            <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-bottom: 2rem;">
                                <div class="m-portlet__head">
                                    <div class="m-portlet__head-caption">
                                        <div class="m-portlet__head-title">
                                            <span class="m-portlet__head-icon m--hide">
                                                <i class="flaticon-statistics"></i>
                                            </span>
                                            <h3 class="m-portlet__head-text">
                                                Lengkapi Data dibawah ini !
                                            </h3>
                                            <h2 class="m-portlet__head-label m-portlet__head-label--success">
                                                <span>Isi Data berikut</span>
                                            </h2>
                                        </div>
                                    </div>
                                    <div class="m-portlet__head-tools">

                                    </div>
                                </div>
                                <div class="m-portlet__body">

                                    <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                        <div class="m-portlet__body">
                                            <div class="form-group m-form__group row">
                                                <div class="col-lg-6">
                                                    <label>* Alamat Email</label>
                                                    <input type="email"  name="email" required placeholder="Jawaban Anda"  class="form-control m-input">
                                                    <span class="m-form__help">&nbsp</span>
                                                </div>
                                                <div class="col-lg-6">
                                                    <label class="">* No HP (Whatsapp)</label>
                                                    <input type="text" onkeypress="return isNumberKey(event)" class="form-control m-input" name="no_whatsapp" required placeholder="Jawaban Anda">

                                                </div>
                                            </div>
                                            <div class="form-group m-form__group row" style="margin-top: -10px">
                                                <div class="col-lg-6">
                                                    <label>* Alamat lengkap:</label>
                                                    <div class="m-input-icon m-input-icon--right">
                                                        <input type="text" class="form-control m-input" name="alamat" required placeholder="Jawaban Anda">
                                                        <span class="m-input-icon__icon m-input-icon__icon--right"><span><i class="la la-map-marker"></i></span></span>
                                                    </div>
                                                    <span class="m-form__help">&nbsp</span>
                                                </div>
                                                <div class="col-lg-6">
                                                    <label>*Jenis Kelamin:</label>
                                                    <div class="m-radio-inline">
                                                        <label class="m-radio m-radio--solid">
                                                            <input type="radio" name="jeniskelamin" id="jeniskelamin"  value="L"> Laki - laki
                                                            <span></span>
                                                        </label>
                                                        <label class="m-radio m-radio--solid">
                                                            <input type="radio" name="jeniskelamin" id="jeniskelamin" value="P"> Perempuan
                                                            <span></span>
                                                        </label>
                                                    </div>
                                                    <span class="m-form__help">&nbsp</span>
                                                </div>
                                            </div>

                                        </div>






                                    </div>


                                </div>



                                <div class="m-portlet__foot m-portlet__foot--fit">
									  <div class="m-form__actions m-form__actions">
												<div class="row">

													<div class="col-lg-12 m--align-right">

														<button style="margin:12px" id="m_blockui_2_5" type="button" class="btn btn-success berikutnya">Berikutnya</button>
													</div>
												</div>
											</div>
										</div>

                            </div>
                        </div>


                        <div class="isi_quisioner fade-in">

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-bottom: 1.2rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                                <h3 class="m-portlet__head-text">

                                                </h3>
                                                <h2 class="m-portlet__head-label m-portlet__head-label--success" style="width:140px">
                                                    <span>Data Tracer</span>
                                                </h2>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px;">
                                            <div class="m-portlet__body">
                                                <b>Menurut Anda seberapa besar penekanan pada metode pembelajaran di bawah ini dilaksanakan di program studi Anda?</b>
                                                <div class="form-group m-form__group row">
                                                    <div class="col-lg-12" style="margin-left:0px">
                                                        <div class="table-responsive">
                                                        <table class="table table-striped m-table" style="display: block; min-height: 300px; overflow-x: auto;border:1;">
                                                            <thead class="m-datatable__head">
                                                            <tr>
                                                                <th></th>
                                                                <th>Sangat Besar</th>
                                                                <th>Besar</th>
                                                                <th>Cukup</th>
                                                                <th>Kecil</th>
                                                                <th>Sangat Kecil</th>
                                                            </tr>
                                                            </thead>

                                                            <tbody>
                                                            <tr>
                                                                <td>Kuliah</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kuliah1">
                                                                            <input type="radio" required name="kuliah" id="kuliah1" value="sangat besar">

                                                                        <span></span></
                                                                    label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kuliah2">
                                                                            <input type="radio" required name="kuliah" id="kuliah2" value="besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kuliah3">
                                                                            <input type="radio" required name="kuliah" id="kuliah3" value="cukup besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kuliah4">
                                                                            <input type="radio" required name="kuliah" id="kuliah4" value="kurang">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kuliah5">
                                                                            <input type="radio" required name="kuliah" id="kuliah5" value="tidak sama sekali">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Responsi dan tutorial</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="responsi1">
                                                                            <input type="radio" required name="responsi" id="responsi1" value="sangat besar">

                                                                        <span></span></
                                                                    label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="responsi2">
                                                                            <input type="radio" required name="responsi" id="responsi2" value="besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="responsi3">
                                                                            <input type="radio" required name="responsi" id="responsi3" value="cukup besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="responsi4">
                                                                            <input type="radio" required name="responsi" id="responsi4" value="kurang">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="responsi5">
                                                                            <input type="radio" required name="responsi" id="responsi5" value="tidak sama sekali">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Seminar</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="seminar1">
                                                                            <input type="radio" required name="seminar" id="seminar1" value="sangat besar">

                                                                        <span></span></
                                                                    label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="seminar2">
                                                                            <input type="radio" required name="seminar" id="seminar2" value="besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="seminar3">
                                                                            <input type="radio" required name="seminar" id="seminar3" value="cukup besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="seminar4">
                                                                            <input type="radio" required name="seminar" id="seminar4" value="kurang">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="seminar5">
                                                                            <input type="radio" required name="seminar" id="seminar5" value="tidak sama sekali">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Praktikum, praktik studio, praktik bengkel</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="praktikum_praktik1">
                                                                            <input type="radio" required name="praktikum_praktik" id="praktikum_praktik1" value="sangat besar">

                                                                        <span></span></
                                                                    label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="praktikum_praktik2">
                                                                            <input type="radio" required name="praktikum_praktik" id="praktikum_praktik2" value="besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="praktikum_praktik3">
                                                                            <input type="radio" required name="praktikum_praktik" id="praktikum_praktik3" value="cukup besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="praktikum_praktik4">
                                                                            <input type="radio" required name="praktikum_praktik" id="praktikum_praktik4" value="kurang">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="praktikum_praktik5">
                                                                            <input type="radio" required name="praktikum_praktik" id="praktikum_praktik5" value="tidak sama sekali">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Praktek lapangan, praktik kerja</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="praktek_lapangan1">
                                                                            <input type="radio" required name="praktek_lapangan" id="praktek_lapangan1" value="sangat besar">

                                                                        <span></span></
                                                                    label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="praktek_lapangan2">
                                                                            <input type="radio" required name="praktek_lapangan" id="praktek_lapangan2" value="besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="praktek_lapangan3">
                                                                            <input type="radio" required name="praktek_lapangan" id="praktek_lapangan3" value="cukup besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="praktek_lapangan4">
                                                                            <input type="radio" required name="praktek_lapangan" id="praktek_lapangan4" value="kurang">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="praktek_lapangan5">
                                                                            <input type="radio" required name="praktek_lapangan" id="praktek_lapangan5" value="tidak sama sekali">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Penelitian, perancangan, atau pengembangan</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="penelitian1">
                                                                            <input type="radio" required name="penelitian" id="penelitian1" value="sangat besar">

                                                                        <span></span></
                                                                    label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="penelitian2">
                                                                            <input type="radio" required name="penelitian" id="penelitian2" value="besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="penelitian3">
                                                                            <input type="radio" required name="penelitian" id="penelitian3" value="cukup besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="penelitian4">
                                                                            <input type="radio" required name="penelitian" id="penelitian4" value="kurang">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="penelitian5">
                                                                            <input type="radio" required name="penelitian" id="penelitian5" value="tidak sama sekali">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Pelatihan militer</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pelatihan_militer1">
                                                                            <input type="radio" required name="pelatihan_militer" id="pelatihan_militer1" value="sangat besar">

                                                                        <span></span></
                                                                    label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pelatihan_militer2">
                                                                            <input type="radio" required name="pelatihan_militer" id="pelatihan_militer2" value="besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pelatihan_militer3">
                                                                            <input type="radio" required name="pelatihan_militer" id="pelatihan_militer3" value="cukup besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pelatihan_militer4">
                                                                            <input type="radio" required name="pelatihan_militer" id="pelatihan_militer4" value="kurang">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pelatihan_militer5">
                                                                            <input type="radio" required name="pelatihan_militer" id="pelatihan_militer5" value="tidak sama sekali">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Pertukaran Pelajar</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pertukaran_pelajar1">
                                                                            <input type="radio" required name="pertukaran_pelajar" id="pertukaran_pelajar1" value="sangat besar">

                                                                        <span></span></
                                                                    label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pertukaran_pelajar2">
                                                                            <input type="radio" required name="pertukaran_pelajar" id="pertukaran_pelajar2" value="besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pertukaran_pelajar3">
                                                                            <input type="radio" required name="pertukaran_pelajar" id="pertukaran_pelajar3" value="cukup besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pertukaran_pelajar4">
                                                                            <input type="radio" required name="pertukaran_pelajar" id="pertukaran_pelajar4" value="kurang">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pertukaran_pelajar5">
                                                                            <input type="radio" required name="pertukaran_pelajar" id="pertukaran_pelajar5" value="tidak sama sekali">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Magang</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="magang1">
                                                                            <input type="radio" required name="magang" id="magang1" value="sangat besar">

                                                                        <span></span></
                                                                    label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="magang2">
                                                                            <input type="radio" required name="magang" id="magang2" value="besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="magang3">
                                                                            <input type="radio" required name="magang" id="magang3" value="cukup besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="magang4">
                                                                            <input type="radio" required name="magang" id="magang4" value="kurang">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="magang5">
                                                                            <input type="radio" required name="magang" id="magang5" value="tidak sama sekali">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>Wirausaha</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="wirausaha1">
                                                                            <input type="radio" required name="wirausaha" id="wirausaha1" value="sangat besar">

                                                                        <span></span></
                                                                    label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="wirausaha2">
                                                                            <input type="radio" required name="wirausaha" id="wirausaha2" value="besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="wirausaha3">
                                                                            <input type="radio" required name="wirausaha" id="wirausaha3" value="cukup besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="wirausaha4">
                                                                            <input type="radio" required name="wirausaha" id="wirausaha4" value="kurang">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="wirausaha5">
                                                                            <input type="radio" required name="wirausaha" id="wirausaha5" value="tidak sama sekali">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Bentuk lain pengabdian kepada masyarakat</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengabdian1">
                                                                            <input type="radio" required name="pengabdian" id="pengabdian1" value="sangat besar">

                                                                        <span></span></
                                                                    label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengabdian2">
                                                                            <input type="radio" required name="pengabdian" id="pengabdian2" value="besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengabdian3">
                                                                            <input type="radio" required name="pengabdian" id="pengabdian3" value="cukup besar">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengabdian4">
                                                                            <input type="radio" required name="pengabdian" id="pengabdian4" value="kurang">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengabdian5">
                                                                            <input type="radio" required name="pengabdian" id="pengabdian5" value="tidak sama sekali">

                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                        <br>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_penekanan_pada_metode_pembelajaran" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>


                                            </div>


                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F3. Kapan anda mulai mencari pekerjaan? Mohon pekerjaan sambilan tidak dimasukkan ?  </b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">

                                                        <table>
                                                            <tr >
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pertanyaan22">
                                                                            <input type="radio" required name="pertanyaan_f3" id="pertanyaan22" value="sebelum">
                                                                            Sebelum Lulus,

                                                                            &nbsp
                                                                        <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                    <input class="form-control" placeholder="Jawaban Anda" type="text" disabled name="pertanyaanf3_input_sebelum" id="pertanyaanf61">

                                                                    </div>
                                                                </td>
                                                                <td>   &nbspbulan sebelum lulus    </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pertanyaan90">
                                                                            <input type="radio" name="pertanyaan_f3" id="pertanyaan90" value="setelah">
                                                                            Setelah Lulus,

                                                                            &nbsp
                                                                        <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                    <input class="form-control" placeholder="Jawaban Anda" type="text" disabled name="pertanyaanf3_input_setelah" id="pertanyaanf61">

                                                                    </div>
                                                                </td>
                                                                <td>   &nbspbulan setelah lulus    </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pertanyaan222">
                                                                            <input type="radio" name="pertanyaan_f3" id="pertanyaan222" value="tidak mencari kerja">
                                                                            Saya tidak mencari kerja <i>(Langsung Ke Bagian Pekerjaan)</i>
                                                                        <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_mulai_mencari_pekerjaan" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-bottom: 1.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                                <h3 class="m-portlet__head-text">
                                                    Lewati Section Ini Jika Anda Tidak Mencari Kerja
                                                </h3>
                                                <h2 class="m-portlet__head-label m-portlet__head-label--success">
                                                    <span>Mencari Kerja</span>
                                                </h2>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body">


                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F4. Bagaimana anda mencari pekerjaan tersebut? <i>Jawaban bisa lebih dari satu</i></b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf41">
                                                                <input type="checkbox" name="pertanyaanf4_iklan" id="pertanyaanf41" value="1">
                                                                Melalui iklan di koran/majalah, brosur
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf42">
                                                                <input type="checkbox" name="pertanyaanf4_melamar" id="pertanyaanf42" value="1">
                                                                Melamar ke perusahaan tanpa mengetahui lowongan yang ada
                                                            <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf43">
                                                                <input type="checkbox" name="pertanyaanf4_pergi" id="pertanyaanf43" value="1">
                                                                Pergi ke bursa/pameran kerja
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf44">
                                                                <input type="checkbox" name="pertanyaanf4_mencari" id="pertanyaanf44" value="1">
                                                                Mencari lewat internet/iklan online/milis
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf45">
                                                                <input type="checkbox" name="pertanyaanf4_dihubungi" id="pertanyaanf45" value="1">
                                                                Dihubungi oleh perusahaan
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf46">
                                                                <input type="checkbox" name="pertanyaanf4_menghubungi_kemenakertrans" id="pertanyaanf46" value="1">
                                                                Menghubungi Kemenakertrans
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf47">
                                                                <input type="checkbox" name="pertanyaanf4_memeroleh" id="pertanyaanf47" value="1">
                                                                Memeroleh informasi dari pusat/kantor pengembangan karir fakultas/universitas
                                                            <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf48">
                                                                <input type="checkbox" name="pertanyaanf4_menghubungi_kantor" id="pertanyaanf48" value="1">
                                                                Menghubungi kantor kemahasiswaan/hubungan alumni
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf49">
                                                                <input type="checkbox" name="pertanyaanf4_membangun_jejaring" id="pertanyaanf49" value="1">
                                                                Membangun jejaring (network) sejak masih kuliah
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf410">
                                                                <input type="checkbox" name="pertanyaanf4_melalui" id="pertanyaanf410" value="1">
                                                                Melalui relasi (misalnya dosen, orang tua, saudara, teman, dll.)
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf411">
                                                                <input type="checkbox" name="pertanyaanf4_membangun_bisnis" id="pertanyaanf411" value="1">
                                                                Membangun bisnis sendiri
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf412">
                                                                <input type="checkbox" name="pertanyaanf4_melalui_magang" id="pertanyaanf412" value="1">
                                                                Melalui penempatan kerja atau magang
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf413">
                                                                <input type="checkbox" name="pertanyaanf4_bekerja_tempat_sama" id="pertanyaanf413" value="1">
                                                                Bekerja di tempat yang sama dengan tempat kerja semasa kuliah
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf414">
                                                                <input type="checkbox" name="pertanyaanf4_lainnya" id="pertanyaanf414" value="1">
                                                                Lainnya
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_mencari_pekerjaan" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F5. Berapa bulan waktu yang dihabiskan (sebelum dan sesudah kelulusan) untuk memeroleh pekerjaan pertama?  </b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <table >
                                                            <tr >
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf51">
                                                                            <input type="radio" required name="pertanyaan2_f5" id="pertanyaanf51" value="sebelum">
                                                                           Kira-kira
                                                                            <span></span>
                                                                            &nbsp
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                    <input class="form-control" placeholder="Jawaban Anda" disabled type="text" name="pertanyaanf5input" id="pertanyaanf5input1">

                                                                    </div>
                                                                </td>
                                                                <td>   bulan sebelum lulus ujian  </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf52">
                                                                            <input type="radio" name="pertanyaan2_f5" id="pertanyaanf52" value="setelah">
                                                                           Kira-kira
                                                                            <span></span>
                                                                            &nbsp
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                    <input class="form-control" placeholder="Jawaban Anda" disabled type="text" name="pertanyaanf5input2" id="pertanyaanf5input2">

                                                                    </div>
                                                                </td>
                                                                <td>   bulan sesudah lulus ujian   </td>
                                                            </tr>

                                                        </table>
                                                          <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_bulan_untuk_mencari_pekerjaan" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F6. Berapa perusahaan/instansi/institusi yang sudah anda lamar (lewat surat atau e-mail) sebelum anda memeroleh pekerjaan pertama?  </b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="form-check">
                                                            <input class="form-control" required placeholder="Jawaban Anda" type="text" name="pertanyaanf6" id="pertanyaanf61">
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_perusahaan_yang_sudah_anda_lamar_lewat_email" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                                </div>
                                            </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F7. Berapa banyak perusahaan/instansi/institusi yang merespons lamaran anda? </b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="form-check">
                                                            <input class="form-control" required placeholder="Jawaban Anda" type="text" name="pertanyaanf7" id="pertanyaanf61">
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_perusahaan_merespon" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F7a. Berapa banyak perusahaan/instansi/institusi yang mengundang anda untuk wawancara? </b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="form-check">
                                                            <input class="form-control" required placeholder="Jawaban Anda" type="text" name="pertanyaanf7a" id="pertanyaanf71">
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_perusahaan_yang_mengundang_anda" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Apa nama perusahaan tempat anda bekerja saat ini?</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="input-group mb-6">

                                                            <input type="text" placeholder="Jawaban Anda" name="nama_perusahaan" class="form-control" aria-label="Amount (to the nearest dollar)">

                                                          </div>
                                                          <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_perusahaan_tempat_bekerja" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Dimana alamat perusahaan tempat anda bekerja saat ini?</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="input-group mb-6">

                                                            <input type="text" placeholder="Jawaban Anda" name="alamat_tempat_bekerja" class="form-control" aria-label="Amount (to the nearest dollar)">

                                                          </div>
                                                          <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_alamat_tempat_bekerja" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>No. Telpon Perusahaan </b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="input-group mb-6">

                                                            <input type="text" placeholder="Jawaban Anda" name="no_telp_perusahaan" class="form-control" aria-label="Amount (to the nearest dollar)">

                                                          </div>
                                                          <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_no_telp_perusahaan" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 2.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>

                                                <h2 class="m-portlet__head-label m-portlet__head-label--success">
                                                    <span>Pekerjaan</span>
                                                </h2>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F8. Apakah anda bekerja saat ini (termasuk kerja sambilan dan wirausaha)? </b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf81">
                                                                <input type="radio" required name="pertanyaanf8" id="pertanyaanf81" value="2">
                                                                YA <i>(Jika Ya, lanjutkan ke f11)</i>
                                                                <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf82">
                                                                <input type="radio" name="pertanyaanf8" id="pertanyaanf82" value="1">
                                                                TIDAK
                                                                <span></span>
                                                            </label>
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_anda_bekerja_saat_ini" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 2.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                                <h3 class="m-portlet__head-text">
                                                    Lewati Bagian Ini jika Anda Sudah Bekerja
                                                </h3>
                                                <h2 class="m-portlet__head-label m-portlet__head-label--success">
                                                    <span>Belum Bekerja</span>
                                                </h2>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -35px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">


                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 2.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>


                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -35px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F9. Bagaimana anda menggambarkan situasi anda saat ini? Jawaban bisa lebih dari satu</b>
                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf91">
                                                                <input type="checkbox" name="pertanyaanf9_belajar" id="pertanyaanf91" value="1">
                                                                Saya masih belajar/melanjutkan kuliah profesi atau pascasarjana
                                                                <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf92">
                                                                <input type="checkbox" name="pertanyaanf9_menikah" id="pertanyaanf92" value="1">
                                                                Saya Menikah
                                                                <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf93">
                                                                <input type="checkbox" name="pertanyaanf9_sibuk_keluarga" id="pertanyaanf93" value="1">
                                                                Saya sibuk dengan keluarga dan anak-anak
                                                                <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf94">
                                                                <input type="checkbox" name="pertanyaanf9_sedang_mencari_pekerjaan" id="pertanyaanf94" value="1">
                                                                Saya sekarang sedang mencari pekerjaan
                                                                <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf95">
                                                                <input type="checkbox" name="pertanyaanf9_lainnya" id="pertanyaanf95" value="1">
                                                                Lainnya
                                                                <span></span>
                                                            </label>
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_menggambarkan_situasi_anda" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 2.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>


                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -35px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F10. Apakah anda aktif mencari pekerjaan dalam 4 minggu terakhir? Pilihlah Satu Jawaban.</b>
                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf10">
                                                                <input type="radio" name="pertanyaanf10" id="pertanyaanf10" value="1">
                                                               Tidak
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf101">
                                                                <input type="radio" name="pertanyaanf10" id="pertanyaanf101" value="2">
                                                                Tidak, tapi saya sedang menunggu hasil lamaran kerja
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf102">
                                                                <input type="radio" name="pertanyaanf10" id="pertanyaanf102" value="3">
                                                                Ya, saya akan mulai bekerja dalam 2 minggu ke depan
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf103">
                                                                <input type="radio" name="pertanyaanf10" id="pertanyaanf103" value="4">
                                                                Ya, tapi saya belum pasti akan bekerja dalam 2 minggu ke depan
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf104">
                                                                <input type="radio" name="pertanyaanf10" id="pertanyaanf104" value="5">
                                                                Lainnya
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_pekerjaan_dalam_4minggu" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 2.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                                <h3 class="m-portlet__head-text">
                                                    Lewati bagian ini jika Anda belum bekerja
                                                </h3>
                                                <h2 class="m-portlet__head-label m-portlet__head-label--success" style="width: 310px;">
                                                    <span>Data Alumni Yang Sudah Bekerja</span>
                                                </h2>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -35px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">


                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Nama Atasan Langsung Anda (Jika Sudah Bekerja)</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="input-group mb-6">

                                                            <input type="text" placeholder="Jawaban Anda" name="nama_atasan_langsung" class="form-control" aria-label="Amount (to the nearest dollar)">

                                                          </div>
                                                          <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_nama_atasan_langsung" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Nomor HP Atasan Langsung Anda (Jika Sudah Bekerja)</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="input-group mb-6">

                                                            <input type="text" placeholder="Jawaban Anda" name="no_hp_atasan" class="form-control" aria-label="Amount (to the nearest dollar)">

                                                          </div>
                                                          <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_nohp_atasan_langsung" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F11. Apa jenis perusahaan/instansi/institusi tempat anda bekerja sekarang?</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="table-responsive">
                                                        <table class="table table-striped m-table" style="display: block; min-height: 300px; overflow-x: auto;border:1;">
                                                            <thead>
                                                            <tr>
                                                                <th></th>
                                                                <th>Berijin</th>
                                                                <th>Tidak Berijin</th>
                                                                <th>Lokal</th>
                                                                <th>Nasional</th>
                                                                <th>Internasional</th>
                                                            </tr>
                                                            </thead>

                                                            <tbody>
                                                                <div class="checkbox-group required">
                                                                <tr>
                                                                    <td>  Wirausaha Ijin/tidak berijin</td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="wiraswastaijintidakberijinberijin">
                                                                                <input class="form-check-input" type="checkbox" name="wiraswastaijintidakberijin[]" id="wiraswastaijintidakberijinberijin" value="berijin">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="wiraswastaijintidakberijintidakberijin">
                                                                                <input class="form-check-input" type="checkbox" name="wiraswastaijintidakberijin[]" id="wiraswastaijintidakberijintidakberijin" value="tidakberijin">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="wiraswastaijintidakberijinlokal">
                                                                                <input class="form-check-input" type="checkbox" name="wiraswastaijintidakberijin[]" id="wiraswastaijintidakberijinlokal" value="lokal">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="wiraswastaijintidakberijinnasional">
                                                                                <input class="form-check-input" type="checkbox" name="wiraswastaijintidakberijin[]" id="wiraswastaijintidakberijinnasional" value="nasional">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="wiraswastaijintidakberijininternasional">
                                                                                <input class="form-check-input" type="checkbox" name="wiraswastaijintidakberijin[]" id="wiraswastaijintidakberijininternasional" value="internasional">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                </tr>

                                                                <tr>
                                                                    <td>  Wirausaha Lokal/Nasional/Internasional</td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="wiraswastalokal/nasionalberijin">
                                                                                <input class="form-check-input" type="checkbox" name="wiraswastalokal_nasional[]" id="wiraswastalokal/nasionalberijin" value="berijin">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="wiraswastalokal/nasionaltidakberijin">
                                                                                <input class="form-check-input" type="checkbox" name="wiraswastalokal_nasional[]" id="wiraswastalokal/nasionaltidakberijin" value="tidakberijin">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="wiraswastalokal/nasionallokal">
                                                                                <input class="form-check-input" type="checkbox" name="wiraswastalokal_nasional[]" id="wiraswastalokal/nasionallokal" value="lokal">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="wiraswastalokal/nasionalnasional">
                                                                                <input class="form-check-input" type="checkbox" name="wiraswastalokal_nasional[]" id="wiraswastalokal/nasionalnasional" value="nasional">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="wiraswastainternasional">
                                                                                <input class="form-check-input" type="checkbox" name="wiraswastalokal_nasional[]" id="wiraswastainternasional" value="internasional">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                </tr>

                                                                <tr>
                                                                    <td> Perusahaan swasta Ijin/tidak berijin</td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="perusahaanswastaberijin">
                                                                                <input class="form-check-input" type="checkbox" name="perusahaanswasta[]" id="perusahaanswastaberijin" value="berijin">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="perusahaanswastatidakberijin">
                                                                                <input class="form-check-input" type="checkbox" name="perusahaanswasta[]" id="perusahaanswastatidakberijin" value="tidakberijin">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="perusahaanswastalokal">
                                                                                <input class="form-check-input" type="checkbox" name="perusahaanswasta[]" id="perusahaanswastalokal" value="lokal">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="perusahaanswastanasional">
                                                                                <input class="form-check-input" type="checkbox" name="perusahaanswasta[]" id="perusahaanswastanasional" value="nasional">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="perusahaanswastainternasional">
                                                                                <input class="form-check-input" type="checkbox" name="perusahaanswasta[]" id="perusahaanswastainternasional" value="internasional">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                </tr>

                                                                <tr>
                                                                    <td> Perusahaan Lokal/Nasional/Internasional</td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="perusahaanlokalnasional_berijin">
                                                                                <input class="form-check-input" type="checkbox" name="perusahaanlokalnasional[]" id="perusahaanlokalnasional_berijin" value="berijin">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="perusahaanlokalnasional_tidakberijin">
                                                                                <input class="form-check-input" type="checkbox" name="perusahaanlokalnasional[]" id="perusahaanlokalnasional_tidakberijin" value="tidakberijin">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="perusahaanlokalnasional_lokal">
                                                                                <input class="form-check-input" type="checkbox" name="perusahaanlokalnasional[]" id="perusahaanlokalnasional_lokal" value="lokal">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="perusahaanlokalnasional_nasional">
                                                                                <input class="form-check-input" type="checkbox" name="perusahaanlokalnasional[]" id="perusahaanlokalnasional_nasional" value="nasional">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check">
                                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="perusahaanlokalnasional_internasional">
                                                                                <input class="form-check-input" type="checkbox" name="perusahaanlokalnasional[]" id="perusahaanlokalnasional_internasional" value="internasional">
                                                                                <span></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                </tr>


                                                            <tr>
                                                                <td> Instansi pemerintah (termasuk BUMN)</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="bumnberijin">
                                                                            <input class="form-check-input" type="checkbox" name="bumn[]" id="bumnberijin" value="berijin">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="bumntidakberijin">
                                                                            <input class="form-check-input" type="checkbox" name="bumn[]" id="bumntidakberijin" value="tidakberijin">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="bumnlokal">
                                                                            <input class="form-check-input" type="checkbox" name="bumn[]" id="bumnlokal" value="lokal">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="bumnnasional">
                                                                            <input class="form-check-input" type="checkbox" name="bumn[]" id="bumnnasional" value="nasional">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="bumninternasional">
                                                                            <input class="form-check-input" type="checkbox" name="bumn[]" id="bumninternasional" value="internasional">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td> Organisasi non-profit/Lembaga Swadaya Masyarakat</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="organisasiberijin">
                                                                            <input class="form-check-input" type="checkbox" name="organisasi_non_profit[]" id="organisasiberijin" value="berijin">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="organisasitidakberijin">
                                                                            <input class="form-check-input" type="checkbox" name="organisasi_non_profit[]" id="organisasitidakberijin" value="tidakberijin">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="organisasilokal">
                                                                            <input class="form-check-input" type="checkbox" name="organisasi_non_profit[]" id="organisasilokal" value="lokal">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="organisasinasional">
                                                                            <input class="form-check-input" type="checkbox" name="organisasi_non_profit[]" id="organisasinasional" value="nasional">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="organisasiinternasional">
                                                                            <input class="form-check-input" type="checkbox" name="organisasi_non_profit[]" id="organisasiinternasional" value="internasional">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            </tbody>
                                                        </div>
                                                        </table>
                                                    </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_jenis_perusahaan_tempat_bekerja" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F12. Sebutkan sumberdana dalam pembiayaan kuliah?</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf12">
                                                                <input type="radio" required name="pertanyaanf12" id="pertanyaanf12" value="Biaya Sendiri/Keluarga">
                                                                Biaya Sendiri/Keluarga
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf121">
                                                                <input type="radio" name="pertanyaanf12" id="pertanyaanf121" value="Beasiswa ADIK">
                                                                Beasiswa ADIK
                                                            <span></span>
                                                            </label>
                                                        </div>


                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf122">
                                                                <input type="radio" name="pertanyaanf12" id="pertanyaanf122" value="Beasiswa BIDIKMISI">
                                                                Beasiswa BIDIKMISI
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf123">
                                                                <input type="radio" name="pertanyaanf12" id="pertanyaanf123" value="Beasiswa PPA">
                                                                Beasiswa PPA
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf124">
                                                                <input type="radio" name="pertanyaanf12" id="pertanyaanf124" value="Beasiswa AFIRMASI">
                                                                Beasiswa AFIRMASI
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf125">
                                                                <input type="radio" name="pertanyaanf12" id="pertanyaanf125" value="Beasiswa Perusahaan/swasta">
                                                                Beasiswa Perusahaan/swasta
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf126">
                                                                <input type="radio" name="pertanyaanf12" id="pertanyaanf126" value="Lainnya">
                                                                Lainnya
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_pembiayaan" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                                </div>
                                            </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F13. Kira-kira berapa pendapatan anda setiap bulannya?</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <table>
                                                            <tr>
                                                                <td>Dari Pekerjaan Utama </td>
                                                                <td><div class="input-group mb-3">

                                                                    <input type="text" onkeypress="return isNumberKey(event)" placeholder="5000000" name="pekerjaan_utama" class="form-control loan_max_amount" aria-label="Amount (to the nearest dollar)">

                                                                  </div></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Dari Lembur dan Tips </td>
                                                                <td><div class="input-group mb-3">
                                                                    <div class="input-group-prepend">

                                                                    </div>
                                                                    <input type="text" onkeypress="return isNumberKey(event)" placeholder="500000" name="lembur_tips" class="form-control loan_max_amount" aria-label="Amount (to the nearest dollar)">

                                                                  </div></td>
                                                            </tr>
                                                            <tr>
                                                                <td> Dari Pekerjaan Lainnya </td>
                                                                <td><div class="input-group mb-3">
                                                                    <div class="input-group-prepend">

                                                                    </div>
                                                                    <input type="text" onkeypress="return isNumberKey(event)" placeholder="2500000" name="pekerjaan_lainnya" class="form-control loan_max_amount" aria-label="Amount (to the nearest dollar)">

                                                                  </div></td>
                                                            </tr>
                                                        </table>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_pendapatan_setiap_bulannya" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                                </div>
                                            </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F14. Seberapa erat hubungan antara bidang studi dengan pekerjaan anda?</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf14">
                                                                <input type="radio" required name="pertanyaanf14" id="pertanyaanf14" value="1">
                                                                Sangat erat
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf141">
                                                                <input type="radio" name="pertanyaanf14" id="pertanyaanf141" value="2">
                                                                Erat
                                                            <span></span>
                                                            </label>
                                                        </div>


                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf142">
                                                                <input type="radio" name="pertanyaanf14" id="pertanyaanf142" value="3">
                                                               Cukup Erat
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf143">
                                                                <input type="radio" name="pertanyaanf14" id="pertanyaanf143" value="4">
                                                               Kurang Erat
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf144">
                                                                <input type="radio" name="pertanyaanf14" id="pertanyaanf144" value="5">
                                                                Tidak Sama Sekali
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_Seberapaerathubunganantarabidangstudi" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                                </div>
                                            </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F15. Tingkat pendidikan apa yang paling tepat/sesuai untuk pekerjaan anda saat ini?</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf15">
                                                                <input type="radio" required name="pertanyaanf15" id="pertanyaanf15" value="1">
                                                                Setingkat Lebih Tinggi
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf151">
                                                                <input type="radio" name="pertanyaanf15" id="pertanyaanf151" value="2">
                                                                Tingkat Yang Sama
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf152">
                                                                <input type="radio" name="pertanyaanf15" id="pertanyaanf152" value="3">
                                                               Setingkat Lebih Rendah
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="pertanyaanf153">
                                                                <input type="radio" name="pertanyaanf15" id="pertanyaanf153" value="4">
                                                                Tidak Perlu Pendidikan Tinggi
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_tingkat_pendidikan_yang_tepat" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                                </div>
                                            </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>F16. Jika menurut anda pekerjaan anda saat ini tidak sesuai dengan pendidikan anda, mengapa anda mengambilnya? Jawaban bisa lebih dari satu</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf161">
                                                                <input type="checkbox" name="pertanyaanf16_pertanyaan_tidak_sesuai" id="pertanyaanf161" value="1">
                                                                Pertanyaan tidak sesuai; pekerjaan saya sekarang sudah sesuai dengan pendidikan saya.
                                                            <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf162">
                                                                <input type="checkbox" name="pertanyaanf16_Saya_belum_mendapatkan_pekerjaan_yang_lebih_sesuai" id="pertanyaanf162" value="1">
                                                                Saya belum mendapatkan pekerjaan yang lebih sesuai.
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf163">
                                                                <input type="checkbox" name="pertanyaanf16_di_pekerjaan_ini_saya_memeroleh_prospek_karir_yang_baik" id="pertanyaanf163" value="1">
                                                                Di pekerjaan ini saya memeroleh prospek karir yang baik.
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf164">
                                                                <input type="checkbox" name="pertanyaanf16_saya_lebih_suka_bekerja_di_area_pekerjaan" id="pertanyaanf164" value="1">
                                                                Saya lebih suka bekerja di area pekerjaan yang tidak ada hubungannya dengan pendidikan saya.
                                                            <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf165">
                                                                <input type="checkbox" name="pertanyaanf16_saya_dipromosikan_ke_posisi_yang_kurang" id="pertanyaanf165" value="1">
                                                                Saya dipromosikan ke posisi yang kurang berhubungan dengan pendidikan saya dibanding posisi sebelumnya.
                                                            <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf166">
                                                                <input type="checkbox" name="pertanyaanf16_Saya_dapat_memeroleh_pendapatan" id="pertanyaanf166" value="1">
                                                                Saya dapat memeroleh pendapatan yang lebih tinggi di pekerjaan ini.
                                                            <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf167">
                                                                <input type="checkbox" name="pertanyaanf16_Pekerjaan_saya_saat_ini_lebih_aman_terjamin_secure" id="pertanyaanf167" value="1">
                                                                Pekerjaan saya saat ini lebih aman/terjamin/secure.
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf168">
                                                                <input type="checkbox" name="pertanyaanf16_Pekerjaan_saya_saat_ini_lebih_menarik" id="pertanyaanf168" value="1">
                                                                Pekerjaan saya saat ini lebih menarik.
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf169">
                                                                <input type="checkbox" name="pertanyaanf16_Pekerjaan_saya_saat_ini_lebih_memungkinkan" id="pertanyaanf169" value="1">
                                                                Pekerjaan saya saat ini lebih memungkinkan saya mengambil pekerjaan tambahan/jadwal yang fleksibel, dll.
                                                            <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf1610">
                                                                <input type="checkbox" name="pertanyaanf16_Pekerjaan_saya_saat_ini_lokasinya_lebih_dekat" id="pertanyaanf1610" value="1">
                                                                Pekerjaan saya saat ini lokasinya lebih dekat dari rumah saya.
                                                            <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf1611">
                                                                <input type="checkbox" name="pertanyaanf16_Pekerjaan_saya_saat_ini_dapat_lebih" id="pertanyaanf1611" value="1">
                                                                Pekerjaan saya saat ini dapat lebih menjamin kebutuhan keluarga saya.
                                                            <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf1612">
                                                                <input type="checkbox" name="pertanyaanf16_Pada_awal_meniti_karir_ini" id="pertanyaanf1612" value="1">
                                                                Pada awal meniti karir ini, saya harus menerima pekerjaan yang tidak berhubungan dengan pendidikan saya.
                                                            <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="pertanyaanf1613">
                                                                <input type="checkbox" name="pertanyaanf16_Lainnya" id="pertanyaanf1613" value="1">
                                                                Lainnya:
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_tingkat_pendidikan_yang_tepat2" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                                </div>
                                            </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Menurut Anda, bagaimanakah profil karakter kepribadian Anda dalam lingkungan kerja?</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="table-responsive">
                                                        <table class="table table-striped m-table" style="display: block; min-height: 300px; overflow-x: auto;border:1">
                                                            <thead>
                                                            <tr>
                                                                <th></th>
                                                                <th>Sangat Besar</th>
                                                                <th>Besar</th>
                                                                <th>Cukup</th>
                                                                <th>Kecil</th>
                                                                <th>Sangat Kecil</th>
                                                            </tr>
                                                            </thead>

                                                            <tbody>
                                                            <tr>
                                                                <td>Melakukan pekerjaan dengan penuh tanggung jawab dan keikhlasan</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="tanggung_jawab1">
                                                                            <input class="form-check-input " required type="radio" name="tanggung_jawab" id="tanggung_jawab1" value="sangat besar">
                                                                        <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="tanggung_jawab2">
                                                                            <input class="form-check-input " type="radio" name="tanggung_jawab" id="tanggung_jawab2" value="besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="tanggung_jawab3">
                                                                            <input class="form-check-input " type="radio" name="tanggung_jawab" id="tanggung_jawab3" value="cukup besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="tanggung_jawab4">
                                                                            <input class="form-check-input " type="radio" name="tanggung_jawab" id="tanggung_jawab4" value="kurang">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="tanggung_jawab5">
                                                                            <input class="form-check-input " type="radio" name="tanggung_jawab" id="tanggung_jawab5" value="tidak sama sekali">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Mampu bekerjasama dalam tim</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjasama1">
                                                                            <input class="form-check-input " type="radio" required name="bekerjasama" id="bekerjasama1" value="sangat besar">
                                                                        <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjasama2">
                                                                            <input class="form-check-input " type="radio"  name="bekerjasama" id="bekerjasama2" value="besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjasama3">
                                                                            <input class="form-check-input " type="radio" name="bekerjasama" id="bekerjasama3" value="cukup besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjasama4">
                                                                            <input class="form-check-input " type="radio" name="bekerjasama" id="bekerjasama4" value="kurang">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjasama5">
                                                                            <input class="form-check-input " type="radio" name="bekerjasama" id="bekerjasama5" value="tidak sama sekali">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Bersungguh-sungguh dan memegang teguh nilai kebenaran dalam melakanakan pekerjaan</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bersungguhsungguh1">
                                                                            <input class="form-check-input " required type="radio" name="bersungguhsungguh" id="bersungguhsungguh1" value="sangat besar">
                                                                        <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bersungguhsungguh2">
                                                                            <input class="form-check-input " type="radio" name="bersungguhsungguh" id="bersungguhsungguh2" value="besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bersungguhsungguh3">
                                                                            <input class="form-check-input " type="radio" name="bersungguhsungguh" id="bersungguhsungguh3" value="cukup besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bersungguhsungguh4">
                                                                            <input class="form-check-input " type="radio" name="bersungguhsungguh" id="bersungguhsungguh4" value="kurang">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bersungguhsungguh5">
                                                                            <input class="form-check-input " type="radio" name="bersungguhsungguh" id="bersungguhsungguh5" value="tidak sama sekali">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Bekerja keras sesuai dengan kompetensi</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjakeras1">
                                                                            <input class="form-check-input " required type="radio" name="bekerjakeras" id="bekerjakeras1" value="sangat besar">
                                                                        <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjakeras2">
                                                                            <input class="form-check-input " type="radio" name="bekerjakeras" id="bekerjakeras2" value="besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjakeras3">
                                                                            <input class="form-check-input " type="radio" name="bekerjakeras" id="bekerjakeras3" value="cukup besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjakeras4">
                                                                            <input class="form-check-input " type="radio" name="bekerjakeras" id="bekerjakeras4" value="kurang">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjakeras5">
                                                                            <input class="form-check-input " type="radio" name="bekerjakeras" id="bekerjakeras5" value="tidak sama sekali">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Toleran dan mampu menerima masukkan dari siapapun</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="toleran1">
                                                                            <input class="form-check-input " required type="radio" name="toleran" id="toleran1" value="sangat besar">
                                                                        <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="toleran2">
                                                                            <input class="form-check-input " type="radio" name="toleran" id="toleran2" value="besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="toleran3">
                                                                            <input class="form-check-input " type="radio" name="toleran" id="toleran3" value="cukup besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="toleran4">
                                                                            <input class="form-check-input " type="radio" name="toleran" id="toleran4" value="kurang">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="toleran5">
                                                                            <input class="form-check-input " type="radio" name="toleran" id="toleran5" value="tidak sama sekali">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Meletakkan segala sesuatu secara profesional</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="meletakkansegalasesuatu1">
                                                                            <input class="form-check-input " required type="radio" name="meletakkansegalasesuatu" id="meletakkansegalasesuatu1" value="sangat besar">
                                                                        <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="meletakkansegalasesuatu2">
                                                                            <input class="form-check-input " type="radio" name="meletakkansegalasesuatu" id="meletakkansegalasesuatu2" value="besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="meletakkansegalasesuatu3">
                                                                            <input class="form-check-input " type="radio" name="meletakkansegalasesuatu" id="meletakkansegalasesuatu3" value="cukup besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="meletakkansegalasesuatu4">
                                                                            <input class="form-check-input " type="radio" name="meletakkansegalasesuatu" id="meletakkansegalasesuatu4" value="kurang">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="meletakkansegalasesuatu5">
                                                                            <input class="form-check-input " type="radio" name="meletakkansegalasesuatu" id="meletakkansegalasesuatu5" value="tidak sama sekali">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Kreatif dan inovatif dalam mengembangkan kualitas pekerjaan</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kreatifdaninovatif1">
                                                                            <input class="form-check-input " required type="radio" name="kreatifdaninovatif" id="kreatifdaninovatif1" value="sangat besar">
                                                                        <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kreatifdaninovatif2">
                                                                            <input class="form-check-input " type="radio" name="kreatifdaninovatif" id="kreatifdaninovatif2" value="besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kreatifdaninovatif3">
                                                                            <input class="form-check-input " type="radio" name="kreatifdaninovatif" id="kreatifdaninovatif3" value="cukup besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kreatifdaninovatif4">
                                                                            <input class="form-check-input " type="radio" name="kreatifdaninovatif" id="kreatifdaninovatif4" value="kurang">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kreatifdaninovatif5">
                                                                            <input class="form-check-input " type="radio" name="kreatifdaninovatif" id="kreatifdaninovatif5" value="tidak sama sekali">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Mampu membuat keputusan terbaik dengan arif dan bijaksana</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="keputusanterbaik1">
                                                                            <input class="form-check-input " required type="radio" name="keputusanterbaik" id="keputusanterbaik1" value="sangat besar">
                                                                        <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="keputusanterbaik2">
                                                                            <input class="form-check-input " type="radio" name="keputusanterbaik" id="keputusanterbaik2" value="besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="keputusanterbaik3">
                                                                            <input class="form-check-input " type="radio" name="keputusanterbaik" id="keputusanterbaik3" value="cukup besar">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="keputusanterbaik4">
                                                                            <input class="form-check-input " type="radio" name="keputusanterbaik" id="keputusanterbaik4" value="kurang">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="keputusanterbaik5">
                                                                            <input class="form-check-input " type="radio" name="keputusanterbaik" id="keputusanterbaik5" value="tidak sama sekali">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>

                                                        <br>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_BerapakaliSaudaramenjadipanitiadalamorganisasi" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-bottom: 1.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>

                                                <h2 class="m-portlet__head-label m-portlet__head-label--success">
                                                    <span>Kompetensi</span>
                                                </h2>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">
                                        <b>Pada saat lulus, pada tingkat mana kompetensi di bawah ini Anda kuasai? (A)</b>
                                        <br><br>
                                        <div class="form-group m-form__group row" style="margin-left: -10px">

                                            <div class="col-lg-12">
                                                <div class="table-responsive">

                                                <table class="table table-striped m-table" style="display: block; min-height: 300px; overflow-x: auto;border:1;width:100%">
                                                    <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th>Sangat Besar</th>
                                                        <th>Besar</th>
                                                        <th>Cukup</th>
                                                        <th>Kecil</th>
                                                        <th>Sangat Kecil</th>
                                                    </tr>
                                                    </thead>

                                                    <tbody>
                                                    <tr>
                                                        <td>Pengetahuan di bidang atau disiplin ilmu Anda</td>
                                                        <td>
                                                            <div class="form-check">

                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandibidang1">
                                                                    <input class="form-check-input" required type="radio" name="pengetahuandibidang" id="pengetahuandibidang1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandibidang2">
                                                                    <input class="form-check-input" type="radio" name="pengetahuandibidang" id="pengetahuandibidang2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandibidang3">
                                                                    <input class="form-check-input" type="radio" name="pengetahuandibidang" id="pengetahuandibidang3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandibidang4">
                                                                    <input class="form-check-input" type="radio" name="pengetahuandibidang" id="pengetahuandibidang4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandibidang5">
                                                                    <input class="form-check-input" type="radio" name="pengetahuandibidang" id="pengetahuandibidang5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Pengetahuan di luar bidang atau disiplin ilmu Anda</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandiluarbidang1">
                                                                    <input class="form-check-input" required type="radio" name="pengetahuandiluarbidang" id="pengetahuandiluarbidang1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandiluarbidang2">
                                                                    <input class="form-check-input" type="radio" name="pengetahuandiluarbidang" id="pengetahuandiluarbidang2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandiluarbidang3">
                                                                    <input class="form-check-input" type="radio" name="pengetahuandiluarbidang" id="pengetahuandiluarbidang3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandiluarbidang4">
                                                                    <input class="form-check-input" type="radio" name="pengetahuandiluarbidang" id="pengetahuandiluarbidang4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandiluarbidang5">
                                                                    <input class="form-check-input" type="radio" name="pengetahuandiluarbidang" id="pengetahuandiluarbidang5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Pengetahuan umum</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuanumum1">
                                                                    <input class="form-check-input" required type="radio" name="pengetahuanumum" id="pengetahuanumum1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuanumum2">
                                                                    <input class="form-check-input" type="radio" name="pengetahuanumum" id="pengetahuanumum2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuanumum3">
                                                                    <input class="form-check-input" type="radio" name="pengetahuanumum" id="pengetahuanumum3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuanumum4">
                                                                    <input class="form-check-input" type="radio" name="pengetahuanumum" id="pengetahuanumum4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="pengetahuanumum5">
                                                                    <input class="form-check-input" type="radio" name="pengetahuanumum" id="pengetahuanumum5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Bahasa Inggris</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bahasainggris1">
                                                                    <input class="form-check-input" required type="radio" name="bahasainggris" id="bahasainggris1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bahasainggris2">
                                                                    <input class="form-check-input" type="radio" name="bahasainggris" id="bahasainggris2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bahasainggris3">
                                                                    <input class="form-check-input" type="radio" name="bahasainggris" id="bahasainggris3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bahasainggris4">
                                                                    <input class="form-check-input" type="radio" name="bahasainggris" id="bahasainggris4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bahasainggris5">
                                                                    <input class="form-check-input" type="radio" name="bahasainggris" id="bahasainggris5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Ketrampilan internet</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilaninternet1">
                                                                    <input class="form-check-input" required type="radio" name="ketrampilaninternet" id="ketrampilaninternet1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilaninternet2">
                                                                    <input class="form-check-input" type="radio" name="ketrampilaninternet" id="ketrampilaninternet2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilaninternet3">
                                                                    <input class="form-check-input" type="radio" name="ketrampilaninternet" id="ketrampilaninternet3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilaninternet4">
                                                                    <input class="form-check-input" type="radio" name="ketrampilaninternet" id="ketrampilaninternet4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilaninternet5">
                                                                    <input class="form-check-input" type="radio" name="ketrampilaninternet" id="ketrampilaninternet5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Ketrampilan komputer</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilankomputer1">
                                                                    <input class="form-check-input" required type="radio" name="ketrampilankomputer" id="ketrampilankomputer1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilankomputer2">
                                                                    <input class="form-check-input" type="radio" name="ketrampilankomputer" id="ketrampilankomputer2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilankomputer3">
                                                                    <input class="form-check-input" type="radio" name="ketrampilankomputer" id="ketrampilankomputer3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilankomputer4">
                                                                    <input class="form-check-input" type="radio" name="ketrampilankomputer" id="ketrampilankomputer4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilankomputer5">
                                                                    <input class="form-check-input" type="radio" name="ketrampilankomputer" id="ketrampilankomputer5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Berpikir kritis</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="berpikirkritis1">
                                                                    <input class="form-check-input" required type="radio" name="berpikirkritis" id="berpikirkritis1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="berpikirkritis2">
                                                                    <input class="form-check-input" type="radio" name="berpikirkritis" id="berpikirkritis2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="berpikirkritis3">
                                                                    <input class="form-check-input" type="radio" name="berpikirkritis" id="berpikirkritis3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="berpikirkritis4">
                                                                    <input class="form-check-input" type="radio" name="berpikirkritis" id="berpikirkritis4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="berpikirkritis5">
                                                                    <input class="form-check-input" type="radio" name="berpikirkritis" id="berpikirkritis5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Keterampilan Riset</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilanriset1">
                                                                    <input class="form-check-input" required type="radio" name="ketrampilanriset" id="ketrampilanriset1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilanriset2">
                                                                    <input class="form-check-input" type="radio" name="ketrampilanriset" id="ketrampilanriset2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilanriset3">
                                                                    <input class="form-check-input" type="radio" name="ketrampilanriset" id="ketrampilanriset3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilanriset4">
                                                                    <input class="form-check-input" type="radio" name="ketrampilanriset" id="ketrampilanriset4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="ketrampilanriset5">
                                                                    <input class="form-check-input" type="radio" name="ketrampilanriset" id="ketrampilanriset5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Kemampuan belajar</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanbelajar1">
                                                                    <input class="form-check-input" required type="radio" name="kemampuanbelajar" id="kemampuanbelajar1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanbelajar2">
                                                                    <input class="form-check-input" type="radio" name="kemampuanbelajar" id="kemampuanbelajar2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanbelajar3">
                                                                    <input class="form-check-input" type="radio" name="kemampuanbelajar" id="kemampuanbelajar3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanbelajar4">
                                                                    <input class="form-check-input" type="radio" name="kemampuanbelajar" id="kemampuanbelajar4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanbelajar5">
                                                                    <input class="form-check-input" type="radio" name="kemampuanbelajar" id="kemampuanbelajar5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Kemampuan berkomunikasi</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanberkomunikasi1">
                                                                    <input class="form-check-input" required type="radio" name="kemampuanberkomunikasi" id="kemampuanberkomunikasi1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanberkomunikasi2">
                                                                    <input class="form-check-input" type="radio" name="kemampuanberkomunikasi" id="kemampuanberkomunikasi2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanberkomunikasi3">
                                                                    <input class="form-check-input" type="radio" name="kemampuanberkomunikasi" id="kemampuanberkomunikasi3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanberkomunikasi4">
                                                                    <input class="form-check-input" type="radio" name="kemampuanberkomunikasi" id="kemampuanberkomunikasi4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanberkomunikasi5">
                                                                    <input class="form-check-input" type="radio" name="kemampuanberkomunikasi" id="kemampuanberkomunikasi5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Bekerja di bawah tekanan</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadibawahtekanan1">
                                                                    <input class="form-check-input" required type="radio" name="bekerjadibawahtekanan" id="bekerjadibawahtekanan1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadibawahtekanan2">
                                                                    <input class="form-check-input" type="radio" name="bekerjadibawahtekanan" id="bekerjadibawahtekanan2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadibawahtekanan3">
                                                                    <input class="form-check-input" type="radio" name="bekerjadibawahtekanan" id="bekerjadibawahtekanan3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadibawahtekanan4">
                                                                    <input class="form-check-input" type="radio" name="bekerjadibawahtekanan" id="bekerjadibawahtekanan4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadibawahtekanan5">
                                                                    <input class="form-check-input" type="radio" name="bekerjadibawahtekanan" id="bekerjadibawahtekanan5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Manajemen waktu</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="manajemenwaktu1">
                                                                    <input class="form-check-input" required type="radio" name="manajemenwaktu" id="manajemenwaktu1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="manajemenwaktu2">
                                                                    <input class="form-check-input" type="radio" name="manajemenwaktu" id="manajemenwaktu2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="manajemenwaktu3">
                                                                    <input class="form-check-input" type="radio" name="manajemenwaktu" id="manajemenwaktu3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="manajemenwaktu4">
                                                                    <input class="form-check-input" type="radio" name="manajemenwaktu" id="manajemenwaktu4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="manajemenwaktu5">
                                                                    <input class="form-check-input" type="radio" name="manajemenwaktu" id="manajemenwaktu5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Bekerja secara mandiri</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjasecaramandiri1">
                                                                    <input class="form-check-input" required type="radio" name="bekerjasecaramandiri" id="bekerjasecaramandiri1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjasecaramandiri2">
                                                                    <input class="form-check-input" type="radio" name="bekerjasecaramandiri" id="bekerjasecaramandiri2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjasecaramandiri3">
                                                                    <input class="form-check-input" type="radio" name="bekerjasecaramandiri" id="bekerjasecaramandiri3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjasecaramandiri4">
                                                                    <input class="form-check-input" type="radio" name="bekerjasecaramandiri" id="bekerjasecaramandiri4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjasecaramandiri5">
                                                                    <input class="form-check-input" type="radio" name="bekerjasecaramandiri" id="bekerjasecaramandiri5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Bekerja dalam tim/bekerjasama</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadalamtim1">
                                                                    <input class="form-check-input" required type="radio" name="bekerjadalamtim" id="bekerjadalamtim1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadalamtim2">
                                                                    <input class="form-check-input" type="radio" name="bekerjadalamtim" id="bekerjadalamtim2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadalamtim3">
                                                                    <input class="form-check-input" type="radio" name="bekerjadalamtim" id="bekerjadalamtim3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadalamtim4">
                                                                    <input class="form-check-input" type="radio" name="bekerjadalamtim" id="bekerjadalamtim4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadalamtim5">
                                                                    <input class="form-check-input" type="radio" name="bekerjadalamtim" id="bekerjadalamtim5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Kemampuan dalam memecahkan masalah</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemecahkanmasalah1">
                                                                    <input class="form-check-input" required type="radio" name="kemampuandalammemecahkanmasalah" id="kemampuandalammemecahkanmasalah1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemecahkanmasalah2">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammemecahkanmasalah" id="kemampuandalammemecahkanmasalah2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemecahkanmasalah3">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammemecahkanmasalah" id="kemampuandalammemecahkanmasalah3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemecahkanmasalah4">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammemecahkanmasalah" id="kemampuandalammemecahkanmasalah4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemecahkanmasalah5">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammemecahkanmasalah" id="kemampuandalammemecahkanmasalah5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Negosiasi</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="negoisasi1">
                                                                    <input class="form-check-input" required type="radio" name="negoisasi" id="negoisasi1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="negoisasi2">
                                                                    <input class="form-check-input" type="radio" name="negoisasi" id="negoisasi2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="negoisasi3">
                                                                    <input class="form-check-input" type="radio" name="negoisasi" id="negoisasi3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="negoisasi4">
                                                                    <input class="form-check-input" type="radio" name="negoisasi" id="negoisasi4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="negoisasi5">
                                                                    <input class="form-check-input" type="radio" name="negoisasi" id="negoisasi5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Kemampuan analisis</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanalisis1">
                                                                    <input class="form-check-input" required type="radio" name="kemampuanalisis" id="kemampuanalisis1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanalisis2">
                                                                    <input class="form-check-input" type="radio" name="kemampuanalisis" id="kemampuanalisis2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanalisis3">
                                                                    <input class="form-check-input" type="radio" name="kemampuanalisis" id="kemampuanalisis3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanalisis4">
                                                                    <input class="form-check-input" type="radio" name="kemampuanalisis" id="kemampuanalisis4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanalisis5">
                                                                    <input class="form-check-input" type="radio" name="kemampuanalisis" id="kemampuanalisis5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Toleransi </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="toleransi1">
                                                                    <input class="form-check-input" required type="radio" name="toleransi" id="toleransi1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="toleransi2">
                                                                    <input class="form-check-input" type="radio" name="toleransi" id="toleransi2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="toleransi3">
                                                                    <input class="form-check-input" type="radio" name="toleransi" id="toleransi3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="toleransi4">
                                                                    <input class="form-check-input" type="radio" name="toleransi" id="toleransi4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="toleransi5">
                                                                    <input class="form-check-input" type="radio" name="toleransi" id="toleransi5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Kemampuan adaptasi</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanadaptasi1">
                                                                    <input class="form-check-input" required type="radio" name="kemampuanadaptasi" id="kemampuanadaptasi1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanadaptasi2">
                                                                    <input class="form-check-input" type="radio" name="kemampuanadaptasi" id="kemampuanadaptasi2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanadaptasi3">
                                                                    <input class="form-check-input" type="radio" name="kemampuanadaptasi" id="kemampuanadaptasi3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanadaptasi4">
                                                                    <input class="form-check-input" type="radio" name="kemampuanadaptasi" id="kemampuanadaptasi4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanadaptasi5">
                                                                    <input class="form-check-input" type="radio" name="kemampuanadaptasi" id="kemampuanadaptasi5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Loyalitas</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="loyalitas1">
                                                                    <input class="form-check-input" required type="radio" name="loyalitas" id="loyalitas1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="loyalitas2">
                                                                    <input class="form-check-input" type="radio" name="loyalitas" id="loyalitas2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="loyalitas3">
                                                                    <input class="form-check-input" type="radio" name="loyalitas" id="loyalitas3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="loyalitas4">
                                                                    <input class="form-check-input" type="radio" name="loyalitas" id="loyalitas4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="loyalitas5">
                                                                    <input class="form-check-input" type="radio" name="loyalitas" id="loyalitas5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Integritas</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="integritas1">
                                                                    <input class="form-check-input" required type="radio" name="integritas" id="integritas1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="integritas2">
                                                                    <input class="form-check-input" type="radio" name="integritas" id="integritas2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="integritas3">
                                                                    <input class="form-check-input" type="radio" name="integritas" id="integritas3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="integritas4">
                                                                    <input class="form-check-input" type="radio" name="integritas" id="integritas4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="integritas5">
                                                                    <input class="form-check-input" type="radio" name="integritas" id="integritas5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Bekerja dengan orang yang berbeda budaya maupun latar belakang</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadengancaraberbeda1">
                                                                    <input class="form-check-input" required type="radio" name="bekerjadengancaraberbeda" id="bekerjadengancaraberbeda1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadengancaraberbeda2">
                                                                    <input class="form-check-input" type="radio" name="bekerjadengancaraberbeda" id="bekerjadengancaraberbeda2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadengancaraberbeda3">
                                                                    <input class="form-check-input" type="radio" name="bekerjadengancaraberbeda" id="bekerjadengancaraberbeda3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadengancaraberbeda4">
                                                                    <input class="form-check-input" type="radio" name="bekerjadengancaraberbeda" id="bekerjadengancaraberbeda4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="bekerjadengancaraberbeda5">
                                                                    <input class="form-check-input" type="radio" name="bekerjadengancaraberbeda" id="bekerjadengancaraberbeda5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Kepemimpinan</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kepemimpinan1">
                                                                    <input class="form-check-input" required type="radio" name="kepemimpinan" id="kepemimpinan1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kepemimpinan2">
                                                                    <input class="form-check-input" type="radio" name="kepemimpinan" id="kepemimpinan2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kepemimpinan3">
                                                                    <input class="form-check-input" type="radio" name="kepemimpinan" id="kepemimpinan3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kepemimpinan4">
                                                                    <input class="form-check-input" type="radio" name="kepemimpinan" id="kepemimpinan4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kepemimpinan5">
                                                                    <input class="form-check-input" type="radio" name="kepemimpinan" id="kepemimpinan5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Kemampuan dalam memegang tanggungjawab</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemegangtanggungjawab1">
                                                                    <input class="form-check-input" required type="radio" name="kemampuandalammemegangtanggungjawab" id="kemampuandalammemegangtanggungjawab1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemegangtanggungjawab2">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammemegangtanggungjawab" id="kemampuandalammemegangtanggungjawab2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemegangtanggungjawab3">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammemegangtanggungjawab" id="kemampuandalammemegangtanggungjawab3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemegangtanggungjawab4">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammemegangtanggungjawab" id="kemampuandalammemegangtanggungjawab4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemegangtanggungjawab5">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammemegangtanggungjawab" id="kemampuandalammemegangtanggungjawab5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Inisiatif</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="inisiatif1">
                                                                    <input class="form-check-input" required type="radio" name="inisiatif" id="inisiatif1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="inisiatif2">
                                                                    <input class="form-check-input" type="radio" name="inisiatif" id="inisiatif2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="inisiatif3">
                                                                    <input class="form-check-input" type="radio" name="inisiatif" id="inisiatif3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="inisiatif4">
                                                                    <input class="form-check-input" type="radio" name="inisiatif" id="inisiatif4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="inisiatif5">
                                                                    <input class="form-check-input" type="radio" name="inisiatif" id="inisiatif5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Manajemen proyek/program</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="manajemenproyek1">
                                                                    <input class="form-check-input" required type="radio" name="manajemenproyek" id="manajemenproyek1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="manajemenproyek2">
                                                                    <input class="form-check-input" type="radio" name="manajemenproyek" id="manajemenproyek2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="manajemenproyek3">
                                                                    <input class="form-check-input" type="radio" name="manajemenproyek" id="manajemenproyek3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="manajemenproyek4">
                                                                    <input class="form-check-input" type="radio" name="manajemenproyek" id="manajemenproyek4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="manajemenproyek5">
                                                                    <input class="form-check-input" type="radio" name="manajemenproyek" id="manajemenproyek5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Kemampuan untuk memresentasikan ide/produk/laporan</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanmemresentasikanide1">
                                                                    <input class="form-check-input" required type="radio" name="kemampuanmemresentasikanide" id="kemampuanmemresentasikanide1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanmemresentasikanide2">
                                                                    <input class="form-check-input"  type="radio" name="kemampuanmemresentasikanide" id="kemampuanmemresentasikanide2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanmemresentasikanide3">
                                                                    <input class="form-check-input" type="radio" name="kemampuanmemresentasikanide" id="kemampuanmemresentasikanide3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanmemresentasikanide4">
                                                                    <input class="form-check-input" type="radio" name="kemampuanmemresentasikanide" id="kemampuanmemresentasikanide4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanmemresentasikanide5">
                                                                    <input class="form-check-input" type="radio" name="kemampuanmemresentasikanide" id="kemampuanmemresentasikanide5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Kemampuan dalam menulis laporan, memo dan dokumen</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammenulislaporan1">
                                                                    <input class="form-check-input" required type="radio" name="kemampuandalammenulislaporan" id="kemampuandalammenulislaporan1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammenulislaporan2">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammenulislaporan" id="kemampuandalammenulislaporan2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammenulislaporan3">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammenulislaporan" id="kemampuandalammenulislaporan3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammenulislaporan4">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammenulislaporan" id="kemampuandalammenulislaporan4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammenulislaporan5">
                                                                    <input class="form-check-input" type="radio" name="kemampuandalammenulislaporan" id="kemampuandalammenulislaporan5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                     <tr>
                                                        <td>Kemampuan untuk terus belajar sepanjang hayat</td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanuntukterusbelajar1">
                                                                    <input class="form-check-input" required type="radio" name="kemampuanuntukterusbelajar" id="kemampuanuntukterusbelajar1" value="5">
                                                                <span></span>
                                                            </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanuntukterusbelajar2">
                                                                    <input class="form-check-input" type="radio" name="kemampuanuntukterusbelajar" id="kemampuanuntukterusbelajar2" value="4">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanuntukterusbelajar3">
                                                                    <input class="form-check-input" type="radio" name="kemampuanuntukterusbelajar" id="kemampuanuntukterusbelajar3" value="3">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanuntukterusbelajar4">
                                                                    <input class="form-check-input" type="radio" name="kemampuanuntukterusbelajar" id="kemampuanuntukterusbelajar4" value="2">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="m-radio m-radio--solid m-radio--success" for="kemampuanuntukterusbelajar5">
                                                                    <input class="form-check-input" type="radio" name="kemampuanuntukterusbelajar" id="kemampuanuntukterusbelajar5" value="1">
                                                                    <span></span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Pada saat ini, pada tingkat mana kompetensi di bawah ini diperlukan dalam pekerjaan? (B)</b>
                                                <br><br>
                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">
                                                        <div class="table-responsive">
                                                        <table class="table table-striped m-table" style="display: block; min-height: 300px; overflow-x: auto;border:1;width:100%">
                                                            <thead>
                                                            <tr>
                                                                <th></th>
                                                                <th>Sangat Tinggi</th>
                                                                <th>Tinggi</th>
                                                                <th>Cukup</th>
                                                                <th>Rendah</th>
                                                                <th>Sangat Rendah</th>
                                                            </tr>
                                                            </thead>

                                                            <tbody>
                                                            <tr>
                                                                <td>Pengetahuan di bidang atau disiplin ilmu Anda</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandibidang_b1">
                                                                            <input class="form-check-input " required type="radio" name="pengetahuandibidang_b" id="pengetahuandibidang_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandibidang_b2">
                                                                            <input class="form-check-input " type="radio" name="pengetahuandibidang_b" id="pengetahuandibidang_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandibidang_b3">
                                                                            <input class="form-check-input " type="radio" name="pengetahuandibidang_b" id="pengetahuandibidang_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandibidang_b4">
                                                                            <input class="form-check-input " type="radio" name="pengetahuandibidang_b" id="pengetahuandibidang_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandibidang_b5">
                                                                            <input class="form-check-input " type="radio" name="pengetahuandibidang_b" id="pengetahuandibidang_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Pengetahuan di luar bidang atau disiplin ilmu Anda</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandiluarbidang_b1">
                                                                            <input class="form-check-input " required type="radio" name="pengetahuandiluarbidang_b" id="pengetahuandiluarbidang_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandiluarbidang_b2">
                                                                            <input class="form-check-input " type="radio" name="pengetahuandiluarbidang_b" id="pengetahuandiluarbidang_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandiluarbidang_b3">
                                                                            <input class="form-check-input " type="radio" name="pengetahuandiluarbidang_b" id="pengetahuandiluarbidang_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandiluarbidang_b4">
                                                                            <input class="form-check-input " type="radio" name="pengetahuandiluarbidang_b" id="pengetahuandiluarbidang_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuandiluarbidang_b5">
                                                                            <input class="form-check-input " type="radio" name="pengetahuandiluarbidang_b" id="pengetahuandiluarbidang_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Pengetahuan umum</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuanumum_b1">
                                                                            <input class="form-check-input " required type="radio" name="pengetahuanumum_b" id="pengetahuanumum_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuanumum_b2">
                                                                            <input class="form-check-input " type="radio" name="pengetahuanumum_b" id="pengetahuanumum_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuanumum_b3">
                                                                            <input class="form-check-input " type="radio" name="pengetahuanumum_b" id="pengetahuanumum_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuanumum_b4">
                                                                            <input class="form-check-input " type="radio" name="pengetahuanumum_b" id="pengetahuanumum_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="pengetahuanumum_b5">
                                                                            <input class="form-check-input " type="radio" name="pengetahuanumum_b" id="pengetahuanumum_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Bahasa Inggris</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bahasainggris_b1">
                                                                            <input class="form-check-input " required type="radio" name="bahasainggris_b" id="bahasainggris_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bahasainggris_b2">
                                                                            <input class="form-check-input " type="radio" name="bahasainggris_b" id="bahasainggris_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bahasainggris_b3">
                                                                            <input class="form-check-input " type="radio" name="bahasainggris_b" id="bahasainggris_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bahasainggris_b4">
                                                                            <input class="form-check-input " type="radio" name="bahasainggris_b" id="bahasainggris_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bahasainggris_b5">
                                                                            <input class="form-check-input " type="radio" name="bahasainggris_b" id="bahasainggris_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Ketrampilan internet</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilaninternet_b1">
                                                                            <input class="form-check-input " required type="radio" name="ketrampilaninternet_b" id="ketrampilaninternet_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilaninternet_b2">
                                                                            <input class="form-check-input " type="radio" name="ketrampilaninternet_b" id="ketrampilaninternet_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilaninternet_b3">
                                                                            <input class="form-check-input " type="radio" name="ketrampilaninternet_b" id="ketrampilaninternet_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilaninternet_b4">
                                                                            <input class="form-check-input " type="radio" name="ketrampilaninternet_b" id="ketrampilaninternet_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilaninternet_b5">
                                                                            <input class="form-check-input " type="radio" name="ketrampilaninternet_b" id="ketrampilaninternet_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Ketrampilan komputer</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilankomputer_b1">
                                                                            <input class="form-check-input " required type="radio" name="ketrampilankomputer_b" id="ketrampilankomputer_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilankomputer_b2">
                                                                            <input class="form-check-input "  type="radio" name="ketrampilankomputer_b" id="ketrampilankomputer_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilankomputer_b3">
                                                                            <input class="form-check-input " type="radio" name="ketrampilankomputer_b" id="ketrampilankomputer_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilankomputer_b4">
                                                                            <input class="form-check-input " type="radio" name="ketrampilankomputer_b" id="ketrampilankomputer_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilankomputer_b5">
                                                                            <input class="form-check-input " type="radio" name="ketrampilankomputer_b" id="ketrampilankomputer_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Berpikir kritis</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="berpikirkritis_b1">
                                                                            <input class="form-check-input " required type="radio" name="berpikirkritis_b" id="berpikirkritis_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="berpikirkritis_b2">
                                                                            <input class="form-check-input " type="radio" name="berpikirkritis_b" id="berpikirkritis_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="berpikirkritis_b3">
                                                                            <input class="form-check-input " type="radio" name="berpikirkritis_b" id="berpikirkritis_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="berpikirkritis_b4">
                                                                            <input class="form-check-input " type="radio" name="berpikirkritis_b" id="berpikirkritis_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="berpikirkritis_b5">
                                                                            <input class="form-check-input " type="radio" name="berpikirkritis_b" id="berpikirkritis_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Ketrampilan riset</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilanriset_b1">
                                                                            <input class="form-check-input " required type="radio" name="ketrampilanriset_b" id="ketrampilanriset_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilanriset_b2">
                                                                            <input class="form-check-input " type="radio" name="ketrampilanriset_b" id="ketrampilanriset_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilanriset_b3">
                                                                            <input class="form-check-input " type="radio" name="ketrampilanriset_b" id="ketrampilanriset_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilanriset_b4">
                                                                            <input class="form-check-input " type="radio" name="ketrampilanriset_b" id="ketrampilanriset_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="ketrampilanriset_b5">
                                                                            <input class="form-check-input " type="radio" name="ketrampilanriset_b" id="ketrampilanriset_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Kemampuan belajar</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanbelajar_b1">
                                                                            <input class="form-check-input " required type="radio" name="kemampuanbelajar_b" id="kemampuanbelajar_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanbelajar_b2">
                                                                            <input class="form-check-input " type="radio" name="kemampuanbelajar_b" id="kemampuanbelajar_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanbelajar_b3">
                                                                            <input class="form-check-input " type="radio" name="kemampuanbelajar_b" id="kemampuanbelajar_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanbelajar_b4">
                                                                            <input class="form-check-input " type="radio" name="kemampuanbelajar_b" id="kemampuanbelajar_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanbelajar_b5">
                                                                            <input class="form-check-input " type="radio" name="kemampuanbelajar_b" id="kemampuanbelajar_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Kemampuan berkomunikasi</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanberkomunikasi_b1">
                                                                            <input class="form-check-input " required type="radio" name="kemampuanberkomunikasi_b" id="kemampuanberkomunikasi_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanberkomunikasi_b2">
                                                                            <input class="form-check-input " type="radio" name="kemampuanberkomunikasi_b" id="kemampuanberkomunikasi_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanberkomunikasi_b3">
                                                                            <input class="form-check-input " type="radio" name="kemampuanberkomunikasi_b" id="kemampuanberkomunikasi_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanberkomunikasi_b4">
                                                                            <input class="form-check-input " type="radio" name="kemampuanberkomunikasi_b" id="kemampuanberkomunikasi_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanberkomunikasi_b5">
                                                                            <input class="form-check-input " type="radio" name="kemampuanberkomunikasi_b" id="kemampuanberkomunikasi_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Bekerja di bawah tekanan</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadibawahtekanan_b1">
                                                                            <input class="form-check-input " required type="radio" name="bekerjadibawahtekanan_b" id="bekerjadibawahtekanan_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadibawahtekanan_b2">
                                                                            <input class="form-check-input " type="radio" name="bekerjadibawahtekanan_b" id="bekerjadibawahtekanan_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadibawahtekanan_b3">
                                                                            <input class="form-check-input " type="radio" name="bekerjadibawahtekanan_b" id="bekerjadibawahtekanan_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadibawahtekanan_b4">
                                                                            <input class="form-check-input " type="radio" name="bekerjadibawahtekanan_b" id="bekerjadibawahtekanan_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadibawahtekanan_b5">
                                                                            <input class="form-check-input " type="radio" name="bekerjadibawahtekanan_b" id="bekerjadibawahtekanan_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Manajemen waktu</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="manajemenwaktu_b1">
                                                                            <input class="form-check-input " required type="radio" name="manajemenwaktu_b" id="manajemenwaktu_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="manajemenwaktu_b2">
                                                                            <input class="form-check-input " type="radio" name="manajemenwaktu_b" id="manajemenwaktu_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="manajemenwaktu_b3">
                                                                            <input class="form-check-input " type="radio" name="manajemenwaktu_b" id="manajemenwaktu_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="manajemenwaktu_b4">
                                                                            <input class="form-check-input " type="radio" name="manajemenwaktu_b" id="manajemenwaktu_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="manajemenwaktu_b5">
                                                                            <input class="form-check-input " type="radio" name="manajemenwaktu_b" id="manajemenwaktu_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Bekerja secara mandiri</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjasecaramandiri_b1">
                                                                            <input class="form-check-input " required type="radio" name="bekerjasecaramandiri_b" id="bekerjasecaramandiri_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjasecaramandiri_b2">
                                                                            <input class="form-check-input " type="radio" name="bekerjasecaramandiri_b" id="bekerjasecaramandiri_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjasecaramandiri_b3">
                                                                            <input class="form-check-input " type="radio" name="bekerjasecaramandiri_b" id="bekerjasecaramandiri_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjasecaramandiri_b4">
                                                                            <input class="form-check-input " type="radio" name="bekerjasecaramandiri_b" id="bekerjasecaramandiri_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjasecaramandiri_b5">
                                                                            <input class="form-check-input " type="radio" name="bekerjasecaramandiri_b" id="bekerjasecaramandiri_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Bekerja dalam tim/bekerjasama</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadalamtim_b1">
                                                                            <input class="form-check-input " required type="radio" name="bekerjadalamtim_b" id="bekerjadalamtim_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadalamtim_b2">
                                                                            <input class="form-check-input " type="radio" name="bekerjadalamtim_b" id="bekerjadalamtim_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadalamtim_b3">
                                                                            <input class="form-check-input " type="radio" name="bekerjadalamtim_b" id="bekerjadalamtim_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadalamtim_b4">
                                                                            <input class="form-check-input " type="radio" name="bekerjadalamtim_b" id="bekerjadalamtim_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadalamtim_b5">
                                                                            <input class="form-check-input " type="radio" name="bekerjadalamtim_b" id="bekerjadalamtim_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Kemampuan dalam memecahkan masalah</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemecahkanmasalah_b1">
                                                                            <input class="form-check-input " required type="radio" name="kemampuandalammemecahkanmasalah_b" id="kemampuandalammemecahkanmasalah_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemecahkanmasalah_b2">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalammemecahkanmasalah_b" id="kemampuandalammemecahkanmasalah_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemecahkanmasalah_b3">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalammemecahkanmasalah_b" id="kemampuandalammemecahkanmasalah_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemecahkanmasalah_b4">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalammemecahkanmasalah_b" id="kemampuandalammemecahkanmasalah_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammemecahkanmasalah_b5">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalammemecahkanmasalah_b" id="kemampuandalammemecahkanmasalah_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Negosiasi</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="negosisasi_b1">
                                                                            <input class="form-check-input " required type="radio" name="negosisasi_b" id="negosisasi_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="negosisasi_b2">
                                                                            <input class="form-check-input " type="radio" name="negosisasi_b" id="negosisasi_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="negosisasi_b3">
                                                                            <input class="form-check-input " type="radio" name="negosisasi_b" id="negosisasi_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="negosisasi_b4">
                                                                            <input class="form-check-input " type="radio" name="negosisasi_b" id="negosisasi_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="negosisasi_b5">
                                                                            <input class="form-check-input " type="radio" name="negosisasi_b" id="negosisasi_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>


                                                            <tr>
                                                                <td>Kemampuan analisis</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanalisis_b1">
                                                                            <input class="form-check-input " required type="radio" name="kemampuanalisis_b" id="kemampuanalisis_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanalisis_b2">
                                                                            <input class="form-check-input " type="radio" name="kemampuanalisis_b" id="kemampuanalisis_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanalisis_b3">
                                                                            <input class="form-check-input " type="radio" name="kemampuanalisis_b" id="kemampuanalisis_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanalisis_b4">
                                                                            <input class="form-check-input " type="radio" name="kemampuanalisis_b" id="kemampuanalisis_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanalisis_b5">
                                                                            <input class="form-check-input " type="radio" name="kemampuanalisis_b" id="kemampuanalisis_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Toleransi</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="toleransi_b1">
                                                                            <input class="form-check-input " required type="radio" name="toleransi_b" id="toleransi_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="toleransi_b2">
                                                                            <input class="form-check-input " type="radio" name="toleransi_b" id="toleransi_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="toleransi_b3">
                                                                            <input class="form-check-input " type="radio" name="toleransi_b" id="toleransi_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="toleransi_b4">
                                                                            <input class="form-check-input " type="radio" name="toleransi_b" id="toleransi_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="toleransi_b5">
                                                                            <input class="form-check-input " type="radio" name="toleransi_b" id="toleransi_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Kemampuan adaptasi</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanadaptasi_b1">
                                                                            <input class="form-check-input " required type="radio" name="kemampuanadaptasi_b" id="kemampuanadaptasi_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanadaptasi_b2">
                                                                            <input class="form-check-input " type="radio" name="kemampuanadaptasi_b" id="kemampuanadaptasi_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanadaptasi_b3">
                                                                            <input class="form-check-input " type="radio" name="kemampuanadaptasi_b" id="kemampuanadaptasi_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanadaptasi_b4">
                                                                            <input class="form-check-input " type="radio" name="kemampuanadaptasi_b" id="kemampuanadaptasi_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanadaptasi_b5">
                                                                            <input class="form-check-input " type="radio" name="kemampuanadaptasi_b" id="kemampuanadaptasi_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Loyalitas</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="loyalitas_b1">
                                                                            <input class="form-check-input " required type="radio" name="loyalitas_b" id="loyalitas_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="loyalitas_b2">
                                                                            <input class="form-check-input " type="radio" name="loyalitas_b" id="loyalitas_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="loyalitas_b3">
                                                                            <input class="form-check-input " type="radio" name="loyalitas_b" id="loyalitas_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="loyalitas_b4">
                                                                            <input class="form-check-input " type="radio" name="loyalitas_b" id="loyalitas_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="loyalitas_b5">
                                                                            <input class="form-check-input " type="radio" name="loyalitas_b" id="loyalitas_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>integritas</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="integritas_b1">
                                                                            <input class="form-check-input " required type="radio" name="integritas_b" id="integritas_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="integritas_b2">
                                                                            <input class="form-check-input " type="radio" name="integritas_b" id="integritas_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="integritas_b3">
                                                                            <input class="form-check-input " type="radio" name="integritas_b" id="integritas_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="integritas_b4">
                                                                            <input class="form-check-input " type="radio" name="integritas_b" id="integritas_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="integritas_b5">
                                                                            <input class="form-check-input " type="radio" name="integritas_b" id="integritas_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Bekerja dengan orang yang berbeda budaya maupun latar belakang</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadenganlatarbelakang_b21">
                                                                            <input class="form-check-input " required type="radio" name="bekerjadenganlatarbelakang_b2" id="bekerjadenganlatarbelakang_b21" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadenganlatarbelakang_b22">
                                                                            <input class="form-check-input " type="radio" name="bekerjadenganlatarbelakang_b2" id="bekerjadenganlatarbelakang_b22" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadenganlatarbelakang_b23">
                                                                            <input class="form-check-input " type="radio" name="bekerjadenganlatarbelakang_b2" id="bekerjadenganlatarbelakang_b23" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadenganlatarbelakang_b24">
                                                                            <input class="form-check-input " type="radio" name="bekerjadenganlatarbelakang_b2" id="bekerjadenganlatarbelakang_b24" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="bekerjadenganlatarbelakang_b25">
                                                                            <input class="form-check-input " type="radio" name="bekerjadenganlatarbelakang_b2" id="bekerjadenganlatarbelakang_b25" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Kepemimpinan</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kepemimpinan_b1">
                                                                            <input class="form-check-input " required type="radio" name="kepemimpinan_b" id="kepemimpinan_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kepemimpinan_b2">
                                                                            <input class="form-check-input " type="radio" name="kepemimpinan_b" id="kepemimpinan_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kepemimpinan_b3">
                                                                            <input class="form-check-input " type="radio" name="kepemimpinan_b" id="kepemimpinan_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kepemimpinan_b4">
                                                                            <input class="form-check-input " type="radio" name="kepemimpinan_b" id="kepemimpinan_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kepemimpinan_b5">
                                                                            <input class="form-check-input " type="radio" name="kepemimpinan_b" id="kepemimpinan_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Kemampuan dalam memegang tanggungjawab</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalamtanggungjawab_b1">
                                                                            <input class="form-check-input " required type="radio" name="kemampuandalamtanggungjawab_b" id="kemampuandalamtanggungjawab_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalamtanggungjawab_b2">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalamtanggungjawab_b" id="kemampuandalamtanggungjawab_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalamtanggungjawab_b3">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalamtanggungjawab_b" id="kemampuandalamtanggungjawab_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalamtanggungjawab_b4">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalamtanggungjawab_b" id="kemampuandalamtanggungjawab_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalamtanggungjawab_b5">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalamtanggungjawab_b" id="kemampuandalamtanggungjawab_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Inisiatif</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="inisiatif_b1">
                                                                            <input class="form-check-input " required type="radio" name="inisiatif_b" id="inisiatif_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="inisiatif_b2">
                                                                            <input class="form-check-input " type="radio" name="inisiatif_b" id="inisiatif_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="inisiatif_b3">
                                                                            <input class="form-check-input " type="radio" name="inisiatif_b" id="inisiatif_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="inisiatif_b4">
                                                                            <input class="form-check-input " type="radio" name="inisiatif_b" id="inisiatif_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="inisiatif_b5">
                                                                            <input class="form-check-input " type="radio" name="inisiatif_b" id="inisiatif_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Manajemen proyek/program</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="manajemenproyek_b1">
                                                                            <input class="form-check-input " required type="radio" name="manajemenproyek_b" id="manajemenproyek_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="manajemenproyek_b2">
                                                                            <input class="form-check-input " type="radio" name="manajemenproyek_b" id="manajemenproyek_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="manajemenproyek_b3">
                                                                            <input class="form-check-input " type="radio" name="manajemenproyek_b" id="manajemenproyek_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="manajemenproyek_b4">
                                                                            <input class="form-check-input " type="radio" name="manajemenproyek_b" id="manajemenproyek_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="manajemenproyek_b5">
                                                                            <input class="form-check-input " type="radio" name="manajemenproyek_b" id="manajemenproyek_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Kemampuan untuk memresentasikan ide/produk/laporan</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="mempresentasikanideproduk_b1">
                                                                            <input class="form-check-input " required type="radio" name="mempresentasikanideproduk_b" id="mempresentasikanideproduk_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="mempresentasikanideproduk_b2">
                                                                            <input class="form-check-input " type="radio" name="mempresentasikanideproduk_b" id="mempresentasikanideproduk_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="mempresentasikanideproduk_b3">
                                                                            <input class="form-check-input " type="radio" name="mempresentasikanideproduk_b" id="mempresentasikanideproduk_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="mempresentasikanideproduk_b4">
                                                                            <input class="form-check-input " type="radio" name="mempresentasikanideproduk_b" id="mempresentasikanideproduk_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="mempresentasikanideproduk_b5">
                                                                            <input class="form-check-input " type="radio" name="mempresentasikanideproduk_b" id="mempresentasikanideproduk_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Kemampuan dalam menulis laporan, memo dan dokumen</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammenulislaporan_b1">
                                                                            <input class="form-check-input " required type="radio" name="kemampuandalammenulislaporan_b" id="kemampuandalammenulislaporan_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammenulislaporan_b2">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalammenulislaporan_b" id="kemampuandalammenulislaporan_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammenulislaporan_b3">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalammenulislaporan_b" id="kemampuandalammenulislaporan_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammenulislaporan_b4">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalammenulislaporan_b" id="kemampuandalammenulislaporan_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuandalammenulislaporan_b5">
                                                                            <input class="form-check-input " type="radio" name="kemampuandalammenulislaporan_b" id="kemampuandalammenulislaporan_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>Kemampuan untuk terus belajar sepanjang hayat</td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanuntukbelajarsepanjanghayat_b1">
                                                                            <input class="form-check-input " required type="radio" name="kemampuanuntukbelajarsepanjanghayat_b" id="kemampuanuntukbelajarsepanjanghayat_b1" value="5">
                                                                            <span></span>
                                                                    </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanuntukbelajarsepanjanghayat_b2">
                                                                            <input class="form-check-input " type="radio" name="kemampuanuntukbelajarsepanjanghayat_b" id="kemampuanuntukbelajarsepanjanghayat_b2" value="4">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanuntukbelajarsepanjanghayat_b3">
                                                                            <input class="form-check-input " type="radio" name="kemampuanuntukbelajarsepanjanghayat_b" id="kemampuanuntukbelajarsepanjanghayat_b3" value="3">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanuntukbelajarsepanjanghayat_b4">
                                                                            <input class="form-check-input " type="radio" name="kemampuanuntukbelajarsepanjanghayat_b" id="kemampuanuntukbelajarsepanjanghayat_b4" value="2">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <label class="m-radio m-radio--solid m-radio--success" for="kemampuanuntukbelajarsepanjanghayat_b5">
                                                                            <input class="form-check-input " type="radio" name="kemampuanuntukbelajarsepanjanghayat_b" id="kemampuanuntukbelajarsepanjanghayat_b5" value="1">
                                                                            <span></span>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                            </tbody>
                                                        </table>
                                                    </div>

                                                        <br>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_BerapakaliSaudaramenjadipanitiadalamorganisasi" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                        <br>


                                                    </div>


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                                <h3 class="m-portlet__head-text">

                                                </h3>
                                                <h5 class="m-portlet__head-label m-portlet__head-label--success" style="width: 330px" >
                                                    <span style="font-size: 11px">KEAKTIFAN DALAM ORGANISASI KEMAHASISWAAN</span>
                                                </h5>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -35px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Organisasi kemahasiswaan apa yang pernah Saudara ikuti saat kuliah di UNISMA</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">

                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success">
                                                            <input type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="DewanPermusyawaratan" value="Dewan Permusyawaratan Mahasiswa Universitas"> Dewan Permusyawaratan Mahasiswa Universitas (DPMU)
                                                            <span></span>
                                                        </label>

                                                        <br>
                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" >
                                                            <input type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="BadanEksekutif" value="Badan Eksekutif Mahasiswa Universitas">
                                                            Badan Eksekutif Mahasiswa Universitas (BEMU)
                                                            <span></span>
                                                        </label>

                                                        <br>
                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" >
                                                            <input  type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="SI" value="UKM Seni Islami">
                                                            UKM Seni Islami (SI)
                                                            <span></span>
                                                        </label>

                                                        <br>

                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="JQH">
                                                            <input  type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="JQH" value="UKM jam'iyyatul Qurro'Wal Huffadz">
                                                               UKM jam'iyyatul Qurro'Wal Huffadz (JQH) 4
                                                            <span></span>
                                                            </label>
                                                        <br>

                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="MATAN">
                                                            <input  type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="MATAN" value="MATAN">
                                                               UKM Mahasiswa Ahli Thoriq An-Nahdliyah (MATAN)
                                                            <span></span>
                                                            </label>
                                                        <br>

                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="PagarNusa">
                                                            <input  type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="PagarNusa" value="UKM Ikatan Pencak Silat NU">
                                                                UKM Ikatan Pencak Silat NU "Pagar Nusa"
                                                            <span></span>
                                                            </label>
                                                        <br>

                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Photography">
                                                            <input  type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Photography" value="UKM Panorama Photography">
                                                                UKM Panorama Photography
                                                            <span></span>
                                                            </label>
                                                        <br>


                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="PSM_BA">
                                                            <input  type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="PSM_BA" value="PSM-BA">
                                                                Paduan Suara Mahasiswa "Bunga Almamater" (PSM-BA)
                                                            <span></span>
                                                            </label>
                                                        <br>

                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="KSR_PMI">
                                                            <input  type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="KSR_PMI" value="KSR-PMI">
                                                                UKM Korps Suka Rela Palang Merah Indonesia (KSR-PMI)
                                                            <span></span>
                                                            </label>
                                                        <br>

                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="KOPMA">
                                                            <input  type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="KOPMA" value="KOPMA">
                                                                UKM Koperasi Mahasiswa (KOPMA)
                                                            <span></span>
                                                            </label>
                                                        <br>

                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Pramuka">
                                                            <input  type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Pramuka" value="UKM Pramuka">
                                                                UKM Pramuka
                                                            <span></span>
                                                            </label>
                                                        <br>

                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Olahraga">
                                                            <input  type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Olahraga" value="UKM Olahraga">
                                                                UKM Olahraga
                                                            <span></span>
                                                            </label>
                                                        <br>
                                                        <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Musik_Gaung">
                                                            <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Musik_Gaung" value="UKM Musik Gaung 193">
                                                                UKM Musik Gaung 193
                                                            <span></span>
                                                            </label>
                                               <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Teater">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Teater" value="UKM Komunitas Teater">
                                                               UKM Komunitas Teater
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="RPA">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="RPA" value="RPA">
                                                               UKM pecinta Alam "Ranti Pager Aji"(RPA)
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Melati_Sekar_Langit">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Melati_Sekar_Langit" value=" UKM Seni Tari">
                                                               UKM Seni Tari "Melati Sekar Langit"
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Cinta_Tanah_Air">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Cinta_Tanah_Air" value=" UKM Cinta Tanah Air">
                                                               UKM Cinta Tanah Air
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="FAI">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="FAI" value="FAI">
                                                               DPM Fakultas Agama islam (FAI)
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="FH">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="FH" value="FH">
                                                              DPM Fakultas Hukum (FH)
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="FP">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="FP" value="FP">
                                                               DPM Fakultas Pertanian (FP)
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="FAPET">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="FAPET" value="FAPET">
                                                               DPM Fakultas Peternakan (FAPET)
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="FT">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="FT" value="FT">
                                                               DPM Fakultas Teknik (FT)
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="FMIPA">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="FMIPA" value="FMIPA">
                                                              DPM Fakultas Matematika dan Ilmu Pengetahuan Alam (FMIPA)
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="FKIP">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="FKIP" value="FKIP">
                                                               DPM Fakultas Keguruan dan Ilmu Pendidikan (FKIP)
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="FIA">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="FIA" value="FIA">
                                                              DPM Fakultas Ilmu Administrasi (FIA)
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="FK">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="FK" value="FK">
                                                               DPM Fakultas Kedokteran (FK)
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="BEMFAI">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="BEMFAI" value="BEM Fakultas Agama Islam">
                                                               BEM Fakultas Agama Islam (FAI)
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="BEMFH">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="BEMFH" value="BEM Fakultas Hukum (FH)">
                                                            BEM Fakultas Hukum (FH)
                                                        <span></span>
                                                        </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="BEMFP">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="BEMFP" value="BEM Fakultas Pertanian (FP)">
                                                               BEM Fakultas Pertanian (FP)
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="BEMFAPET">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="BEMFAPET" value="BEM Fakultas Peternakan (FAPET)">
                                                               BEM Fakultas Peternakan (FAPET)
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="BEMFT">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="BEMFT" value="BEM Fakultas Teknik (FT)">
                                                               BEM Fakultas Teknik (FT)
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="BEMFMIPA">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="BEMFMIPA" value="BEM Fakultas Matematika dan Ilmu Pengetahuan Alam">
                                                               BEM Fakultas Matematika dan Ilmu Pengetahuan Alam (FMIPA)
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="FKIPBEM">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="FKIPBEM" value="BEM Fakultas Keguruan dan Ilmu Pendidikan (FKIP)">
                                                               BEM Fakultas Keguruan dan Ilmu Pendidikan (FKIP)
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="BEMFIA">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="BEMFIA" value="BEM Fakultas Ilmu Administrasi (FIA)">
                                                              BEM Fakultas Ilmu Administrasi (FIA)
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="BEMFK">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="BEMFK" value="BEM Fakultas Kedokteran (FK)">
                                                               BEM Fakultas Kedokteran (FK)
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="BSO">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="BSO" value="BSO (Badan Semi Ortonom)">
                                                               BSO (Badan Semi Ortonom)
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Agama_Islam">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Agama_Islam" value="Himaprodi Pend.Agama Islam">
                                                               Himaprodi Pend.Agama Islam
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="HukumIslam">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="HukumIslam" value="Himaprodi Hukum Islam">
                                                               Himaprodi Hukum Islam
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="PGMI">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="PGMI" value="Himaprodi PGMI">
                                                               Himaprodi PGMI
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="PGRA">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="PGRA" value="Himaprodi PGRA">
                                                             Himaprodi PGRA
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Ilmu Hukum">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Ilmu Hukum" value="Himaprodi Ilmu Hukum">
                                                            Himaprodi Ilmu Hukum
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Agroteknologi">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Agroteknologi" value="Himaprodi Agroteknologi">
                                                            Himaprodi Agroteknologi
                                                            <span></span>
                                                            </label>
                                                            <br>

                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="HimaprodiAgribisnis">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="HimaprodiAgribisnis" value="Himaprodi Agribisnis">
                                                               Himaprodi Agribisnis
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="HimaprodiPeternakan">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="HimaprodiPeternakan" value="Himaprodi Peternakan">
                                                               Himaprodi Peternakan
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="TeknikSipil">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="TeknikSipil" value="Himaprodi Teknik Sipil">
                                                              Himaprodi Teknik Sipil
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="TeknikMesin">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="TeknikMesin" value="Himaprodi Teknik Mesin">
                                                              Himaprodi Teknik Mesin
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="TeknikElektro">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="TeknikElektro" value="Himaprodi Teknik Elektro">
                                                               Himaprodi Teknik Elektro
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="HimaprodiBiologi">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="HimaprodiBiologi" value="Himaprodi Biologi">
                                                               Himaprodi Biologi
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="BahasadanSastraIndonesia">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="BahasadanSastraIndonesia" value="Himaprodi Pendidikan Bahasa dan Sastra Indonesia">
                                                              Himaprodi Pendidikan Bahasa dan Sastra Indonesia
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="PendidikanMatematika">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="PendidikanMatematika" value="Himaprodi Pendidikan Matematika">
                                                              Himaprodi Pendidikan Matematika
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Inggris">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Inggris" value="Himaprodi Pendidikan Bahasa Inggris">
                                                              Himaprodi Pendidikan Bahasa Inggris
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="Akuntansi">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="Akuntansi" value="Himaprodi Akuntansi">
                                                              Himaprodi Akuntansi
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="ManajemenHimaprodi">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="ManajemenHimaprodi" value="Himaprodi Manajemen">
                                                              Himaprodi Manajemen
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="PerbankanSyariah">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="PerbankanSyariah" value="Himaprodi Perbankan Syariah">
                                                             Himaprodi Perbankan Syariah
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="AdministrasiNegara">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="AdministrasiNegara" value="Himaprodi Ilmu Administrasi Negara">
                                                               Himaprodi Ilmu Administrasi Negara
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="AdministrasiNiaga">
                                                                <input class="form-check-input" type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="AdministrasiNiaga" value="Himaprodi Ilmu Administrasi Niaga">
                                                              Himaprodi Ilmu Administrasi Niaga
                                                            <span></span>
                                                            </label>
                                                            <br>
                                                            <label class="m-checkbox m-checkbox--solid m-checkbox--success" for="HimaprodiPendidikanDokter">
                                                                <input class="form-check-input " type="checkbox" name="organisasi_dalam_kemahasiswaan[]" id="HimaprodiPendidikanDokter" value="Himaprodi Pendidikan Dokter">
                                                              Himaprodi Pendidikan Dokter
                                                            <span></span>
                                                            </label>
                                                            <div align="right" style="margin-left:105px" style="z-index:5;">
                                                                <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_organisasi_kemahasiswaan" type="button" name="HimaprodiPendidikanDokter"><b>Clear Selection</b>

                                                                </button>
                                                            </div>
                                                        <br>



                                                    </div>

                                                </div>

                                            </div>


                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Kemukakan kedudukan Saudara sebagai pengurus kegiatan organisasi kemahasiswaan yang pernah Saudara ikuti:</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">

                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="kedudukansaudara">
                                                                <input type="radio" name="kedudukansaudara" id="kedudukansaudara" value="Sebagai ketua">
                                                            Sebagai ketua
                                                        <span></span>
                                                        </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="kedudukansaudara2">
                                                                <input type="radio" name="kedudukansaudara" id="kedudukansaudara2" value="Sebagai wakil ketua">
                                                            Sebagai wakil ketua
                                                        <span></span>
                                                        </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="kedudukansaudara3">
                                                                <input type="radio" name="kedudukansaudara" id="kedudukansaudara3" value="Sebagai sekretaris/bendahara">
                                                            Sebagai sekretaris/bendahara
                                                        <span></span>
                                                        </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="kedudukansaudara4">
                                                                <input type="radio" name="kedudukansaudara" id="kedudukansaudara4" value="Sebagai koordinator divisi/seksi">
                                                            Sebagai koordinator divisi/seksi
                                                        <span></span>
                                                        </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="kedudukansaudara5">
                                                                <input type="radio" name="kedudukansaudara" id="kedudukansaudara5" value="Sebagai Anggota">
                                                            Sebagai Anggota
                                                        <span></span>
                                                        </label>
                                                        </div>
                                                        <br>
                                                        <div align="right" style="margin-left:105px">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_kemukakan_kedudukan_saudara" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Berapa kali saudara menjadi panitia kegiatan organisasi kemahasiswaan pada saat kuliah di UNISMA</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">

                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="panitiakegiatan">
                                                                <input class="form-check-input " type="radio" name="panitiakegiatan" id="panitiakegiatan" value="> dari 3 kali">
                                                            > dari 3 kali
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="panitiakegiatan2">
                                                                <input class="form-check-input " type="radio" name="panitiakegiatan" id="panitiakegiatan2" value="3 kali">
                                                            3 kali
                                                            <span></span>
                                                            </label>
                                                            </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="panitiakegiatan3">
                                                                <input class="form-check-input " type="radio" name="panitiakegiatan" id="panitiakegiatan3" value="2 kali">
                                                           2 kali
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="panitiakegiatan4">
                                                                <input class="form-check-input " type="radio" name="panitiakegiatan" id="panitiakegiatan4" value="1 kali">
                                                            1 kali
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <br>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_kegiatan_organisasi_kemahasiswaan" type="button" name="HimaprodiPendidikanDokter"><b>Clear Selection</b>

                                                            </button>
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>


                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Apakah Saudara mengikuti organisasi kemahasiswaan berbasis ke NU an?</b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">


                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="organisasikemahasiswaanNU">
                                                                <input  type="radio" name="organisasikemahasiswaanNU" id="organisasikemahasiswaanNU" value="YA">
                                                            YA
                                                            <span></span>
                                                            </label>
                                                        </div>

                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="organisasikemahasiswaanNU2">
                                                                <input  type="radio" name="organisasikemahasiswaanNU" id="organisasikemahasiswaanNU2" value="Tidak">
                                                           Tidak
                                                           <span></span>
                                                            </label>
                                                        </div>
                                                        <br>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_kemahasiswaan_nu" type="button" name="HimaprodiPendidikanDokter"><b>Clear Selection</b>

                                                            </button>
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Jika YA </b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">


                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="organisasiNU">
                                                                <input type="radio" name="organisasiNU" id="organisasiNU" value="PMII">
                                                           PMII
                                                           <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="organisasiNU2">
                                                                <input type="radio" name="organisasiNU" id="organisasiNU2" value="IPNU/IPPNU">
                                                           IPNU/IPPNU
                                                           <span></span>
                                                            </label>
                                                        </div>
                                                         <div class="form-check">
                                                             <label class="m-radio m-radio--solid m-radio--success" for="organisasiNU3">
                                                                <input type="radio" name="organisasiNU" id="organisasiNU3" value="FATAYAT">
                                                           FATAYAT
                                                           <span></span>
                                                            </label>
                                                        </div>
                                                         <div class="form-check">
                                                             <label class="m-radio m-radio--solid m-radio--success" for="organisasiNU4">
                                                                <input type="radio" name="organisasiNU" id="organisasiNU4" value="ANSOR">
                                                           ANSOR
                                                           <span></span>
                                                            </label>
                                                        </div>
                                                         <div class="form-check">
                                                             <label class="m-radio m-radio--solid m-radio--success" for="organisasiNU5">
                                                                <input type="radio" name="organisasiNU" id="organisasiNU5" value="MUSLIMAT">
                                                           MUSLIMAT
                                                           <span></span>
                                                            </label>
                                                        </div>

                                                        <br>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_iya_nu" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Kemukakan kedudukan Saudara sebagai pengurus organisasi kemahasiswaan berbasis ke-Nu-an yang pernah Saudara ikuti:  </b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">


                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="kemukakankedudukanpengurusorganisasi">
                                                                <input type="radio" name="kemukakankedudukanpengurusorganisasi" id="kemukakankedudukanpengurusorganisasi" value="sebagai ketua">
                                                            sebagai ketua
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="kemukakankedudukanpengurusorganisasi2">
                                                                <input type="radio" name="kemukakankedudukanpengurusorganisasi" id="kemukakankedudukanpengurusorganisasi2" value="sebagai wakil ketua">
                                                            sebagai wakil ketua
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="kemukakankedudukanpengurusorganisasi3">
                                                                <input type="radio" name="kemukakankedudukanpengurusorganisasi" id="kemukakankedudukanpengurusorganisasi3" value="sebagai sekretaris/bendahara">
                                                            sebagai sekretaris/bendahara
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="kemukakankedudukanpengurusorganisasi4">
                                                                <input type="radio" name="kemukakankedudukanpengurusorganisasi" id="kemukakankedudukanpengurusorganisasi4" value="sebagai koordinator divisi/seksi">
                                                            sebagai koordinator divisi/seksi
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="kemukakankedudukanpengurusorganisasi5">
                                                                <input type="radio" name="kemukakankedudukanpengurusorganisasi" id="kemukakankedudukanpengurusorganisasi5" value="sebagai anggota">
                                                            sebagai anggota
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_kemukakankedudukanpengurusorganisasi" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="m-portlet m-portlet--creative m-portlet--bordered-semi" style="margin-top: 0.5rem;">
                                    <div class="m-portlet__head">
                                        <div class="m-portlet__head-caption">
                                            <div class="m-portlet__head-title">
                                                <span class="m-portlet__head-icon m--hide">
                                                    <i class="flaticon-statistics"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="m-portlet__head-tools">

                                        </div>
                                    </div>
                                    <div class="m-portlet__body" style="margin-top: -40px">

                                        <div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" style="margin-top: -20px">
                                            <div class="m-portlet__body">
                                                <b>Berapa kali Saudara menjadi panitia dalam organisasi kemahasiswaan berbasis Ke-NU-an:  </b>

                                                <div class="form-group m-form__group row" style="margin-left: -40px">
                                                    <div class="col-lg-12">


                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="BerapakaliSaudaramenjadipanitiadalamorganisasi">
                                                                <input type="radio" name="BerapakaliSaudaramenjadipanitiadalamorganisasi" id="BerapakaliSaudaramenjadipanitiadalamorganisasi" value="> dari 3 kali">
                                                            > dari 3 kali
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="BerapakaliSaudaramenjadipanitiadalamorganisasi2">
                                                                <input type="radio" name="BerapakaliSaudaramenjadipanitiadalamorganisasi" id="BerapakaliSaudaramenjadipanitiadalamorganisasi2" value="3 kali">
                                                            3 kali
                                                            <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="BerapakaliSaudaramenjadipanitiadalamorganisasi3">
                                                                <input type="radio" name="BerapakaliSaudaramenjadipanitiadalamorganisasi" id="BerapakaliSaudaramenjadipanitiadalamorganisasi3" value="2 kali">
                                                           2 kali
                                                           <span></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <label class="m-radio m-radio--solid m-radio--success" for="BerapakaliSaudaramenjadipanitiadalamorganisasi4">
                                                                <input type="radio" name="BerapakaliSaudaramenjadipanitiadalamorganisasi" id="BerapakaliSaudaramenjadipanitiadalamorganisasi4" value="1 kali">
                                                           1 kali
                                                           <span></span>
                                                            </label>
                                                        </div>
                                                        <br>
                                                        <div align="right">
                                                            <button style="background-color:white;color:#97c197" class="btn waves-effect waves-light" id="reset_BerapakaliSaudaramenjadipanitiadalamorganisasi" type="button"><b>Clear Selection</b>

                                                            </button>
                                                        </div>
                                                        <br>

                                                        <div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
                                                            <div class="m-form__actions m-form__actions--solid" style="padding: 10px;">
                                                                <div class="row">
                                                                    <div class="col-lg-6">

                                                                    </div>
                                                                    <div class="col-lg-6 m--align-right">

                                                                        <button type="submit" class="btn btn-success">Submit Tracer</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>




                        </div>

                    </div>

				</div>
			</div>

			<footer class="m-grid__item		m-footer " style="margin-left:0px">
				<div class="m-container m-container--fluid m-container--full-height m-page__container">
					<div class="m-stack m-stack--flex-tablet-and-mobile m-stack--ver m-stack--desktop">
						<div class="m-stack__item m-stack__item--left m-stack__item--middle m-stack__item--last">
							<span class="m-footer__copyright">
								2020 &copy; sistem Tracer Study by <a href="https://keenthemes.com" class="m-link">UNISMA</a>
							</span>
						</div>

					</div>
				</>
            </footer>
            <div class="modal fade" id="m_modal_6" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">

                    <div class="modal-content">
                        <div class="modal-header" style="padding:11px">
                            <h5 class="modal-title">Detail Data Alumni</h5>

                          </div>

                        <div class="modal-body">
                            <div class="m-portlet m-portlet--full-height " style="background-color: transparant">

                                <div class="m-portlet__body" style="background-color: transparant">
                                    <div class="m-widget13" style="background-color: transparant">
                                        <div class="m-widget13__item">
                                            <span class="m-widget13__desc m--align-right">
                                                NPM
                                            </span>
                                            <span class="m-widget13__text">
                                                {{$data_mhs->npm}}
                                            </span>
                                        </div>
                                        <div class="m-widget13__item">
                                            <span class="m-widget13__desc m--align-right">
                                               Nama Alumni:
                                            </span>
                                            <span class="m-widget13__text">
                                                {{$data_mhs->nama}}
                                            </span>
                                        </div>
                                        <div class="m-widget13__item">
                                            <span class="m-widget13__desc m--align-right">
                                               Tahun lulus:
                                            </span>
                                            <span class="m-widget13__text">
                                                {{$data_mhs->tahun_lulus}}
                                            </span>
                                        </div>

                                        <div class="m-widget13__item">
                                            <span class="m-widget13__desc m--align-right">
                                               Kode PT:
                                            </span>
                                            <span class="m-widget13__text m-widget13__number-bolder m--font-brand">
                                                {{$data_mhs->kode_pt}}
                                            </span>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer" style="margin-top: -35px">
                            <button id="m_aside_header_topbar_mobile_toggle" type="button" class="btn btn-danger m-brand__icon m--visible-tablet-and-mobile-inline-block" data-dismiss="modal">Close</button>

                        </div>
                    </div>
                </div>
            </div>

			<!-- end::Footer -->
        </div>


		<!-- end:: Page -->

		<!-- begin::Quick Sidebar -->


		<!-- end::Quick Sidebar -->

		<!-- begin::Scroll Top -->
		<div id="m_scroll_top" class="m-scroll-top">
			<i class="la la-arrow-up"></i>
		</>

		<!-- end::Scroll Top -->

		<!-- begin::Quick Nav -->

		<!-- begin::Quick Nav -->

		<!--begin:: Global Mandatory Vendors -->
		<script src="../public/vendors/jquery/dist/jquery.js" type="text/javascript"></script>
		<script src="../public/vendors/popper.js/dist/umd/popper.js" type="text/javascript"></script>
		<script src="../public/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
		<script src="../public/vendors/js-cookie/src/js.cookie.js" type="text/javascript"></script>
		<script src="../public/vendors/moment/min/moment.min.js" type="text/javascript"></script>
		<script src="../public/vendors/tooltip.js/dist/umd/tooltip.min.js" type="text/javascript"></script>
		<script src="../public/vendors/perfect-scrollbar/dist/perfect-scrollbar.js" type="text/javascript"></script>
		<script src="../public/vendors/wnumb/wNumb.js" type="text/javascript"></script>

		<!--end:: Global Mandatory ../public/Vendors -->

		<!--begin:: Global Optional ../public/Vendors -->
		<script src="../public/vendors/jquery.repeater/src/lib.js" type="text/javascript"></script>
		<script src="../public/vendors/jquery.repeater/src/jquery.input.js" type="text/javascript"></script>
		<script src="../public/vendors/jquery.repeater/src/repeater.js" type="text/javascript"></script>
		<script src="../public/vendors/jquery-form/dist/jquery.form.min.js" type="text/javascript"></script>
		<script src="../public/vendors/block-ui/jquery.blockUI.js" type="text/javascript"></script>
		<script src="../public/vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
		<script src="../public/vendors/js/framework/components/plugins/forms/bootstrap-datepicker.init.js" type="text/javascript"></script>
		<script src="../public/vendors/bootstrap-datetime-picker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
		<script src="../public/vendors/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript"></script>
		<script src="../public/vendors/js/framework/components/plugins/forms/bootstrap-timepicker.init.js" type="text/javascript"></script>
		<script src="../public/vendors/bootstrap-daterangepicker/daterangepicker.js" type="text/javascript"></script>
		<script src="../public/vendors/js/framework/components/plugins/forms/bootstrap-daterangepicker.init.js" type="text/javascript"></script>
		<script src="../public/vendors/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.js" type="text/javascript"></script>
		<script src="../public/vendors/bootstrap-maxlength/src/bootstrap-maxlength.js" type="text/javascript"></script>
		<script src="../public/vendors/bootstrap-switch/dist/js/bootstrap-switch.js" type="text/javascript"></script>
		<script src="../public/vendors/js/framework/components/plugins/forms/bootstrap-switch.init.js" type="text/javascript"></script>
		<script src="../public/vendors/vendors/bootstrap-multiselectsplitter/bootstrap-multiselectsplitter.min.js" type="text/javascript"></script>
		<script src="../public/vendors/bootstrap-select/dist/js/bootstrap-select.js" type="text/javascript"></script>
		<script src="../public/vendors/select2/dist/js/select2.full.js" type="text/javascript"></script>
		<script src="../public/vendors/typeahead.js/dist/typeahead.bundle.js" type="text/javascript"></script>
		<script src="../public/vendors/handlebars/dist/handlebars.js" type="text/javascript"></script>
		<script src="../public/vendors/inputmask/dist/jquery.inputmask.bundle.js" type="text/javascript"></script>
		<script src="../public/vendors/inputmask/dist/inputmask/inputmask.date.extensions.js" type="text/javascript"></script>
		<script src="../public/vendors/inputmask/dist/inputmask/inputmask.numeric.extensions.js" type="text/javascript"></script>
		<script src="../public/vendors/inputmask/dist/inputmask/inputmask.phone.extensions.js" type="text/javascript"></script>
		<script src="../public/vendors/nouislider/distribute/nouislider.js" type="text/javascript"></script>
		<script src="../public/vendors/owl.carousel/dist/owl.carousel.js" type="text/javascript"></script>
		<script src="../public/vendors/autosize/dist/autosize.js" type="text/javascript"></script>
		<script src="../public/vendors/clipboard/dist/clipboard.min.js" type="text/javascript"></script>
		<script src="../public/vendors/ion-rangeslider/js/ion.rangeSlider.js" type="text/javascript"></script>
		<script src="../public/vendors/dropzone/dist/dropzone.js" type="text/javascript"></script>
		<script src="../public/vendors/summernote/dist/summernote.js" type="text/javascript"></script>
		<script src="../public/vendors/markdown/lib/markdown.js" type="text/javascript"></script>
		<script src="../public/vendors/bootstrap-markdown/js/bootstrap-markdown.js" type="text/javascript"></script>
		<script src="../public/vendors/js/framework/components/plugins/forms/bootstrap-markdown.init.js" type="text/javascript"></script>
		<script src="../public/vendors/jquery-validation/dist/jquery.validate.js" type="text/javascript"></script>
		<script src="../public/vendors/jquery-validation/dist/additional-methods.js" type="text/javascript"></script>
		<script src="../public/vendors/js/framework/components/plugins/forms/jquery-validation.init.js" type="text/javascript"></script>
		<script src="../public/vendors/bootstrap-notify/bootstrap-notify.min.js" type="text/javascript"></script>
		<script src="../public/vendors/js/framework/components/plugins/base/bootstrap-notify.init.js" type="text/javascript"></script>
		<script src="../public/vendors/toastr/build/toastr.min.js" type="text/javascript"></script>
		<script src="../public/vendors/jstree/dist/jstree.js" type="text/javascript"></script>
		<script src="../public/vendors/raphael/raphael.js" type="text/javascript"></script>
		<script src="../public/vendors/morris.js/morris.js" type="text/javascript"></script>
		<script src="../public/vendors/chartist/dist/chartist.js" type="text/javascript"></script>
		<script src="../public/vendors/chart.js/dist/Chart.bundle.js" type="text/javascript"></script>
		<script src="../public/vendors/js/framework/components/plugins/charts/chart.init.js" type="text/javascript"></script>
		<script src="../public/vendors/vendors/bootstrap-session-timeout/dist/bootstrap-session-timeout.min.js" type="text/javascript"></script>
		<script src="../public/vendors/vendors/jquery-idletimer/idle-timer.min.js" type="text/javascript"></script>
		<script src="../public/vendors/waypoints/lib/jquery.waypoints.js" type="text/javascript"></script>
		<script src="../public/vendors/counterup/jquery.counterup.js" type="text/javascript"></script>
		<script src="../public/vendors/es6-promise-polyfill/promise.min.js" type="text/javascript"></script>
		<script src="../public/vendors/sweetalert2/dist/sweetalert2.min.js" type="text/javascript"></script>
        <script src="../public/vendors/js/framework/components/plugins/base/sweetalert2.init.js" type="text/javascript"></script>
        <script src="../public/assets/vendors/custom/datatables/datatables.bundle.js" type="text/javascript"></script>
        <script src="../public/assets/demo/custom/crud/datatables/basic/basic.js" type="text/javascript"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.12/js/select2.full.min.js"></script>
        <script src="../public/assets/demo/custom/crud/forms/widgets/summernote.js" type="text/javascript"></script>
        <script src="../public/assets/demo/custom/crud/forms/widgets/bootstrap-datetimepicker.js" type="text/javascript"></script>
		<!--end:: Global Optional Vendors -->
        <script src="../public/assets/demo/custom/components/base/blockui.js" type="text/javascript"></script>
		<!--begin::Global Theme Bundle -->
		<script src="../public/assets/demo/base/scripts.bundle.js" type="text/javascript"></script>

		<!--end::Global Theme Bundle -->

		<!--begin::Page Vendors -->
        <script src="../public/assets/vendors/custom/fullcalendar/fullcalendar.bundle.js" type="text/javascript"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/locale/id.min.js" type="text/javascript"></script>

		<!--end::Page Vendors -->

		<!--begin::Page Scripts -->
		<script src="../public/assets/app/js/dashboard.js" type="text/javascript"></script>
        <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
            <script src="https://cdn.datatables.net/fixedcolumns/3.3.2/js/dataTables.fixedColumns.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/cleave.js@1.5.3/dist/cleave.min.js"></script>
            <script src="https://unpkg.com/sweetalert@2.1.0/dist/sweetalert.min.js"></script>

        <script>
            const form = document.querySelector('#survey-form');

            // listen to the 'submit' event on the form
            form.addEventListener('submit', evt => {
            // prevent the submit event
            evt.preventDefault();

            // display an alert
            swal('Submit Tracer Study?', {
                buttons: true
            }).then(val => {
                // when the promise resolves,
                // check the value that was passed
                if (val) {
                // if the value is true,
                // actually submit the form
                form.submit();
                }
            });
            })

            document.querySelectorAll('.loan_max_amount').forEach(inp => new Cleave(inp, {
                numeral: true,
                numeralThousandsGroupStyle: 'thousand'
              }));
            function isNumberKey(evt)
            {
                var charCode = (evt.which) ? evt.which : event.keyCode
                if (charCode > 31 && (charCode < 48 || charCode > 57))
                    return false;

                return true;
            }
            $(document).ready(function(){
                $('div.checkbox-group.required :checkbox:checked').length > 0;
                $('#click_alumni').click(function(){
                    var isi_alumni = '<hr><table border=0>'+ '<tr><td style="text-align: left;">NPM</td><td>:</td><td style="text-align: left;"><b>&nbsp{{$data_mhs->npm}}</b></td></tr>'+ '<tr><td style="text-align: left;">Nama</td><td>:</td><td>&nbsp<b>{{$data_mhs->nama}}</b></td></tr>' + '<tr><td style="text-align: left;">Tahun lulus</td><td>:</td><td style="text-align: left;">&nbsp<b>{{$data_mhs->tahun_lulus}}</b></td></tr>'+ '<tr><td style="text-align: left;">Kode PT</td><td>:</td><td style="text-align: left;">&nbsp<b>{{$data_mhs->kode_pt}}</b></td></tr>' +'</table>'
                    Swal.fire({
                        title: "Data Alumni<hr>",
                        html:  isi_alumni,
                        confirmButtonText: "OK",
                      });
                });
                $('#click_alumni2').click(function(){
                    var isi_alumni = '<hr><table border=0>'+ '<tr><td style="text-align: left;">NPM</td><td>:</td><td style="text-align: left;"><b>&nbsp{{$data_mhs->npm}}</b></td></tr>'+ '<tr><td style="text-align: left;">Nama</td><td>:</td><td>&nbsp<b>{{$data_mhs->nama}}</b></td></tr>' + '<tr><td style="text-align: left;">Tahun lulus</td><td>:</td><td style="text-align: left;">&nbsp<b>{{$data_mhs->tahun_lulus}}</b></td></tr>'+ '<tr><td style="text-align: left;">Kode PT</td><td>:</td><td style="text-align: left;">&nbsp<b>{{$data_mhs->kode_pt}}</b></td></tr>' +'</table>'
                    Swal.fire({
                        title: "Data Alumni<hr>",
                        html:  isi_alumni,
                        confirmButtonText: "OK",
                      });
                });

                function IsEmail(email) {
                    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                    if(!regex.test(email)) {
                      return false;
                    }else{
                      return true;
                    }
                  }

                $('form').submit(function() {
                    $(window).unbind('beforeunload');
                  });

                  $(window).on('beforeunload', function(){
                    return 'Are you sure you want to leave?';
                    });


            $("#pertanyaan22").change(function(event){
                event.preventDefault();
                $('input[name ="pertanyaanf3_input_sebelum"]').prop("disabled", false);
                $('input[name ="pertanyaanf3_input_setelah"]').prop("disabled", true);
                $('input[name ="pertanyaanf3_input_setelah"]').val('');
            });
            $("#pertanyaan90").change(function(event){
                event.preventDefault();
                $('input[name ="pertanyaanf3_input_setelah"]').prop("disabled", false);
                $('input[name ="pertanyaanf3_input_sebelum"]').val('');
                $('input[name ="pertanyaanf3_input_sebelum"]').prop("disabled", true);
            });
            $("#pertanyaan222").change(function(event){
                event.preventDefault();
                $('input[name ="pertanyaanf3_input_setelah"]').prop("disabled", true);
                $('input[name ="pertanyaanf3_input_sebelum"]').val('');
                $('input[name ="pertanyaanf3_input_setelah"]').val('');
                $('input[name ="pertanyaanf3_input_sebelum"]').prop("disabled", true);
            });

            $("#pertanyaanf51").change(function(event){
                event.preventDefault();
                $('input[name ="pertanyaanf5input"]').prop("disabled", false);
                $('input[name ="pertanyaanf5input2"]').val('');
                $('input[name ="pertanyaanf5input2"]').prop("disabled", true);


            });
            $("#pertanyaanf52").change(function(event){
                event.preventDefault();
                $('input[name ="pertanyaanf5input2"]').prop("disabled", false);
                $('input[name ="pertanyaanf5input"]').prop("disabled", true);
                $('input[name ="pertanyaanf5input"]').val('');


            });


                $('.isi_quisioner').fadeOut();
                $('.berikutnya').click(function(){
                    if($('input[name ="email"]').val() == '' || $('input[name ="jeniskelamin"]').value == '' || $('input[name ="no_whatsapp"]').val() == '' || $('input[name ="alamat"]').val() == ''){
                        swal({
                            title: "Peringatan!",
                            text: "Lengkapi data Anda terlebih dahulu, untuk mengisi quisioner alumni !",

                            button: "OKE",
                        });
                    }else if(IsEmail($('input[name ="email"]').val())==false){
                        swal({
                            title: "Peringatan!",
                            text: "Format email yang anda masukkan salah !",

                            button: "OKE",
                        });
                    }else{
                        $('.isi_biodata').hide();
                        $('.isi_quisioner').fadeIn();
                    }


                });



                $('#reset_organisasi_kemahasiswaan').click(function() {
                    $('input[name="organisasi_dalam_kemahasiswaan[]"]').prop('checked', false);



                });

                $('#reset_kemukakan_kedudukan_saudara').click(function() {
                    $('input[name="kedudukansaudara"]').prop('checked', false);
                });

                $('#reset_kegiatan_organisasi_kemahasiswaan').click(function() {
                    $('input[name="panitiakegiatan"]').prop('checked', false);
                });

                $('#reset_kemahasiswaan_nu').click(function() {
                    $('input[name="organisasikemahasiswaanNU"]').prop('checked', false);
                });

                $('#reset_iya_nu').click(function() {
                    $('input[name="organisasiNU"]').prop('checked', false);
                });

                $('#reset_kemukakankedudukanpengurusorganisasi').click(function() {
                    $('input[name="kemukakankedudukanpengurusorganisasi"]').prop('checked', false);
                });

                $('#reset_kemukakankedudukanpanitiaorganisasi').click(function() {
                    $('input[name="kemukakankedudukanpanitiaorganisasi"]').prop('checked', false);
                });

                $('#reset_BerapakaliSaudaramenjadipanitiadalamorganisasi').click(function() {
                    $('input[name="BerapakaliSaudaramenjadipanitiadalamorganisasi"]').prop('checked', false);
                });

                $('#reset_penekanan_pada_metode_pembelajaran').click(function() {
                    $('input[name="kuliah"]').prop('checked', false);
                    $('input[name="responsi"]').prop('checked', false);
                    $('input[name="seminar"]').prop('checked', false);
                    $('input[name="praktikum"]').prop('checked', false);
                    $('input[name="praktek_lapangan"]').prop('checked', false);
                    $('input[name="penelitian"]').prop('checked', false);
                    $('input[name="pelatihan_militer"]').prop('checked', false);
                    $('input[name="pertukaran_pelajar"]').prop('checked', false);
                    $('input[name="magang"]').prop('checked', false);
                    $('input[name="wirausaha"]').prop('checked', false);
                    $('input[name="pengabdian"]').prop('checked', false);
                });

                $('#reset_mulai_mencari_pekerjaan').click(function() {
                    $('input[name="pertanyaan_f3"]').prop('checked', false);
                    $('input[name="pertanyaanf3_input_sebelum"]').val('');
                    $('input[name="pertanyaanf3_input_setelah"]').val('');

                });

                $('#reset_mencari_pekerjaan').click(function() {
                    $('input[name="pertanyaanf4_iklan"]').prop('checked', false);
                    $('input[name="pertanyaanf4_melamar"]').prop('checked', false);
                    $('input[name="pertanyaanf4_pergi"]').prop('checked', false);
                    $('input[name="pertanyaanf4_mencari"]').prop('checked', false);
                    $('input[name="pertanyaanf4_dihubungi"]').prop('checked', false);
                    $('input[name="pertanyaanf4_menghubungi_kemenakertrans"]').prop('checked', false);
                    $('input[name="pertanyaanf4_memeroleh"]').prop('checked', false);
                    $('input[name="pertanyaanf4_menghubungi_kantor"]').prop('checked', false);
                    $('input[name="pertanyaanf4_membangun_jejaring"]').prop('checked', false);
                    $('input[name="pertanyaanf4_melalui"]').prop('checked', false);
                    $('input[name="pertanyaanf4_membangun_bisnis"]').prop('checked', false);
                    $('input[name="pertanyaanf4_melalui_magang"]').prop('checked', false);
                    $('input[name="pertanyaanf4_bekerja_tempat_sama"]').prop('checked', false);
                    $('input[name="pertanyaanf4_lainnya"]').prop('checked', false);
                });

                $('#reset_bulan_untuk_mencari_pekerjaan').click(function() {
                    $('input[name="pertanyaan2_f5"]').prop('checked', false);
                    $('input[name="pertanyaanf5input"]').val('');
                    $('input[name="pertanyaanf5input2"]').val('');
                    $('input[name ="pertanyaanf5input2"]').prop("disabled", true);
                $('input[name ="pertanyaanf5input"]').prop("disabled", true);
                });

                $('#reset_perusahaan_yang_sudah_anda_lamar_lewat_email').click(function() {
                    $('input[name="pertanyaanf6"]').val('');
                });

                $('#reset_perusahaan_merespon').click(function() {
                    $('input[name="pertanyaanf7"]').val('');
                });

                $('#reset_perusahaan_yang_mengundang_anda').click(function() {
                    $('input[name="pertanyaanf7a"]').val('');
                });

                $('#reset_perusahaan_tempat_bekerja').click(function() {
                    $('input[name="perusahaan_tempat_bekerja"]').val('');
                });

                $('#reset_alamat_tempat_bekerja').click(function() {
                    $('input[name="alamat_tempat_bekerja"]').val('');
                });

                $('#reset_no_telp_perusahaan').click(function() {
                    $('input[name="no_telp_perusahaan"]').val('');
                });

                $('#reset_anda_bekerja_saat_ini').click(function() {
                    $('input[name="pertanyaanf8"]').prop('checked', false);
                });

                $('#reset_menggambarkan_situasi_anda').click(function() {
                    $('input[name="pertanyaanf9_belajar"]').prop('checked', false);
                    $('input[name="pertanyaanf9_menikah"]').prop('checked', false);
                    $('input[name="pertanyaanf9_sibuk_keluarga"]').prop('checked', false);
                    $('input[name="pertanyaanf9_sedang_mencari_pekerjaan"]').prop('checked', false);
                    $('input[name="pertanyaanf9_lainnya"]').prop('checked', false);
                });

                $('#reset_pekerjaan_dalam_4minggu').click(function() {
                    $('input[name="pertanyaanf10"]').prop('checked', false);

                });

                $('#reset_nama_atasan_langsung').click(function() {
                    $('input[name="nama_atasan_langsung"]').val('');
                });

                 $('#reset_nohp_atasan_langsung').click(function() {
                    $('input[name="no_hp_atasan"]').val('');
                });

                $('#reset_jenis_perusahaan_tempat_bekerja').click(function() {
                    $('input[name="wiraswastaijintidakberijin_ijin"]').prop('checked', false);
                    $('input[name="wiraswastaijintidakberijin_tidakijin"]').prop('checked', false);
                    $('input[name="wiraswastaijintidakberijin_lokal"]').prop('checked', false);
                    $('input[name="wiraswastaijintidakberijin_nasional"]').prop('checked', false);
                    $('input[name="wiraswastaijintidakberijin_internasional"]').prop('checked', false);
                });

                $('#reset_pendapatan_setiap_bulannya').click(function() {
                    $('input[name="pekerjaan_utama"]').val('');
                    $('input[name="lembur_tips"]').val('');
                    $('input[name="pekerjaan_lainnya"]').val('');
                });

                $('#reset_Seberapaerathubunganantarabidangstudi').click(function() {
                    $('input[name="pertanyaanf14"]').prop('checked', false);

                });
                $('#reset_pembiayaan').click(function() {
                    $('input[name="pertanyaanf14"]').prop('checked', false);

                });

                $('#reset_tingkat_pendidikan_yang_tepat').click(function() {
                    $('input[name="pertanyaanf15"]').prop('checked', false);

                });

                $('#reset_tingkat_pendidikan_yang_tepat2').click(function() {
                    $('input[name="pertanyaanf16_pertanyaan_tidak_sesuai"]').prop('checked', false);
                    $('input[name="pertanyaanf16_Saya_belum_mendapatkan_pekerjaan_yang_lebih_sesuai"]').prop('checked', false);
                    $('input[name="pertanyaanf16_di_pekerjaan_ini_saya_memeroleh_prospek_karir_yang_baik"]').prop('checked', false);
                    $('input[name="pertanyaanf16_saya_lebih_suka_bekerja_di_area_pekerjaan"]').prop('checked', false);
                    $('input[name="pertanyaanf16_saya_dipromosikan_ke_posisi_yang_kurang"]').prop('checked', false);

                    $('input[name="pertanyaanf16_Saya_dapat_memeroleh_pendapatan"]').prop('checked', false);
                    $('input[name="pertanyaanf16_Pekerjaan_saya_saat_ini_lebih_aman_terjamin_secure"]').prop('checked', false);
                    $('input[name="pertanyaanf16_Pekerjaan_saya_saat_ini_lebih_menarik"]').prop('checked', false);
                    $('input[name="pertanyaanf16_Pekerjaan_saya_saat_ini_lebih_memungkinkan"]').prop('checked', false);
                    $('input[name="pertanyaanf16_Pekerjaan_saya_saat_ini_lokasinya_lebih_dekat"]').prop('checked', false);

                    $('input[name="pertanyaanf16_Pekerjaan_saya_saat_ini_dapat_lebih"]').prop('checked', false);
                    $('input[name="pertanyaanf16_Pada_awal_meniti_karir_ini"]').prop('checked', false);
                    $('input[name="pertanyaanf16_Lainnya"]').prop('checked', false);
                });

            });

        </script>
