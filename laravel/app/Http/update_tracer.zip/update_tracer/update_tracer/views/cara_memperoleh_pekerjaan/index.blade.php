@extends('template')
@section('konten')
<head>
    <link href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
</head>

<div class="m-portlet">
    <div class="m-portlet__head">
        <div class="m-portlet__head-caption">
            <div class="m-portlet__head-title">
                <h3 class="m-portlet__head-text">
                    Cara Memperoleh Pekerjaan
                </h3>
            </div>
        </div>
    </div>
    <div class="m-portlet__body">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active show" data-toggle="tab" href="#m_tabs_1_3"><i class="flaticon-edit-1"></i>
                    Data Tracer Alumni</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#" data-target="#m_tabs_1_1"><i class="flaticon-analytics"></i>
                    Grafik</a>
            </li>



        </ul>

        <div class="tab-content">
            <div class="tab-pane" id="m_tabs_1_1" role="tabpanel">
                <div class="col-md-12">
                    <div id="chart_cara_memperoleh_pekerjaan"></div>
                </div>
            </div>

            <div class="tab-pane active show" id="m_tabs_1_3" role="tabpanel">
                <div class="row">
                    <div class="col-md-9">
                        <div class="m-alert m-alert--icon m-alert--air alert alert-dismissible fade show" role="alert" style="background-color: #95a57e36">
                            <div class="m-alert__icon">
                                <i class="la 
                                la-question
                                 "></i>
                            </div>
                            <div class="m-alert__text">
                                <strong>Pertanyaan : </strong>
                                                    
                            F4. Bagaimana anda mencari pekerjaan tersebut? Jawaban bisa lebih dari satu
                            </div>
                           
                        </div>
                    </div>
                    <div class="col-md-3 text-right">
                        <a href="{{url('export_cara_memperoleh_pekerjaan')}}" class="btn btn-success m-btn m-btn--custom m-btn--icon">
                            <span>
                                <i class="la la-file-excel-o"></i>
                                <span>Export Excell</span>
                            </span>
                        </a>
                    </div>
                </div>
               
            <br>
                <table cellpadding="0" class="table-striped tabel_show table table-bordered nowrap" cellspacing="0" width="100%">

                    <thead style="background-image: url('https://www.transparenttextures.com/patterns/sos.png');background-color: #349d44;color: #e5f6dd;">
                        <tr>
                            <th style="5%">No.</th>
                            <th style="15%">NPM</th>
                            <th style="25%">Nama</th>
                            <th style="25%">Prodi</th>
                            <th style="15%">Tahun lulus</th>
                            <th style="15%">melalui iklan</th>
                            <th style="25%">melamar keperusahaan</th>
                            <th style="25%">pergi kebursa</th>
                            <th style="25%">mencari lewat internet</th>
                            <th style="25%">dihubungi oleh perusahaan</th>
                            <th style="25%">menghubungi kemenakertrans</th>
                            <th style="25%">memeroleh informasi dari pusat</th>
                            <th style="25%">menghubungi kantor kemahasiswaan</th>
                            <th style="25%">membangun jejaring</th>
                            <th style="25%">melalui relasi</th>
                            <th style="25%">membangun bisnis sendiri</th>
                            <th style="25%">melalui penempatan kerja magang</th>
                            <th style="25%">bekerja ditempat yang sama</th>
                            <th style="25%">lainnya</th>
                            <th style="15%">Created</th>

                        </tr>
                    </thead>

                </table>
            </div>

        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
<script src ="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
<script src="https://code.highcharts.com/highcharts.src.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script>

    $(document).ready(function(){

        $.ajax({
            url: "{{url('graph-cara-memperoleh-pekerjaan')}}",
            type: 'GET',
            dataType: 'JSON',
            success:function(response){

            Highcharts.chart('chart_cara_memperoleh_pekerjaan', {
                chart: {
                    type: 'bar'
                },
                title: {
                    text: 'Cara Memperoleh Pekerjaan'
                },
                subtitle: {
                    text: 'Source: <a href="">http://localhost/quisioner_alumni/public/</a>'
                },
                xAxis: {
                    categories: ['Melalui iklan di koran/majalah, brosur ',
                                'Melamar ke perusahaan tanpa mengetahui lowongan yang ada',
                                'Pergi ke bursa/pameran kerja',
                                ' Mencari lewat internet/iklan online/milis ',
                                'dihubungi oleh perusahaan',
                                'menghubungi kemenakertrans',
                                'Memeroleh informasi dari pusat/kantor pengembangan karir fakultas/universitas',
                                'Menghubungi kantor kemahasiswaan/hubungan alumni',
                                'Membangun jejaring (network) sejak masih kuliah',
                                'Melalui relasi (misalnya dosen, orang tua, saudara, teman, dll.)',
                                'Membangun bisnis sendiri',
                                'Melalui penempatan kerja atau magang',
                                'Bekerja di tempat yang sama dengan tempat kerja semasa kuliah',
                                'lainnya'
                                ],
                    title: {
                        text: null
                    }
                },


                yAxis: {
                    min: 0,
                    title: {
                        text: 'Total ',
                        align: 'high'
                    },
                    labels: {
                        overflow: 'justify'
                    }
                },
                tooltip: {
                    valueSuffix: ' Data'
                },
                plotOptions: {
                    bar: {
                        dataLabels: {
                            enabled: true
                        }
                    }
                },
                legend: {
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'top',
                    x: -40,
                    y: 80,
                    floating: true,
                    borderWidth: 1,
                    backgroundColor:
                        Highcharts.defaultOptions.legend.backgroundColor || '#FFFFFF',
                    shadow: true
                },
                credits: {
                    enabled: false
                },
                series: [{
                    data: [
                        {y:response.melalui_iklan[0], color:'#0074D9'},
                        {y:response.melamar_keperusahaan[0], color:'#39CCCC'},
                        {y:response.pergi_kebursa[0], color:'#B10DC9'},
                        {y:response.mencari_lewat_internet[0], color:'#AAAAAA'},
                        {y:response.dihubungi_oleh_perusahaan[0], color:'#FFDC00'},
                        {y:response.menghubungi_kemenakertrans[0], color:'#01FF70'},
                        {y:response.memeroleh_informasi_dari_pusat[0], color:'#2ECC40'},
                        {y:response.menghubungi_kantor_kemahasiswaan[0], color:'#85144b'},
                        {y:response.membangun_jejaring[0], color:'#FF4136'},
                        {y:response.melalui_relasi[0], color:'#FF851B'},
                        {y:response.membangun_bisnis_sendiri[0], color:'#001f3f'},
                        {y:response.melalui_penempatan_kerja_magang[0], color:'#7FDBFF'},
                        {y:response.bekerja_ditempat_yang_sama[0], color:'#F012BE'},
                        {y:response.lainnya[0], color:'#DDDDDD'},


                    ],
                    showInLegend: true
                  }]

                });
            }
        });

        var table_evaluasi_pegawai = $('.tabel_show').DataTable({
            responsive:true,
            paging: true,
            info: true,
            searching: true,
            "aaSorting": [],
            "ordering": true,

            ajax: {
                url: '{{url("datatable-cara-memperoleh-pekerjaan")}}',
                dataSrc: 'result',
            },
            scrollX:        true,

            autoWidth:         true,

        });

    });

</script>
@endsection
