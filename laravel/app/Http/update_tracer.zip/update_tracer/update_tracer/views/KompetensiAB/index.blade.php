@extends('template')
@section('konten')
<head>
    <link href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
</head>
<div class="m-portlet">
    <div class="m-portlet__head">
        <div class="m-portlet__head-caption">
            <div class="m-portlet__head-title">
                <h3 class="m-portlet__head-text">
                  Kompetensi A & B
                </h3>
            </div>
        </div>
    </div>
    <div class="m-portlet__body">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active show" data-toggle="tab" href="#m_tabs_1_3"><i class="flaticon-edit-1"></i>
                    Data Kompetensi A</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#m_tabs_1_2"><i class="flaticon-edit-1"></i>
                    Data Kompetensi B</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#" data-target="#m_tabs_1_1"><i class="flaticon-analytics"></i>
                    Grafik</a>
            </li>



        </ul>

        <div class="tab-content">
            <div class="tab-pane" id="m_tabs_1_1" role="tabpanel">
                <div class="col-md-12">
                    <div id="chart_cara_memperoleh_pekerjaan"></div>
                </div>
            </div>

            <div class="tab-pane active show" id="m_tabs_1_3" role="tabpanel">
               
                <div class="row">
                    <div class="col-md-6">
                        <b><h4>Data Kompetensi A</h4></b>

                    </div>
                    <div class="col-md-6 text-right">
                        <a href="{{url('export_kompetensi_a')}}" class="btn btn-success m-btn m-btn--custom m-btn--icon">
                            <span>
                                <i class="la la-file-excel-o"></i>
                                <span>Export Excell</span>
                            </span>
                        </a>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-12">
                        <div class="m-alert m-alert--icon m-alert--air alert alert-dismissible fade show" role="alert" style="background-color: #95a57e36">
                            <div class="m-alert__icon">
                                <i class="la 
                                la-question
                                 "></i>
                            </div>
                            <div class="m-alert__text">
                                <strong>Pertanyaan : </strong>
                                Pada saat lulus, pada tingkat mana kompetensi di bawah ini Anda kuasai? (A)

                            </div>
                           
                        </div>
                    </div>
                  
                </div>
                <br>

                <table cellpadding="0" class="table-striped tabel_show_kompetensi_a table table-bordered nowrap" cellspacing="0" width="100%">
                    <thead style="background-image: url('https://www.transparenttextures.com/patterns/sos.png');background-color: #349d44;color: #e5f6dd;">
                        <tr>
                            <th style="5%">No.</th>
                            <th style="15%">NPM</th>
                            <th style="25%">Nama</th>
                            <th style="25%">Prodi</th>
                            <th style="15%">Tahun lulus</th>
                            <th style="15%">PengetahuandibidangataudisiplinilmuAnda</th>
                            <th style="15%">PengetahuandiluarbidangataudisiplinilmuAnda</th>
                            <th style="15%">Pengetahuanumum</th>
                            <th style="15%">BahasaInggris</th>
                            <th style="15%">Ketrampilaninternet</th>
                            <th style="15%">Ketrampilankomputer</th>
                            <th style="15%">Berpikirkritis</th>
                            <th style="15%">KeterampilanRiset</th>
                            <th style="15%">Kemampuanbelajar</th>
                            <th style="15%">Kemampuanberkomunikasi</th>
                            <th style="15%">Bekerjadibawahtekanan</th>
                            <th style="15%">Manajemenwaktu</th>
                            <th style="15%">Bekerjasecaramandiri</th>
                            <th style="15%">Bekerjadalamtimbekerjasama</th>
                            <th style="15%">Kemampuandalammemecahkanmasalah</th>
                            <th style="15%">Negosiasi</th>
                            <th style="15%">Kemampuananalisis</th>
                            <th style="15%">Toleransi</th>
                            <th style="15%">Kemampuanadaptasi</th>
                            <th style="15%">Loyalitas</th>
                            <th style="15%">Integritas</th>
                            <th style="15%">Bekerjadenganorangyangberbeda</th>
                            <th style="15%">Kepemimpinan</th>
                            <th style="15%">Kemampuandalammemegangtanggungjawab</th>
                            <th style="15%">Inisiatif</th>
                            <th style="15%">Manajemenproyekprogram</th>
                            <th style="15%">Kemampuanuntukmemresentasikanide</th>
                            <th style="15%">Kemampuandalammenulislaporan</th>
                            <th style="15%">Kemampuanuntukterusbelajarsepanjanghayat</th>

                            <th style="15%">Created</th>

                        </tr>
                    </thead>

                </table>
            </div>

            <div class="tab-pane" id="m_tabs_1_2" role="tabpanel">
                <div class="row">
                    <div class="col-md-6">
                        <b><h4>Data Kompetensi B</h4></b>

                    </div>
                    <div class="col-md-6 text-right">
                        <a href="{{url('export_kompetensi_b')}}" class="btn btn-success m-btn m-btn--custom m-btn--icon">
                            <span>
                                <i class="la la-file-excel-o"></i>
                                <span>Export Excell</span>
                            </span>
                        </a>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-12">
                        <div class="m-alert m-alert--icon m-alert--air alert alert-dismissible fade show" role="alert" style="background-color: #95a57e36">
                            <div class="m-alert__icon">
                                <i class="la 
                                la-question
                                 "></i>
                            </div>
                            <div class="m-alert__text">
                                <strong>Pertanyaan : </strong>
                                Pada saat ini, pada tingkat mana kompetensi di bawah ini diperlukan dalam pekerjaan? (B)

                            </div>
                           
                        </div>
                    </div>
                  
                </div>
                <br>
                <table cellpadding="0" class="table-striped tabel_show_kompetensi_b table table-bordered nowrap" cellspacing="0" width="100%">
                    <thead style="background-image: url('https://www.transparenttextures.com/patterns/sos.png');background-color: #349d44;color: #e5f6dd;">
                        <tr>
                            <th style="5%">No.</th>
                            <th style="15%">NPM</th>
                            <th style="25%">Nama</th>
                            <th style="25%">Prodi</th>
                            <th style="15%">Tahun lulus</th>
                            <th style="15%">PengetahuandibidangataudisiplinilmuAnda</th>
                            <th style="15%">PengetahuandiluarbidangataudisiplinilmuAnda</th>
                            <th style="15%">Pengetahuanumum</th>
                            <th style="15%">BahasaInggris</th>
                            <th style="15%">Ketrampilaninternet</th>
                            <th style="15%">Ketrampilankomputer</th>
                            <th style="15%">Berpikirkritis</th>
                            <th style="15%">KeterampilanRiset</th>
                            <th style="15%">Kemampuanbelajar</th>
                            <th style="15%">Kemampuanberkomunikasi</th>
                            <th style="15%">Bekerjadibawahtekanan</th>
                            <th style="15%">Manajemenwaktu</th>
                            <th style="15%">Bekerjasecaramandiri</th>
                            <th style="15%">Bekerjadalamtimbekerjasama</th>
                            <th style="15%">Kemampuandalammemecahkanmasalah</th>
                            <th style="15%">Negosiasi</th>
                            <th style="15%">Kemampuananalisis</th>
                            <th style="15%">Toleransi</th>
                            <th style="15%">Kemampuanadaptasi</th>
                            <th style="15%">Loyalitas</th>
                            <th style="15%">Integritas</th>
                            <th style="15%">Bekerjadenganorangyangberbeda</th>
                            <th style="15%">Kepemimpinan</th>
                            <th style="15%">Kemampuandalammemegangtanggungjawab</th>
                            <th style="15%">Inisiatif</th>
                            <th style="15%">Manajemenproyekprogram</th>
                            <th style="15%">Kemampuanuntukmemresentasikanide</th>
                            <th style="15%">Kemampuandalammenulislaporan</th>
                            <th style="15%">Kemampuanuntukterusbelajarsepanjanghayat</th>

                            <th style="15%">Created</th>

                        </tr>
                    </thead>

                </table>
            </div>

        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
<script src ="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
<script src="https://code.highcharts.com/highcharts.src.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script>

    $(document).ready(function(){
        var kompetensi_a = $('.tabel_show_kompetensi_a').DataTable({
            responsive:true,
            paging: true,
            info: true,
            searching: true,
            "aaSorting": [],
            "ordering": true,

            ajax: {
                url: '{{url("datatable-kompetensi-A")}}',
                dataSrc: 'result',
            },
            scrollX:        true,

            autoWidth:         true,

        });

        var kompetensi_b = $('.tabel_show_kompetensi_b').DataTable({
            responsive:true,
            paging: true,
            info: true,
            searching: true,
            "aaSorting": [],
            "ordering": true,

            ajax: {
                url: '{{url("datatable-kompetensi-B")}}',
                dataSrc: 'result',
            },
            scrollX:        true,

            autoWidth:         true,

        });
        $.ajax({
            url: "{{url('graph-kompetensi-AB')}}",
            type: 'GET',
            dataType: 'JSON',
            success:function(response){
                console.log(response);
            Highcharts.chart('chart_cara_memperoleh_pekerjaan', {

                title: {
                    text: 'Kompetensi'
                },
                subtitle: {
                    text: 'Source: <a href="">http://localhost/quisioner_alumni/public/</a>'
                },
                yAxis: {
                    title: {
                        text: 'Kompetensi'
                    }
                },

                xAxis: {
                    categories: ['Pengetahuan di bidang atau disiplin ilmu Anda',
                                'Pengetahuan di luar bidang atau disiplin ilmu Anda',
                                'Pengetahuan umum',
                                'Bahasa Inggris',
                                'Ketrampilan internet',
                                'Ketrampilan komputer',
                                'Berpikir kritis',
                                'Keterampilan Riset',
                                'Kemampuan belajar',
                                'Kemampuan berkomunikasi',
                                'Bekerja di bawah tekanan',
                                'Manajemen waktu',
                                'Bekerja secara mandiri',
                                'Bekerja dalam tim/bekerjasama',
                                'Kemampuan dalam memecahkan masalah',
                                'Negosiasi',
                                'Kemampuan analisis',
                                'Toleransi',
                                'Kemampuan adaptasi',
                                'Loyalitas',
                                'Integritas',
                                'Bekerja dengan orang yang berbeda budaya maupun latar belakang',
                                'Kepemimpinan',
                                'Kemampuan dalam memegang tanggungjawab',
                                'Inisiatif',
                                'Manajemen proyek/program',
                                'Kemampuan untuk memresentasikan ide/produk/laporan',
                                'Kemampuan dalam menulis laporan, memo dan dokumen',
                                'Kemampuan untuk terus belajar sepanjang hayat'
                                ],
                    labels: {
                      rotation: 90
                    }
                  },
                tooltip: {
                    valueSuffix: ' Data'
                },
                legend: {
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'middle'
                },




                credits: {
                    enabled: false
                },
                series: [{
                    name : 'Kompetensi A',
                    color: '#3d8a49',
                    data: [response.push_kategori_a[0],
                           response.push_kategori_a[1],
                           response.push_kategori_a[2],
                           response.push_kategori_a[3],
                           response.push_kategori_a[4],
                           response.push_kategori_a[5],
                           response.push_kategori_a[6],
                           response.push_kategori_a[7],
                           response.push_kategori_a[8],
                           response.push_kategori_a[9],
                           response.push_kategori_a[10],
                           response.push_kategori_a[11],
                           response.push_kategori_a[12],
                           response.push_kategori_a[13],
                           response.push_kategori_a[14],
                           response.push_kategori_a[15],
                           response.push_kategori_a[16],
                           response.push_kategori_a[17],
                           response.push_kategori_a[18],
                           response.push_kategori_a[19],
                           response.push_kategori_a[20],
                           response.push_kategori_a[21],
                           response.push_kategori_a[22],
                           response.push_kategori_a[23],
                           response.push_kategori_a[24],
                           response.push_kategori_a[25],
                           response.push_kategori_a[26],
                           response.push_kategori_a[27],
                           response.push_kategori_a[28],
                           response.push_kategori_a[29]

                    ]
                },
                {
                    name : 'Kompetensi B',
                    color: '#f7a35c',
                    data: [response.push_kategori_b[0],
                           response.push_kategori_b[1],
                           response.push_kategori_b[2],
                           response.push_kategori_b[3],
                           response.push_kategori_b[4],
                           response.push_kategori_b[5],
                           response.push_kategori_b[6],
                           response.push_kategori_b[7],
                           response.push_kategori_b[8],
                           response.push_kategori_b[9],
                           response.push_kategori_b[10],
                           response.push_kategori_b[11],
                           response.push_kategori_b[12],
                           response.push_kategori_b[13],
                           response.push_kategori_b[14],
                           response.push_kategori_b[15],
                           response.push_kategori_b[16],
                           response.push_kategori_b[17],
                           response.push_kategori_b[18],
                           response.push_kategori_b[19],
                           response.push_kategori_b[20],
                           response.push_kategori_b[21],
                           response.push_kategori_b[22],
                           response.push_kategori_b[23],
                           response.push_kategori_b[24],
                           response.push_kategori_b[25],
                           response.push_kategori_b[26],
                           response.push_kategori_b[27],
                           response.push_kategori_b[28],
                           response.push_kategori_b[29]

                    ]
                },


            ],

                });
            }
        });

    });

</script>
@endsection
