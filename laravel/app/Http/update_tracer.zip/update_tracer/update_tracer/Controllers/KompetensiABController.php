<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class KompetensiABController extends Controller
{
    public function index()
    {
        if(Auth::user()->role_id == 2){
            $auth_user = DB::table('users')
            ->leftJoin('tm_fakultas', 'users.fakultas_user_id', 'tm_fakultas.id')
            ->where('users.id', Auth::user()->id)
            ->first();
        }else if(Auth::user()->role_id == 3){
            $auth_user = DB::table('users')
            ->leftJoin('tm_kode_prodi', 'users.prodi_id', 'tm_kode_prodi.kode')
            ->where('id', Auth::user()->id)
            ->first();
        }else{
            $auth_user = DB::table('users')
            ->where('id', Auth::user()->id)
            ->first();
        }
        return view('KompetensiAB.index', compact('auth_user'));
    }

    public function show_data_kompetensi_a(){
        try {
            $result = [];
            $count = 1;


            if(Auth::user()->role_id == 1){
                $query = DB::table('tb_kompetensia')
                ->Leftjoin('tb_mahasiswa', 'tb_kompetensia.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                ->whereNotNull('tb_mahasiswa.npm')
                ->get();
            }else if(Auth::user()->role_id == 2){
                $query = DB::table('tb_kompetensia')
                ->Leftjoin('tb_mahasiswa', 'tb_kompetensia.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                ->where('mhs_fakultas_id', Auth::user()->fakultas_user_id)
                ->whereNotNull('tb_mahasiswa.npm')
                ->get();
            }
            else{
                $query = DB::table('tb_kompetensia')
                ->Leftjoin('tb_mahasiswa', 'tb_kompetensia.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                ->where('kode_prodi_id', Auth::user()->prodi_id)
                ->whereNotNull('tb_mahasiswa.npm')
                ->get();
            }
            // dd($query);

            foreach ($query as $user) {
                $action_edit = '<center>
                <a href="#" class="btn btn-success btn-sm m-btn  m-btn m-btn--icon"
                data-toggle="modal"
                data-id= "'. $user->id.'"
                data-target="#modal-edit" id="btn_update_surat">
                <span>
                    <i class="la la-edit"></i>
                    <span>Ubah</span>
                </span>
                </a>';

                $roless = "";

                $update = $user->created_at;
                $data = [];
                $data[] = $count++;
                $data[] = strtoupper($user->npm);
                $data[] = ($user->nama);
                $data[] = ($user->prodi);
                $data[] = ($user->tahun_lulus);
                $data[] = $user->PengetahuandibidangataudisiplinilmuAnda;
                $data[] = $user->PengetahuandiluarbidangataudisiplinilmuAnda;
                $data[] = $user->Pengetahuanumum;
                $data[] = $user->BahasaInggris;
                $data[] = $user->Ketrampilaninternet;
                $data[] = $user->Ketrampilankomputer;
                $data[] = $user->Berpikirkritis;
                $data[] = $user->KeterampilanRiset;
                $data[] = $user->Kemampuanbelajar;
                $data[] = $user->Kemampuanberkomunikasi;
                $data[] = $user->Bekerjadibawahtekanan;
                $data[] = $user->Manajemenwaktu;
                $data[] = $user->Bekerjasecaramandiri;
                $data[] = $user->Bekerjadalamtimbekerjasama;
                $data[] = $user->Kemampuandalammemecahkanmasalah;
                $data[] = $user->Negosiasi;
                $data[] = $user->Kemampuananalisis;
                $data[] = $user->Toleransi;
                $data[] = $user->Kemampuanadaptasi;
                $data[] = $user->Loyalitas;
                $data[] = $user->Integritas;
                $data[] = $user->Bekerjadenganorangyangberbedabudayamaupunlatarbelakang;
                $data[] = $user->Kepemimpinan;
                $data[] = $user->Kemampuandalammemegangtanggungjawab;
                $data[] = $user->Inisiatif;
                $data[] = $user->Manajemenproyekprogram;
                $data[] = $user->Kemampuanuntukmemresentasikanide;
                $data[] = $user->Kemampuandalammenulislaporan;
                $data[] = $user->Kemampuanuntukterusbelajarsepanjanghayat;



                $data[] = $update;
                // $data[] = $action_edit;
                $result[] = $data;
            }
            return response()->json(['result' => $result]);
        } catch (\Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 406);
        }
    }

    public function show_data_kompetensi_b(){
        try {
            $result = [];
            $count = 1;


            if(Auth::user()->role_id == 1){
                $query = DB::table('tb_kompetensib')
                ->Leftjoin('tb_mahasiswa', 'tb_kompetensib.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                ->whereNotNull('tb_mahasiswa.npm')
                ->get();
            }else if(Auth::user()->role_id == 2){
                $query = DB::table('tb_kompetensib')
                ->Leftjoin('tb_mahasiswa', 'tb_kompetensib.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                ->where('mhs_fakultas_id', Auth::user()->fakultas_user_id)
                ->whereNotNull('tb_mahasiswa.npm')
                ->get();
            }
            else{
                $query = DB::table('tb_kompetensib')
                ->Leftjoin('tb_mahasiswa', 'tb_kompetensib.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                ->where('kode_prodi_id', Auth::user()->prodi_id)
                ->whereNotNull('tb_mahasiswa.npm')
                ->get();
            }
            // dd($query);

            foreach ($query as $user) {
                $action_edit = '<center>
                <a href="#" class="btn btn-success btn-sm m-btn  m-btn m-btn--icon"
                data-toggle="modal"
                data-id= "'. $user->id.'"
                data-target="#modal-edit" id="btn_update_surat">
                <span>
                    <i class="la la-edit"></i>
                    <span>Ubah</span>
                </span>
                </a>';

                $roless = "";

                $update = $user->created_at;
                $data = [];
                $data[] = $count++;
                $data[] = strtoupper($user->npm);
                $data[] = ($user->nama);
                $data[] = ($user->prodi);
                $data[] = ($user->tahun_lulus);
                $data[] = $user->PengetahuandibidangataudisiplinilmuAnda;
                $data[] = $user->PengetahuandiluarbidangataudisiplinilmuAnda;
                $data[] = $user->Pengetahuanumum;
                $data[] = $user->BahasaInggris;
                $data[] = $user->Ketrampilaninternet;
                $data[] = $user->Ketrampilankomputer;
                $data[] = $user->Berpikirkritis;
                $data[] = $user->KeterampilanRiset;
                $data[] = $user->Kemampuanbelajar;
                $data[] = $user->Kemampuanberkomunikasi;
                $data[] = $user->Bekerjadibawahtekanan;
                $data[] = $user->Manajemenwaktu;
                $data[] = $user->Bekerjasecaramandiri;
                $data[] = $user->Bekerjadalamtimbekerjasama;
                $data[] = $user->Kemampuandalammemecahkanmasalah;
                $data[] = $user->Negosiasi;
                $data[] = $user->Kemampuananalisis;
                $data[] = $user->Toleransi;
                $data[] = $user->Kemampuanadaptasi;
                $data[] = $user->Loyalitas;
                $data[] = $user->Integritas;
                $data[] = $user->Bekerjadenganorangyangberbedabudayamaupunlatarbelakang;
                $data[] = $user->Kepemimpinan;
                $data[] = $user->Kemampuandalammemegangtanggungjawab;
                $data[] = $user->Inisiatif;
                $data[] = $user->Manajemenproyekprogram;
                $data[] = $user->Kemampuanuntukmemresentasikanide;
                $data[] = $user->Kemampuandalammenulislaporan;
                $data[] = $user->Kemampuanuntukterusbelajarsepanjanghayat;



                $data[] = $update;
                // $data[] = $action_edit;
                $result[] = $data;
            }
            return response()->json(['result' => $result]);
        } catch (\Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 406);
        }
    }

    public function graph(){
        $prodi_id = '';
        if(Auth::user()->role_id == 1){
           $prodi_id = ' where tb_mahasiswa.npm is not null ';
        }else if(Auth::user()->role_id == 2){
            $prodi_id = ' where mhs_fakultas_id= "'.Auth::user()->fakultas_user_id.'" and tb_mahasiswa.npm is not null ';
        }else if(Auth::user()->role_id == 3){
            $prodi_id = ' where kode_prodi_id = "'.Auth::user()->prodi_id.'" and tb_mahasiswa.npm is not null ';
        }

        $query_PengetahuandibidangataudisiplinilmuAnda = DB::select('SELECT *, SUM(PengetahuandibidangataudisiplinilmuAnda) as jumlah  FROM `tb_kompetensia`
        LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
        '.$prodi_id
        );

        $data['PengetahuandibidangataudisiplinilmuAnda'] = [];


        foreach ($query_PengetahuandibidangataudisiplinilmuAnda as $key => $value) {
            array_push($data['PengetahuandibidangataudisiplinilmuAnda'], (int)$value->jumlah);

        }
        //-------------------------------------------------
        $query_PengetahuandiluarbidangataudisiplinilmuAnda = DB::select('SELECT *, SUM(PengetahuandiluarbidangataudisiplinilmuAnda) as jumlah  FROM `tb_kompetensia`
        LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
        '.$prodi_id
        );

        $data['PengetahuandiluarbidangataudisiplinilmuAnda'] = [];


        foreach ($query_PengetahuandiluarbidangataudisiplinilmuAnda as $key => $value) {
            array_push($data['PengetahuandiluarbidangataudisiplinilmuAnda'], (int)$value->jumlah);

        }
            //-------------------------------------------------

        $query_Pengetahuanumum = DB::select('SELECT *, SUM(Pengetahuanumum) as jumlah  FROM `tb_kompetensia`
        LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
        '.$prodi_id
        );

        $data['Pengetahuanumum'] = [];


        foreach ($query_Pengetahuanumum as $key => $value) {
            array_push($data['Pengetahuanumum'], (int)$value->jumlah);

        }

          //-------------------------------------------------

          $query_BahasaInggris = DB::select('SELECT *, SUM(BahasaInggris) as jumlah  FROM `tb_kompetensia`
          LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
          '.$prodi_id
          );

          $data['BahasaInggris'] = [];


          foreach ($query_BahasaInggris as $key => $value) {
              array_push($data['BahasaInggris'], (int)$value->jumlah);

          }

            //-------------------------------------------------

        $query_Ketrampilaninternet = DB::select('SELECT *, SUM(Ketrampilaninternet) as jumlah  FROM `tb_kompetensia`
        LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
        '.$prodi_id
        );

        $data['Ketrampilaninternet'] = [];


        foreach ($query_Ketrampilaninternet as $key => $value) {
            array_push($data['Ketrampilaninternet'], (int)$value->jumlah);

        }

          //-------------------------------------------------

          $query_Ketrampilankomputer = DB::select('SELECT *, SUM(Ketrampilankomputer) as jumlah  FROM `tb_kompetensia`
          LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
          '.$prodi_id
          );

          $data['Ketrampilankomputer'] = [];


          foreach ($query_Ketrampilankomputer as $key => $value) {
              array_push($data['Ketrampilankomputer'], (int)$value->jumlah);

          }

            //-------------------------------------------------

            $query_Berpikirkritis = DB::select('SELECT *, SUM(Berpikirkritis) as jumlah  FROM `tb_kompetensia`
            LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
            '.$prodi_id
            );

            $data['Berpikirkritis'] = [];


            foreach ($query_Berpikirkritis as $key => $value) {
                array_push($data['Berpikirkritis'], (int)$value->jumlah);

            }

              //-------------------------------------------------

          $query_KeterampilanRiset = DB::select('SELECT *, SUM(KeterampilanRiset) as jumlah  FROM `tb_kompetensia`
          LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
          '.$prodi_id
          );

          $data['KeterampilanRiset'] = [];


          foreach ($query_KeterampilanRiset as $key => $value) {
              array_push($data['KeterampilanRiset'], (int)$value->jumlah);

          }

           //-------------------------------------------------

           $query_Kemampuanbelajar = DB::select('SELECT *, SUM(Kemampuanbelajar) as jumlah  FROM `tb_kompetensia`
           LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
           '.$prodi_id
           );

           $data['Kemampuanbelajar'] = [];


           foreach ($query_Kemampuanbelajar as $key => $value) {
               array_push($data['Kemampuanbelajar'], (int)$value->jumlah);

           }

            //-------------------------------------------------

            $query_Kemampuanberkomunikasi = DB::select('SELECT *, SUM(Kemampuanberkomunikasi) as jumlah  FROM `tb_kompetensia`
            LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
            '.$prodi_id
            );

            $data['Kemampuanberkomunikasi'] = [];


            foreach ($query_Kemampuanberkomunikasi as $key => $value) {
                array_push($data['Kemampuanberkomunikasi'], (int)$value->jumlah);

            }

            //-------------------------------------------------

            $query_Bekerjadibawahtekanan = DB::select('SELECT *, SUM(Bekerjadibawahtekanan) as jumlah  FROM `tb_kompetensia`
            LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
            '.$prodi_id
            );

            $data['Bekerjadibawahtekanan'] = [];


            foreach ($query_Bekerjadibawahtekanan as $key => $value) {
                array_push($data['Bekerjadibawahtekanan'], (int)$value->jumlah);

            }

            //-------------------------------------------------

            $query_Manajemenwaktu = DB::select('SELECT *, SUM(Manajemenwaktu) as jumlah  FROM `tb_kompetensia`
            LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
            '.$prodi_id
            );

            $data['Manajemenwaktu'] = [];


            foreach ($query_Manajemenwaktu as $key => $value) {
                array_push($data['Manajemenwaktu'], (int)$value->jumlah);

            }

            //-------------------------------------------------

            $query_Bekerjasecaramandiri = DB::select('SELECT *, SUM(Bekerjasecaramandiri) as jumlah  FROM `tb_kompetensia`
            LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
            '.$prodi_id
            );

            $data['Bekerjasecaramandiri'] = [];


            foreach ($query_Bekerjasecaramandiri as $key => $value) {
                array_push($data['Bekerjasecaramandiri'], (int)$value->jumlah);

            }

             //-------------------------------------------------

             $query_Bekerjadalamtimbekerjasama = DB::select('SELECT *, SUM(Bekerjadalamtimbekerjasama) as jumlah  FROM `tb_kompetensia`
             LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
             '.$prodi_id
             );

             $data['Bekerjadalamtimbekerjasama'] = [];


             foreach ($query_Bekerjadalamtimbekerjasama as $key => $value) {
                 array_push($data['Bekerjadalamtimbekerjasama'], (int)$value->jumlah);

             }

             //-------------------------------------------------

             $query_Kemampuandalammemecahkanmasalah = DB::select('SELECT *, SUM(Kemampuandalammemecahkanmasalah) as jumlah  FROM `tb_kompetensia`
             LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
             '.$prodi_id
             );

             $data['Kemampuandalammemecahkanmasalah'] = [];


             foreach ($query_Kemampuandalammemecahkanmasalah as $key => $value) {
                 array_push($data['Kemampuandalammemecahkanmasalah'], (int)$value->jumlah);

             }

              //-------------------------------------------------

              $query_Negosiasi = DB::select('SELECT *, SUM(Negosiasi) as jumlah  FROM `tb_kompetensia`
              LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
              '.$prodi_id
              );

              $data['Negosiasi'] = [];


              foreach ($query_Negosiasi as $key => $value) {
                  array_push($data['Negosiasi'], (int)$value->jumlah);

              }

               //-------------------------------------------------

               $query_Kemampuananalisis = DB::select('SELECT *, SUM(Kemampuananalisis) as jumlah  FROM `tb_kompetensia`
               LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
               '.$prodi_id
               );

               $data['Kemampuananalisis'] = [];


               foreach ($query_Kemampuananalisis as $key => $value) {
                   array_push($data['Kemampuananalisis'], (int)$value->jumlah);

               }

                //-------------------------------------------------

                $query_Toleransi = DB::select('SELECT *, SUM(Toleransi) as jumlah  FROM `tb_kompetensia`
                LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                '.$prodi_id
                );

                $data['Toleransi'] = [];


                foreach ($query_Toleransi as $key => $value) {
                    array_push($data['Toleransi'], (int)$value->jumlah);

                }

                 //-------------------------------------------------

                 $query_Kemampuanadaptasi = DB::select('SELECT *, SUM(Kemampuanadaptasi) as jumlah  FROM `tb_kompetensia`
                 LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                 '.$prodi_id
                 );

                 $data['Kemampuanadaptasi'] = [];


                 foreach ($query_Kemampuanadaptasi as $key => $value) {
                     array_push($data['Kemampuanadaptasi'], (int)$value->jumlah);

                 }

                 //-------------------------------------------------

                 $query_Loyalitas = DB::select('SELECT *, SUM(Loyalitas) as jumlah  FROM `tb_kompetensia`
                 LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                 '.$prodi_id
                 );

                 $data['Loyalitas'] = [];


                 foreach ($query_Loyalitas as $key => $value) {
                     array_push($data['Loyalitas'], (int)$value->jumlah);

                 }

                 //-------------------------------------------------

                 $query_Integritas = DB::select('SELECT *, SUM(Integritas) as jumlah  FROM `tb_kompetensia`
                 LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                 '.$prodi_id
                 );

                 $data['Integritas'] = [];


                 foreach ($query_Integritas as $key => $value) {
                     array_push($data['Integritas'], (int)$value->jumlah);

                 }

                 //-------------------------------------------------

                 $query_Bekerjadenganorangyangberbedabudayamaupunlatarbelakang = DB::select('SELECT *, SUM(Bekerjadenganorangyangberbedabudayamaupunlatarbelakang) as jumlah  FROM `tb_kompetensia`
                 LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                 '.$prodi_id
                 );

                 $data['Bekerjadenganorangyangberbedabudayamaupunlatarbelakang'] = [];


                 foreach ($query_Bekerjadenganorangyangberbedabudayamaupunlatarbelakang as $key => $value) {
                     array_push($data['Bekerjadenganorangyangberbedabudayamaupunlatarbelakang'], (int)$value->jumlah);

                 }

                 //-------------------------------------------------

                 $query_Kepemimpinan = DB::select('SELECT *, SUM(Kepemimpinan) as jumlah  FROM `tb_kompetensia`
                 LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                 '.$prodi_id
                 );

                 $data['Kepemimpinan'] = [];


                 foreach ($query_Kepemimpinan as $key => $value) {
                     array_push($data['Kepemimpinan'], (int)$value->jumlah);

                 }

                  //-------------------------------------------------

                  $query_Kemampuandalammemegangtanggungjawab = DB::select('SELECT *, SUM(Kemampuandalammemegangtanggungjawab) as jumlah  FROM `tb_kompetensia`
                  LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                  '.$prodi_id
                  );

                  $data['Kemampuandalammemegangtanggungjawab'] = [];


                  foreach ($query_Kemampuandalammemegangtanggungjawab as $key => $value) {
                      array_push($data['Kemampuandalammemegangtanggungjawab'], (int)$value->jumlah);

                  }

                  //-------------------------------------------------

                  $query_Inisiatif = DB::select('SELECT *, SUM(Inisiatif) as jumlah  FROM `tb_kompetensia`
                  LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                  '.$prodi_id
                  );

                  $data['Inisiatif'] = [];


                  foreach ($query_Inisiatif as $key => $value) {
                      array_push($data['Inisiatif'], (int)$value->jumlah);

                  }

                    //-------------------------------------------------

                    $query_Manajemenproyekprogram = DB::select('SELECT *, SUM(Manajemenproyekprogram) as jumlah  FROM `tb_kompetensia`
                    LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                    '.$prodi_id
                    );

                    $data['Manajemenproyekprogram'] = [];


                    foreach ($query_Manajemenproyekprogram as $key => $value) {
                        array_push($data['Manajemenproyekprogram'], (int)$value->jumlah);

                    }

                     //-------------------------------------------------

                     $query_Kemampuanuntukmemresentasikanide = DB::select('SELECT *, SUM(Kemampuanuntukmemresentasikanide) as jumlah  FROM `tb_kompetensia`
                     LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                     '.$prodi_id
                     );

                     $data['Kemampuanuntukmemresentasikanide'] = [];


                     foreach ($query_Kemampuanuntukmemresentasikanide as $key => $value) {
                         array_push($data['Kemampuanuntukmemresentasikanide'], (int)$value->jumlah);

                     }

                     //-------------------------------------------------

                     $query_Kemampuandalammenulislaporan = DB::select('SELECT *, SUM(Kemampuandalammenulislaporan) as jumlah  FROM `tb_kompetensia`
                     LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                     '.$prodi_id
                     );

                     $data['Kemampuandalammenulislaporan'] = [];


                     foreach ($query_Kemampuandalammenulislaporan as $key => $value) {
                         array_push($data['Kemampuandalammenulislaporan'], (int)$value->jumlah);

                     }

                      //-------------------------------------------------

                      $query_Kemampuanuntukterusbelajarsepanjanghayat = DB::select('SELECT *, SUM(Kemampuanuntukterusbelajarsepanjanghayat) as jumlah  FROM `tb_kompetensia`
                      LEFT JOIN tb_mahasiswa ON tb_kompetensia.npm = tb_mahasiswa.npm
                      '.$prodi_id
                      );

                      $data['Kemampuanuntukterusbelajarsepanjanghayat'] = [];


                      foreach ($query_Kemampuanuntukterusbelajarsepanjanghayat as $key => $value) {
                          array_push($data['Kemampuanuntukterusbelajarsepanjanghayat'], (int)$value->jumlah);

                      }
                        $data['push_kategori_a'] =  [];
                        array_push($data['push_kategori_a'],
                            $data['PengetahuandibidangataudisiplinilmuAnda'],
                            $data['PengetahuandiluarbidangataudisiplinilmuAnda'],
                            $data['Pengetahuanumum'],
                            $data['BahasaInggris'],
                            $data['Ketrampilaninternet'],
                            $data['Ketrampilankomputer'],
                            $data['Berpikirkritis'],
                            $data['KeterampilanRiset'],
                            $data['Kemampuanbelajar'],
                            $data['Kemampuanberkomunikasi'],
                            $data['Bekerjadibawahtekanan'],
                            $data['Manajemenwaktu'],
                            $data['Bekerjasecaramandiri'],
                            $data['Bekerjadalamtimbekerjasama'],
                            $data['Kemampuandalammemecahkanmasalah'],
                            $data['Negosiasi'],
                            $data['Kemampuananalisis'],
                            $data['Toleransi'],
                            $data['Kemampuanadaptasi'],
                            $data['Loyalitas'],
                            $data['Integritas'],
                            $data['Bekerjadenganorangyangberbedabudayamaupunlatarbelakang'],
                            $data['Kepemimpinan'],
                            $data['Kemampuandalammemegangtanggungjawab'],
                            $data['Inisiatif'],
                            $data['Manajemenproyekprogram'],
                            $data['Kemampuanuntukmemresentasikanide'],
                            $data['Kemampuandalammenulislaporan'],
                            $data['Kemampuanuntukterusbelajarsepanjanghayat']

                        );



                    //---------------------------------------------------------KOMPETENSI B------------------------------------------------------------------------------------

                    $query_b_PengetahuandibidangataudisiplinilmuAnda = DB::select('SELECT *, SUM(PengetahuandibidangataudisiplinilmuAnda) as jumlah  FROM `tb_kompetensib`
                    LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                    '.$prodi_id
                    );

                    $data['PengetahuandibidangataudisiplinilmuAnda_b'] = [];


                    foreach ($query_b_PengetahuandibidangataudisiplinilmuAnda as $key => $value) {
                        array_push($data['PengetahuandibidangataudisiplinilmuAnda_b'], (int)$value->jumlah);

                    }
                    //-------------------------------------------------
                    $query_b_PengetahuandiluarbidangataudisiplinilmuAnda = DB::select('SELECT *, SUM(PengetahuandiluarbidangataudisiplinilmuAnda) as jumlah  FROM `tb_kompetensib`
                    LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                    '.$prodi_id
                    );

                    $data['PengetahuandiluarbidangataudisiplinilmuAnda_b'] = [];


                    foreach ($query_b_PengetahuandiluarbidangataudisiplinilmuAnda as $key => $value) {
                        array_push($data['PengetahuandiluarbidangataudisiplinilmuAnda_b'], (int)$value->jumlah);

                    }
                        //-------------------------------------------------

                    $query_b_Pengetahuanumum = DB::select('SELECT *, SUM(Pengetahuanumum) as jumlah  FROM `tb_kompetensib`
                    LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                    '.$prodi_id
                    );

                    $data['Pengetahuanumum_b'] = [];


                    foreach ($query_b_Pengetahuanumum as $key => $value) {
                        array_push($data['Pengetahuanumum_b'], (int)$value->jumlah);

                    }

                      //-------------------------------------------------

                      $query_b_BahasaInggris = DB::select('SELECT *, SUM(BahasaInggris) as jumlah  FROM `tb_kompetensib`
                      LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                      '.$prodi_id
                      );

                      $data['BahasaInggris_b'] = [];


                      foreach ($query_b_BahasaInggris as $key => $value) {
                          array_push($data['BahasaInggris_b'], (int)$value->jumlah);

                      }

                        //-------------------------------------------------

                    $query_b_Ketrampilaninternet = DB::select('SELECT *, SUM(Ketrampilaninternet) as jumlah  FROM `tb_kompetensib`
                    LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                    '.$prodi_id
                    );

                    $data['Ketrampilaninternet_b'] = [];


                    foreach ($query_b_Ketrampilaninternet as $key => $value) {
                        array_push($data['Ketrampilaninternet_b'], (int)$value->jumlah);

                    }

                      //-------------------------------------------------

                      $query_b_Ketrampilankomputer = DB::select('SELECT *, SUM(Ketrampilankomputer) as jumlah  FROM `tb_kompetensib`
                      LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                      '.$prodi_id
                      );

                      $data['Ketrampilankomputer_b'] = [];


                      foreach ($query_b_Ketrampilankomputer as $key => $value) {
                          array_push($data['Ketrampilankomputer_b'], (int)$value->jumlah);

                      }

                        //-------------------------------------------------

                        $query_b_Berpikirkritis = DB::select('SELECT *, SUM(Berpikirkritis) as jumlah  FROM `tb_kompetensib`
                        LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                        '.$prodi_id
                        );

                        $data['Berpikirkritis_b'] = [];


                        foreach ($query_b_Berpikirkritis as $key => $value) {
                            array_push($data['Berpikirkritis_b'], (int)$value->jumlah);

                        }

                          //-------------------------------------------------

                      $query_b_KeterampilanRiset = DB::select('SELECT *, SUM(KeterampilanRiset) as jumlah  FROM `tb_kompetensib`
                      LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                      '.$prodi_id
                      );

                      $data['KeterampilanRiset_b'] = [];


                      foreach ($query_b_KeterampilanRiset as $key => $value) {
                          array_push($data['KeterampilanRiset_b'], (int)$value->jumlah);

                      }

                       //-------------------------------------------------

                       $query_b_Kemampuanbelajar = DB::select('SELECT *, SUM(Kemampuanbelajar) as jumlah  FROM `tb_kompetensib`
                       LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                       '.$prodi_id
                       );

                       $data['Kemampuanbelajar_b'] = [];


                       foreach ($query_b_Kemampuanbelajar as $key => $value) {
                           array_push($data['Kemampuanbelajar_b'], (int)$value->jumlah);

                       }

                        //-------------------------------------------------

                        $query_b_Kemampuanberkomunikasi = DB::select('SELECT *, SUM(Kemampuanberkomunikasi) as jumlah  FROM `tb_kompetensib`
                        LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                        '.$prodi_id
                        );

                        $data['Kemampuanberkomunikasi_b'] = [];


                        foreach ($query_b_Kemampuanberkomunikasi as $key => $value) {
                            array_push($data['Kemampuanberkomunikasi_b'], (int)$value->jumlah);

                        }

                        //-------------------------------------------------

                        $query_b_Bekerjadibawahtekanan = DB::select('SELECT *, SUM(Bekerjadibawahtekanan) as jumlah  FROM `tb_kompetensib`
                        LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                        '.$prodi_id
                        );

                        $data['Bekerjadibawahtekanan_b'] = [];


                        foreach ($query_b_Bekerjadibawahtekanan as $key => $value) {
                            array_push($data['Bekerjadibawahtekanan_b'], (int)$value->jumlah);

                        }

                        //-------------------------------------------------

                        $query_b_Manajemenwaktu = DB::select('SELECT *, SUM(Manajemenwaktu) as jumlah  FROM `tb_kompetensib`
                        LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                        '.$prodi_id
                        );

                        $data['Manajemenwaktu_b'] = [];


                        foreach ($query_b_Manajemenwaktu as $key => $value) {
                            array_push($data['Manajemenwaktu_b'], (int)$value->jumlah);

                        }

                        //-------------------------------------------------

                        $query_b_Bekerjasecaramandiri = DB::select('SELECT *, SUM(Bekerjasecaramandiri) as jumlah  FROM `tb_kompetensib`
                        LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                        '.$prodi_id
                        );

                        $data['Bekerjasecaramandiri_b'] = [];


                        foreach ($query_b_Bekerjasecaramandiri as $key => $value) {
                            array_push($data['Bekerjasecaramandiri_b'], (int)$value->jumlah);

                        }

                         //-------------------------------------------------

                         $query_b_Bekerjadalamtimbekerjasama = DB::select('SELECT *, SUM(Bekerjadalamtimbekerjasama) as jumlah  FROM `tb_kompetensib`
                         LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                         '.$prodi_id
                         );

                         $data['Bekerjadalamtimbekerjasama_b'] = [];


                         foreach ($query_b_Bekerjadalamtimbekerjasama as $key => $value) {
                             array_push($data['Bekerjadalamtimbekerjasama_b'], (int)$value->jumlah);

                         }

                         //-------------------------------------------------

                         $query_b_Kemampuandalammemecahkanmasalah = DB::select('SELECT *, SUM(Kemampuandalammemecahkanmasalah) as jumlah  FROM `tb_kompetensib`
                         LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                         '.$prodi_id
                         );

                         $data['Kemampuandalammemecahkanmasalah_b'] = [];


                         foreach ($query_b_Kemampuandalammemecahkanmasalah as $key => $value) {
                             array_push($data['Kemampuandalammemecahkanmasalah_b'], (int)$value->jumlah);

                         }

                          //-------------------------------------------------

                          $query_b_Negosiasi = DB::select('SELECT *, SUM(Negosiasi) as jumlah  FROM `tb_kompetensib`
                          LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                          '.$prodi_id
                          );

                          $data['Negosiasi_b'] = [];


                          foreach ($query_b_Negosiasi as $key => $value) {
                              array_push($data['Negosiasi_b'], (int)$value->jumlah);

                          }

                           //-------------------------------------------------

                           $query_b_Kemampuananalisis = DB::select('SELECT *, SUM(Kemampuananalisis) as jumlah  FROM `tb_kompetensib`
                           LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                           '.$prodi_id
                           );

                           $data['Kemampuananalisis_b'] = [];


                           foreach ($query_b_Kemampuananalisis as $key => $value) {
                               array_push($data['Kemampuananalisis_b'], (int)$value->jumlah);

                           }

                            //-------------------------------------------------

                            $query_b_Toleransi = DB::select('SELECT *, SUM(Toleransi) as jumlah  FROM `tb_kompetensib`
                            LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                            '.$prodi_id
                            );

                            $data['Toleransi_b'] = [];


                            foreach ($query_b_Toleransi as $key => $value) {
                                array_push($data['Toleransi_b'], (int)$value->jumlah);

                            }

                             //-------------------------------------------------

                             $query_b_Kemampuanadaptasi = DB::select('SELECT *, SUM(Kemampuanadaptasi) as jumlah  FROM `tb_kompetensib`
                             LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                             '.$prodi_id
                             );

                             $data['Kemampuanadaptasi_b'] = [];


                             foreach ($query_b_Kemampuanadaptasi as $key => $value) {
                                 array_push($data['Kemampuanadaptasi_b'], (int)$value->jumlah);

                             }

                             //-------------------------------------------------

                             $query_b_Loyalitas = DB::select('SELECT *, SUM(Loyalitas) as jumlah  FROM `tb_kompetensib`
                             LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                             '.$prodi_id
                             );

                             $data['Loyalitas_b'] = [];


                             foreach ($query_b_Loyalitas as $key => $value) {
                                 array_push($data['Loyalitas_b'], (int)$value->jumlah);

                             }

                             //-------------------------------------------------

                             $query_b_Integritas = DB::select('SELECT *, SUM(Integritas) as jumlah  FROM `tb_kompetensib`
                             LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                             '.$prodi_id
                             );

                             $data['Integritas_b'] = [];


                             foreach ($query_b_Integritas as $key => $value) {
                                 array_push($data['Integritas_b'], (int)$value->jumlah);

                             }

                             //-------------------------------------------------

                             $query_b_Bekerjadenganorangyangberbedabudayamaupunlatarbelakang = DB::select('SELECT *, SUM(Bekerjadenganorangyangberbedabudayamaupunlatarbelakang) as jumlah  FROM `tb_kompetensib`
                             LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                             '.$prodi_id
                             );

                             $data['Bekerjadenganorangyangberbedabudayamaupunlatarbelakang_b'] = [];


                             foreach ($query_b_Bekerjadenganorangyangberbedabudayamaupunlatarbelakang as $key => $value) {
                                 array_push($data['Bekerjadenganorangyangberbedabudayamaupunlatarbelakang_b'], (int)$value->jumlah);

                             }

                             //-------------------------------------------------

                             $query_b_Kepemimpinan = DB::select('SELECT *, SUM(Kepemimpinan) as jumlah  FROM `tb_kompetensib`
                             LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                             '.$prodi_id
                             );

                             $data['Kepemimpinan_b'] = [];


                             foreach ($query_b_Kepemimpinan as $key => $value) {
                                 array_push($data['Kepemimpinan_b'], (int)$value->jumlah);

                             }

                              //-------------------------------------------------

                              $query_b_Kemampuandalammemegangtanggungjawab = DB::select('SELECT *, SUM(Kemampuandalammemegangtanggungjawab) as jumlah  FROM `tb_kompetensib`
                              LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                              '.$prodi_id
                              );

                              $data['Kemampuandalammemegangtanggungjawab_b'] = [];


                              foreach ($query_b_Kemampuandalammemegangtanggungjawab as $key => $value) {
                                  array_push($data['Kemampuandalammemegangtanggungjawab_b'], (int)$value->jumlah);

                              }

                              //-------------------------------------------------

                              $query_b_Inisiatif = DB::select('SELECT *, SUM(Inisiatif) as jumlah  FROM `tb_kompetensib`
                              LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                              '.$prodi_id
                              );

                              $data['Inisiatif_b'] = [];


                              foreach ($query_b_Inisiatif as $key => $value) {
                                  array_push($data['Inisiatif_b'], (int)$value->jumlah);

                              }

                                //-------------------------------------------------

                                $query_b_Manajemenproyekprogram = DB::select('SELECT *, SUM(Manajemenproyekprogram) as jumlah  FROM `tb_kompetensib`
                                LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                                '.$prodi_id
                                );

                                $data['Manajemenproyekprogram_b'] = [];


                                foreach ($query_b_Manajemenproyekprogram as $key => $value) {
                                    array_push($data['Manajemenproyekprogram_b'], (int)$value->jumlah);

                                }

                                 //-------------------------------------------------

                                 $query_b_Kemampuanuntukmemresentasikanide = DB::select('SELECT *, SUM(Kemampuanuntukmemresentasikanide) as jumlah  FROM `tb_kompetensib`
                                 LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                                 '.$prodi_id
                                 );

                                 $data['Kemampuanuntukmemresentasikanide_b'] = [];


                                 foreach ($query_b_Kemampuanuntukmemresentasikanide as $key => $value) {
                                     array_push($data['Kemampuanuntukmemresentasikanide_b'], (int)$value->jumlah);

                                 }

                                 //-------------------------------------------------

                                 $query_b_Kemampuandalammenulislaporan = DB::select('SELECT Kemampuandalammenulislaporan, SUM(Kemampuandalammenulislaporan) as jumlah  FROM `tb_kompetensib`
                                 LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                                 '.$prodi_id
                                 );

                                 $data['Kemampuandalammenulislaporan_b'] = [];


                                 foreach ($query_b_Kemampuandalammenulislaporan as $key => $value) {
                                     array_push($data['Kemampuandalammenulislaporan_b'], (int)$value->jumlah);

                                 }

                                  //-------------------------------------------------

                                  $query_b_Kemampuanuntukterusbelajarsepanjanghayat = DB::select('SELECT Kemampuanuntukterusbelajarsepanjanghayat, SUM(Kemampuanuntukterusbelajarsepanjanghayat) as jumlah  FROM `tb_kompetensib`
                                  LEFT JOIN tb_mahasiswa ON tb_kompetensib.npm = tb_mahasiswa.npm
                                  '.$prodi_id
                                  );


                                  $data['Kemampuanuntukterusbelajarsepanjanghayat_b'] = [];


                                  foreach ($query_b_Kemampuanuntukterusbelajarsepanjanghayat as $key => $value) {
                                      array_push($data['Kemampuanuntukterusbelajarsepanjanghayat_b'], (int)$value->jumlah);

                                  }
                                    $data['push_kategori_b'] =  [];
                                    array_push($data['push_kategori_b'],
                                        $data['PengetahuandibidangataudisiplinilmuAnda_b'],
                                        $data['PengetahuandiluarbidangataudisiplinilmuAnda_b'],
                                        $data['Pengetahuanumum_b'],
                                        $data['BahasaInggris_b'],
                                        $data['Ketrampilaninternet_b'],
                                        $data['Ketrampilankomputer_b'],
                                        $data['Berpikirkritis_b'],
                                        $data['KeterampilanRiset_b'],
                                        $data['Kemampuanbelajar_b'],
                                        $data['Kemampuanberkomunikasi_b'],
                                        $data['Bekerjadibawahtekanan_b'],
                                        $data['Manajemenwaktu_b'],
                                        $data['Bekerjasecaramandiri_b'],
                                        $data['Bekerjadalamtimbekerjasama_b'],
                                        $data['Kemampuandalammemecahkanmasalah_b'],
                                        $data['Negosiasi_b'],
                                        $data['Kemampuananalisis_b'],
                                        $data['Toleransi_b'],
                                        $data['Kemampuanadaptasi_b'],
                                        $data['Loyalitas_b'],
                                        $data['Integritas_b'],
                                        $data['Bekerjadenganorangyangberbedabudayamaupunlatarbelakang_b'],
                                        $data['Kepemimpinan_b'],
                                        $data['Kemampuandalammemegangtanggungjawab_b'],
                                        $data['Inisiatif_b'],
                                        $data['Manajemenproyekprogram_b'],
                                        $data['Kemampuanuntukmemresentasikanide_b'],
                                        $data['Kemampuandalammenulislaporan_b'],
                                        $data['Kemampuanuntukterusbelajarsepanjanghayat_b']

                                    );
        // dd($data);

        return $data;
    }

    public function exportExcel_a(){

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $i = 5;
        $no=1;
        $query = '';


        if(Auth::user()->role_id == 1){
            $query = DB::table('tb_kompetensia')
            ->Leftjoin('tb_mahasiswa', 'tb_kompetensia.npm',  'tb_mahasiswa.npm')
            ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
            ->get();
        }else if(Auth::user()->role_id == 2){
            $query = DB::table('tb_kompetensia')
            ->Leftjoin('tb_mahasiswa', 'tb_kompetensia.npm',  'tb_mahasiswa.npm')
            ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
            ->where('mhs_fakultas_id', Auth::user()->fakultas_user_id)
            ->get();
        }
        else{
            $query = DB::table('tb_kompetensia')
            ->Leftjoin('tb_mahasiswa', 'tb_kompetensia.npm',  'tb_mahasiswa.npm')
            ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
            ->where('kode_prodi_id', Auth::user()->prodi_id)
            ->get();
        }

        // dd($query);

        $sheet->setCellValue('B2', 'LAPORAN TRACER STUDY - KOMPETENSI A');

        $sheet->setCellValue('A3', 'NO');
        $sheet->setCellValue('B3', 'NPM');
        $sheet->setCellValue('C3', 'NAMA');
        $sheet->setCellValue('D3', 'PRODI');
        $sheet->setCellValue('E3', 'TAHUN LULUS');
        $sheet->setCellValue('F3', 'PengetahuandibidangataudisiplinilmuAnda');
        $sheet->setCellValue('G3', 'PengetahuandiluarbidangataudisiplinilmuAnda');
        $sheet->setCellValue('H3', 'Pengetahuanumum');
        $sheet->setCellValue('I3', 'BahasaInggris');
        $sheet->setCellValue('J3', 'Ketrampilaninternet');
        $sheet->setCellValue('K3', 'Ketrampilankomputer');
        $sheet->setCellValue('L3', 'Berpikirkritis');
        $sheet->setCellValue('M3', 'KeterampilanRiset');
        $sheet->setCellValue('N3', 'Kemampuanbelajar');
        $sheet->setCellValue('O3', 'Kemampuanberkomunikasi');
        $sheet->setCellValue('P3', 'Bekerjadibawahtekanan');
        $sheet->setCellValue('Q3', 'Manajemenwaktu');
        $sheet->setCellValue('R3', 'Bekerjasecaramandiri');
        $sheet->setCellValue('S3', 'Bekerjadalamtimbekerjasama');
        $sheet->setCellValue('T3', 'Kemampuandalammemecahkanmasalah');
        $sheet->setCellValue('U3', 'Negosiasi');
        $sheet->setCellValue('V3', 'Kemampuananalisis');
        $sheet->setCellValue('W3', 'Toleransi');
        $sheet->setCellValue('X3', 'Kemampuanadaptasi');
        $sheet->setCellValue('Y3', 'Loyalitas');
        $sheet->setCellValue('Z3', 'Integritas');
        $sheet->setCellValue('AA3', 'Bekerjadenganorangyangberbeda');
        $sheet->setCellValue('AB3', 'Kepemimpinan');
        $sheet->setCellValue('AC3', 'Kemampuandalammemegangtanggungjawab');
        $sheet->setCellValue('AD3', 'Inisiatif');
        $sheet->setCellValue('AE3', 'Manajemenproyekprogram');
        $sheet->setCellValue('AF3', 'Kemampuanuntukmemresentasikanide');
        $sheet->setCellValue('AG3', 'Kemampuandalammenulislaporan');
        $sheet->setCellValue('AH3', 'Kemampuanuntukterusbelajarsepanjanghayat');


        //filte
        $sheet->setAutoFilter('A1:AH1');
        //color cell
            //warna nomer

            //warna depart

        //freeze pane

        $sheet->freezePaneByColumnAndRow(1,'D1');
        $sheet->freezePane('D5');

        //merge cells
        $sheet->mergeCells("B2:I2");
        $sheet->mergeCells("A3:A4");
        $sheet->mergeCells("B3:B4");
        $sheet->mergeCells("C3:C4");
        $sheet->mergeCells("D3:D4");
        $sheet->mergeCells("E3:E4");
        $sheet->mergeCells("F3:F4");
        $sheet->mergeCells("G3:G4");
        $sheet->mergeCells("H3:H4");
        $sheet->mergeCells("I3:I4");
        $sheet->mergeCells("J3:J4");
        $sheet->mergeCells('K3:K4');
        $sheet->mergeCells('L3:L4');
        $sheet->mergeCells('M3:M4');
        $sheet->mergeCells('N3:N4');
        $sheet->mergeCells('O3:O4');
        $sheet->mergeCells('P3:P4');
        $sheet->mergeCells('Q3:Q4');
        $sheet->mergeCells('R3:R4');
        $sheet->mergeCells('S3:S4');
        $sheet->mergeCells('T3:T4');
        $sheet->mergeCells('U3:U4');
        $sheet->mergeCells('V3:V4');
        $sheet->mergeCells('W3:W4');
        $sheet->mergeCells('X3:X4');
        $sheet->mergeCells('Y3:Y4');
        $sheet->mergeCells('Z3:Z4');
        $sheet->mergeCells('AA3:AA4');
        $sheet->mergeCells('AB3:AB4');
        $sheet->mergeCells('AC3:AC4');
        $sheet->mergeCells('AD3:AD4');
        $sheet->mergeCells('AE3:AE4');
        $sheet->mergeCells('AF3:AF4');
        $sheet->mergeCells('AG3:AG4');
        $sheet->mergeCells('AH3:AH4');


        //size cells
        $sheet->getColumnDimension('A')->setWidth(5);
        $sheet->getColumnDimension('B')->setWidth(20);
        $sheet->getColumnDimension('C')->setWidth(23);
        $sheet->getColumnDimension('D')->setWidth(20);
        $sheet->getColumnDimension('E')->setWidth(15);
        $sheet->getColumnDimension('F')->setWidth(20);
        $sheet->getColumnDimension('G')->setWidth(20);
        $sheet->getColumnDimension('H')->setWidth(20);
        $sheet->getColumnDimension('I')->setWidth(20);
        $sheet->getColumnDimension('J')->setWidth(20);
        $sheet->getColumnDimension('K')->setWidth(20);
        $sheet->getColumnDimension('L')->setWidth(20);
        $sheet->getColumnDimension('M')->setWidth(20);
        $sheet->getColumnDimension('N')->setWidth(20);
        $sheet->getColumnDimension('O')->setWidth(20);
        $sheet->getColumnDimension('P')->setWidth(20);
        $sheet->getColumnDimension('Q')->setWidth(20);
        $sheet->getColumnDimension('R')->setWidth(20);
        $sheet->getColumnDimension('S')->setWidth(20);
        $sheet->getColumnDimension('T')->setWidth(20);
        $sheet->getColumnDimension('U')->setWidth(20);
        $sheet->getColumnDimension('V')->setWidth(20);
        $sheet->getColumnDimension('W')->setWidth(20);
        $sheet->getColumnDimension('X')->setWidth(20);
        $sheet->getColumnDimension('Y')->setWidth(20);
        $sheet->getColumnDimension('Z')->setWidth(20);
        $sheet->getColumnDimension('AA')->setWidth(20);
        $sheet->getColumnDimension('AB')->setWidth(20);
        $sheet->getColumnDimension('AC')->setWidth(20);
        $sheet->getColumnDimension('AD')->setWidth(20);
        $sheet->getColumnDimension('AE')->setWidth(20);
        $sheet->getColumnDimension('AF')->setWidth(20);
        $sheet->getColumnDimension('AG')->setWidth(20);
        $sheet->getColumnDimension('AH')->setWidth(20);



        $styleArray = [
            'alignment' => [
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
                'wrapText' => true,
             ],
             'borders' => [
                'allBorders' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                ],
            ],

        ];
        $styleHeader = [
            'alignment' => [
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
                'wrapText' => true,
             ],
             'borders' => [
                'allBorders' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                ],
            ],

        ];
        $styletitle = [

            'font' => [
                'name' => 'Century Gothic',
                'size' => 14,
                'bold' => true,
                'color' => ['argb' => '000000'],
            ],

        ];
        $styleheader = [

            'font' => [
                'size' => 11,
                'bold' => true,
                'color' => ['argb' => '000000'],
            ],

        ];
        $count = count($query);
        $sheet->getStyle('A5:AH50')->applyFromArray($styleArray);
        $sheet->getStyle('A3:AH4')->applyFromArray($styleHeader);
        $sheet->getStyle('A2:D2')->applyFromArray($styletitle);
        $sheet->getStyle('A3:AH3')->applyFromArray($styleheader);



        foreach ($query as $key => $value) {
            $sheet->setCellValue('A'.$i, $no++);
            $sheet->setCellValue('B'.$i, $value->npm);
            $sheet->setCellValue('C'.$i, $value->nama);
            $sheet->setCellValue('D'.$i, $value->prodi);
            $sheet->setCellValue('E'.$i, $value->tahun_lulus);
            $sheet->setCellValue('F'.$i, $value->PengetahuandibidangataudisiplinilmuAnda);
            $sheet->setCellValue('G'.$i, $value->PengetahuandiluarbidangataudisiplinilmuAnda);
            $sheet->setCellValue('H'.$i, $value->Pengetahuanumum);
            $sheet->setCellValue('I'.$i, $value->BahasaInggris);
            $sheet->setCellValue('J'.$i, $value->Ketrampilaninternet);
            $sheet->setCellValue('K'.$i, $value->Ketrampilankomputer);
            $sheet->setCellValue('L'.$i, $value->Berpikirkritis);
            $sheet->setCellValue('M'.$i, $value->KeterampilanRiset);
            $sheet->setCellValue('N'.$i, $value->Kemampuanbelajar);
            $sheet->setCellValue('O'.$i, $value->Kemampuanberkomunikasi);
            $sheet->setCellValue('P'.$i, $value->Bekerjadibawahtekanan);
            $sheet->setCellValue('Q'.$i, $value->Manajemenwaktu);
            $sheet->setCellValue('R'.$i, $value->Bekerjasecaramandiri);
            $sheet->setCellValue('S'.$i, $value->Bekerjadalamtimbekerjasama);
            $sheet->setCellValue('T'.$i, $value->Kemampuandalammemecahkanmasalah);
            $sheet->setCellValue('U'.$i, $value->Negosiasi);
            $sheet->setCellValue('V'.$i, $value->Kemampuananalisis);
            $sheet->setCellValue('W'.$i, $value->Toleransi);
            $sheet->setCellValue('X'.$i, $value->Kemampuanadaptasi);
            $sheet->setCellValue('Y'.$i, $value->Loyalitas);
            $sheet->setCellValue('Z'.$i, $value->Integritas);
            $sheet->setCellValue('AA'.$i, $value->Bekerjadenganorangyangberbedabudayamaupunlatarbelakang);
            $sheet->setCellValue('AB'.$i, $value->Kepemimpinan);
            $sheet->setCellValue('AC'.$i, $value->Kemampuandalammemegangtanggungjawab);
            $sheet->setCellValue('AD'.$i, $value->Inisiatif);
            $sheet->setCellValue('AE'.$i, $value->Manajemenproyekprogram);
            $sheet->setCellValue('AF'.$i, $value->Kemampuanuntukmemresentasikanide);
            $sheet->setCellValue('AG'.$i, $value->Kemampuandalammenulislaporan);
            $sheet->setCellValue('AH'.$i, $value->Kemampuanuntukterusbelajarsepanjanghayat);

            $i++;
        }

        $writer = new Xlsx($spreadsheet);
        $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, "Xlsx");
        $date = date('d-F-Y');
        $file_name = 'Laporan Kompetensi A - '. $date.'.xlsx';
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="'.$file_name.'"');
        $writer->save("php://output");
        }

        public function exportExcel_b(){

            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $i = 5;
            $no=1;
            $query = '';


            if(Auth::user()->role_id == 1){
                $query = DB::table('tb_kompetensib')
                ->Leftjoin('tb_mahasiswa', 'tb_kompetensib.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                ->get();
            }else if(Auth::user()->role_id == 2){
                $query = DB::table('tb_kompetensib')
                ->Leftjoin('tb_mahasiswa', 'tb_kompetensib.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                ->where('mhs_fakultas_id', Auth::user()->fakultas_user_id)
                ->get();
            }
            else{
                $query = DB::table('tb_kompetensib')
                ->Leftjoin('tb_mahasiswa', 'tb_kompetensib.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                ->where('kode_prodi_id', Auth::user()->prodi_id)
                ->get();
            }

            // dd($query);

            $sheet->setCellValue('B2', 'LAPORAN TRACER STUDY - KOMPETENSI B');

            $sheet->setCellValue('A3', 'NO');
            $sheet->setCellValue('B3', 'NPM');
            $sheet->setCellValue('C3', 'NAMA');
            $sheet->setCellValue('D3', 'PRODI');
            $sheet->setCellValue('E3', 'TAHUN LULUS');
            $sheet->setCellValue('F3', 'PengetahuandibidangataudisiplinilmuAnda');
            $sheet->setCellValue('G3', 'PengetahuandiluarbidangataudisiplinilmuAnda');
            $sheet->setCellValue('H3', 'Pengetahuanumum');
            $sheet->setCellValue('I3', 'BahasaInggris');
            $sheet->setCellValue('J3', 'Ketrampilaninternet');
            $sheet->setCellValue('K3', 'Ketrampilankomputer');
            $sheet->setCellValue('L3', 'Berpikirkritis');
            $sheet->setCellValue('M3', 'KeterampilanRiset');
            $sheet->setCellValue('N3', 'Kemampuanbelajar');
            $sheet->setCellValue('O3', 'Kemampuanberkomunikasi');
            $sheet->setCellValue('P3', 'Bekerjadibawahtekanan');
            $sheet->setCellValue('Q3', 'Manajemenwaktu');
            $sheet->setCellValue('R3', 'Bekerjasecaramandiri');
            $sheet->setCellValue('S3', 'Bekerjadalamtimbekerjasama');
            $sheet->setCellValue('T3', 'Kemampuandalammemecahkanmasalah');
            $sheet->setCellValue('U3', 'Negosiasi');
            $sheet->setCellValue('V3', 'Kemampuananalisis');
            $sheet->setCellValue('W3', 'Toleransi');
            $sheet->setCellValue('X3', 'Kemampuanadaptasi');
            $sheet->setCellValue('Y3', 'Loyalitas');
            $sheet->setCellValue('Z3', 'Integritas');
            $sheet->setCellValue('AA3', 'Bekerjadenganorangyangberbeda');
            $sheet->setCellValue('AB3', 'Kepemimpinan');
            $sheet->setCellValue('AC3', 'Kemampuandalammemegangtanggungjawab');
            $sheet->setCellValue('AD3', 'Inisiatif');
            $sheet->setCellValue('AE3', 'Manajemenproyekprogram');
            $sheet->setCellValue('AF3', 'Kemampuanuntukmemresentasikanide');
            $sheet->setCellValue('AG3', 'Kemampuandalammenulislaporan');
            $sheet->setCellValue('AH3', 'Kemampuanuntukterusbelajarsepanjanghayat');


            //filte
            $sheet->setAutoFilter('A1:AH1');
            //color cell
                //warna nomer

                //warna depart

            //freeze pane

            $sheet->freezePaneByColumnAndRow(1,'D1');
            $sheet->freezePane('D5');

            //merge cells
            $sheet->mergeCells("B2:I2");
            $sheet->mergeCells("A3:A4");
            $sheet->mergeCells("B3:B4");
            $sheet->mergeCells("C3:C4");
            $sheet->mergeCells("D3:D4");
            $sheet->mergeCells("E3:E4");
            $sheet->mergeCells("F3:F4");
            $sheet->mergeCells("G3:G4");
            $sheet->mergeCells("H3:H4");
            $sheet->mergeCells("I3:I4");
            $sheet->mergeCells("J3:J4");
            $sheet->mergeCells('K3:K4');
            $sheet->mergeCells('L3:L4');
            $sheet->mergeCells('M3:M4');
            $sheet->mergeCells('N3:N4');
            $sheet->mergeCells('O3:O4');
            $sheet->mergeCells('P3:P4');
            $sheet->mergeCells('Q3:Q4');
            $sheet->mergeCells('R3:R4');
            $sheet->mergeCells('S3:S4');
            $sheet->mergeCells('T3:T4');
            $sheet->mergeCells('U3:U4');
            $sheet->mergeCells('V3:V4');
            $sheet->mergeCells('W3:W4');
            $sheet->mergeCells('X3:X4');
            $sheet->mergeCells('Y3:Y4');
            $sheet->mergeCells('Z3:Z4');
            $sheet->mergeCells('AA3:AA4');
            $sheet->mergeCells('AB3:AB4');
            $sheet->mergeCells('AC3:AC4');
            $sheet->mergeCells('AD3:AD4');
            $sheet->mergeCells('AE3:AE4');
            $sheet->mergeCells('AF3:AF4');
            $sheet->mergeCells('AG3:AG4');
            $sheet->mergeCells('AH3:AH4');


            //size cells
            $sheet->getColumnDimension('A')->setWidth(5);
            $sheet->getColumnDimension('B')->setWidth(20);
            $sheet->getColumnDimension('C')->setWidth(23);
            $sheet->getColumnDimension('D')->setWidth(20);
            $sheet->getColumnDimension('E')->setWidth(15);
            $sheet->getColumnDimension('F')->setWidth(20);
            $sheet->getColumnDimension('G')->setWidth(20);
            $sheet->getColumnDimension('H')->setWidth(20);
            $sheet->getColumnDimension('I')->setWidth(20);
            $sheet->getColumnDimension('J')->setWidth(20);
            $sheet->getColumnDimension('K')->setWidth(20);
            $sheet->getColumnDimension('L')->setWidth(20);
            $sheet->getColumnDimension('M')->setWidth(20);
            $sheet->getColumnDimension('N')->setWidth(20);
            $sheet->getColumnDimension('O')->setWidth(20);
            $sheet->getColumnDimension('P')->setWidth(20);
            $sheet->getColumnDimension('Q')->setWidth(20);
            $sheet->getColumnDimension('R')->setWidth(20);
            $sheet->getColumnDimension('S')->setWidth(20);
            $sheet->getColumnDimension('T')->setWidth(20);
            $sheet->getColumnDimension('U')->setWidth(20);
            $sheet->getColumnDimension('V')->setWidth(20);
            $sheet->getColumnDimension('W')->setWidth(20);
            $sheet->getColumnDimension('X')->setWidth(20);
            $sheet->getColumnDimension('Y')->setWidth(20);
            $sheet->getColumnDimension('Z')->setWidth(20);
            $sheet->getColumnDimension('AA')->setWidth(20);
            $sheet->getColumnDimension('AB')->setWidth(20);
            $sheet->getColumnDimension('AC')->setWidth(20);
            $sheet->getColumnDimension('AD')->setWidth(20);
            $sheet->getColumnDimension('AE')->setWidth(20);
            $sheet->getColumnDimension('AF')->setWidth(20);
            $sheet->getColumnDimension('AG')->setWidth(20);
            $sheet->getColumnDimension('AH')->setWidth(20);



            $styleArray = [
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
                    'wrapText' => true,
                 ],
                 'borders' => [
                    'allBorders' => [
                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                    ],
                ],

            ];
            $styleHeader = [
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                    'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
                    'wrapText' => true,
                 ],
                 'borders' => [
                    'allBorders' => [
                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                    ],
                ],

            ];
            $styletitle = [

                'font' => [
                    'name' => 'Century Gothic',
                    'size' => 14,
                    'bold' => true,
                    'color' => ['argb' => '000000'],
                ],

            ];
            $styleheader = [

                'font' => [
                    'size' => 11,
                    'bold' => true,
                    'color' => ['argb' => '000000'],
                ],

            ];
            $count = count($query);
            $sheet->getStyle('A5:AH50')->applyFromArray($styleArray);
            $sheet->getStyle('A3:AH4')->applyFromArray($styleHeader);
            $sheet->getStyle('A2:D2')->applyFromArray($styletitle);
            $sheet->getStyle('A3:AH3')->applyFromArray($styleheader);



            foreach ($query as $key => $value) {
                $sheet->setCellValue('A'.$i, $no++);
                $sheet->setCellValue('B'.$i, $value->npm);
                $sheet->setCellValue('C'.$i, $value->nama);
                $sheet->setCellValue('D'.$i, $value->prodi);
                $sheet->setCellValue('E'.$i, $value->tahun_lulus);
                $sheet->setCellValue('F'.$i, $value->PengetahuandibidangataudisiplinilmuAnda);
                $sheet->setCellValue('G'.$i, $value->PengetahuandiluarbidangataudisiplinilmuAnda);
                $sheet->setCellValue('H'.$i, $value->Pengetahuanumum);
                $sheet->setCellValue('I'.$i, $value->BahasaInggris);
                $sheet->setCellValue('J'.$i, $value->Ketrampilaninternet);
                $sheet->setCellValue('K'.$i, $value->Ketrampilankomputer);
                $sheet->setCellValue('L'.$i, $value->Berpikirkritis);
                $sheet->setCellValue('M'.$i, $value->KeterampilanRiset);
                $sheet->setCellValue('N'.$i, $value->Kemampuanbelajar);
                $sheet->setCellValue('O'.$i, $value->Kemampuanberkomunikasi);
                $sheet->setCellValue('P'.$i, $value->Bekerjadibawahtekanan);
                $sheet->setCellValue('Q'.$i, $value->Manajemenwaktu);
                $sheet->setCellValue('R'.$i, $value->Bekerjasecaramandiri);
                $sheet->setCellValue('S'.$i, $value->Bekerjadalamtimbekerjasama);
                $sheet->setCellValue('T'.$i, $value->Kemampuandalammemecahkanmasalah);
                $sheet->setCellValue('U'.$i, $value->Negosiasi);
                $sheet->setCellValue('V'.$i, $value->Kemampuananalisis);
                $sheet->setCellValue('W'.$i, $value->Toleransi);
                $sheet->setCellValue('X'.$i, $value->Kemampuanadaptasi);
                $sheet->setCellValue('Y'.$i, $value->Loyalitas);
                $sheet->setCellValue('Z'.$i, $value->Integritas);
                $sheet->setCellValue('AA'.$i, $value->Bekerjadenganorangyangberbedabudayamaupunlatarbelakang);
                $sheet->setCellValue('AB'.$i, $value->Kepemimpinan);
                $sheet->setCellValue('AC'.$i, $value->Kemampuandalammemegangtanggungjawab);
                $sheet->setCellValue('AD'.$i, $value->Inisiatif);
                $sheet->setCellValue('AE'.$i, $value->Manajemenproyekprogram);
                $sheet->setCellValue('AF'.$i, $value->Kemampuanuntukmemresentasikanide);
                $sheet->setCellValue('AG'.$i, $value->Kemampuandalammenulislaporan);
                $sheet->setCellValue('AH'.$i, $value->Kemampuanuntukterusbelajarsepanjanghayat);

                $i++;
            }

            $writer = new Xlsx($spreadsheet);
            $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, "Xlsx");
            $date = date('d-F-Y');
            $file_name = 'Laporan Kompetensi B - '. $date.'.xlsx';
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="'.$file_name.'"');
            $writer->save("php://output");
            }

}
