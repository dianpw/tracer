<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;

class DashboardController extends Controller
{
    public function index()
    {
        if(Auth::user()->role_id == 2){
            $auth_user = DB::table('users')
            ->leftJoin('tm_fakultas', 'users.fakultas_user_id', 'tm_fakultas.id')
            ->where('users.id', Auth::user()->id)
            ->first();
        }else if(Auth::user()->role_id == 3){
            $auth_user = DB::table('users')
            ->leftJoin('tm_kode_prodi', 'users.prodi_id', 'tm_kode_prodi.kode')
            ->where('id', Auth::user()->id)
            ->first();
        }else{
            $auth_user = DB::table('users')
            ->where('id', Auth::user()->id)
            ->first();
        }

        $role = Auth::user()->role_id;
        $total_mhs = '';
        $total_sdh_mengisi = '';
        $belum_mengisi = '';
        if($role == 1){
            $total_mhs = DB::table('tb_mahasiswa')
                ->count();
            $total_sdh_mengisi = DB::table('tb_biodata')
				 ->Leftjoin('tb_mahasiswa', 'tb_biodata.npm',  'tb_mahasiswa.npm')
				 ->whereNotNull('tb_mahasiswa.npm')
                ->count();
            $belum_mengisi = $total_mhs -  $total_sdh_mengisi;

        }else if($role == 2){
            $ex_prodi = explode(',', Auth::user()->prodi_id);

            $total_mhs = DB::table('tb_mahasiswa')

                ->whereIn('kode_prodi_id', $ex_prodi)
                ->count();
            $total_sdh_mengisi = DB::table('tb_biodata')
                ->Leftjoin('tb_mahasiswa', 'tb_biodata.npm', 'tb_mahasiswa.npm')
                ->whereIn('kode_prodi_id', $ex_prodi)
                ->count();
            $belum_mengisi = $total_mhs -  $total_sdh_mengisi;

        }else if($role == 3){
            $total_mhs = DB::table('tb_mahasiswa')
                ->where('kode_prodi_id', Auth::user()->prodi_id)
                ->count();
            $total_sdh_mengisi = DB::table('tb_biodata')
                ->Leftjoin('tb_mahasiswa', 'tb_biodata.npm', 'tb_mahasiswa.npm')
                ->where('kode_prodi_id', Auth::user()->prodi_id)
                ->count();
            $belum_mengisi = $total_mhs -  $total_sdh_mengisi;
        }



        // dd($belum_mengisi);
        return view('dashboard.index', compact('auth_user', 'total_mhs', 'total_sdh_mengisi', 'belum_mengisi'));
    }

     public function graph(){
        $role = Auth::user()->role_id;
        if($role == 1){
            $total_mhs = DB::table('tb_mahasiswa')
                    ->count();
            $total_sdh_mengisi = DB::table('tb_biodata')
                    ->count();

        }else if($role == 2){
            $ex_prodi = explode(',', Auth::user()->prodi_id);
            $total_mhs = DB::table('tb_mahasiswa')
                ->whereIn('kode_prodi_id', $ex_prodi)
                ->count();
            $total_sdh_mengisi = DB::table('tb_biodata')
                ->Leftjoin('tb_mahasiswa', 'tb_biodata.npm', 'tb_mahasiswa.npm')
                ->whereIn('kode_prodi_id', $ex_prodi)
                ->count();

        }else if($role == 3){
            $total_mhs = DB::table('tb_mahasiswa')
                ->where('kode_prodi_id', Auth::user()->prodi_id)
                ->count();
            $total_sdh_mengisi = DB::table('tb_biodata')
                ->Leftjoin('tb_mahasiswa', 'tb_biodata.npm', 'tb_mahasiswa.npm')
                ->where('kode_prodi_id', Auth::user()->prodi_id)
                ->count();

        }

        $belum_mengisi = $total_mhs -  $total_sdh_mengisi;
        $data['sudah_mengisi'] = [];
        $data['belum_mengisi'] = [];
        $hsl = $total_mhs -  $total_sdh_mengisi;

        array_push($data['sudah_mengisi'], $total_sdh_mengisi);
        array_push($data['belum_mengisi'], $hsl);

        return $data;
    }
}
