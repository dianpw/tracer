<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\User;
use App\QuisionerModel;
use Illuminate\Support\Facades\Redirect;

class QuisionerController extends Controller
{
    public function pageQuisioner($npm=null){
        $data_mhs = DB::table('tb_mahasiswa')
                ->select('*')
                ->where('npm', '=', $npm)
                ->first();
        if($data_mhs == null){
            return view('not_found');
        }else{
            return view('quisioner.index', compact('data_mhs'));
        }
        // dd($pertanyaan_awal);

    }

    public function fetch(Request $request){
        $pertanyaan1 = DB::table('tb_quisioner')
            ->where('id', 1)
            ->first();
        $opsi_pertanyaan = DB::table('tb_pilihan_jawaban_quisioner')
                        ->where('quisioner_id', $pertanyaan1->id)
                        ->get();
        $data_opsi_pertanyaan = [];
        foreach($opsi_pertanyaan as $key => $value){
            array_push($data_opsi_pertanyaan,  [$value->id, $value->pilihan, $value->keterangan]);
        }
        $pertanyaan_awal = [];
        array_push($pertanyaan_awal, ['pertanyaan' => $pertanyaan1,
                                      'opsi'       => $data_opsi_pertanyaan
        ]);
        // dd($pertanyaan_awal);
        echo json_encode($pertanyaan_awal);
    }

    public function get_data_quisioner($nim){
        $query = DB::table('tb_result_quisioner')
                ->where('nim', $nim)
                ->get();
        dd($query);
    }

    public function submit_tracer(Request $request){
        //-------------------------Organisasi kemahasiswaan apa yang pernah Saudara ikuti saat kuliah di UNISMA------------------------------
        $post = $request->all();

        $replace_biodata = DB::Table('tb_biodata')
        ->where('npm', $post['npm'])
        ->delete();

        DB::table('tb_biodata')
        ->insert([
            'npm'               => $request->npm,
            'email'             => $request->email,
            'jenis_kelamin'     => $request->jeniskelamin,
            'no_hp'             => $request->no_whatsapp,
            'alamat'            => $request->alamat

            ]);
        $replace_organisasi_dalam_kemahasiswaan = DB::Table('tb_organisasi_kemahasiswaan_yang_diikuti')
                                                ->where('npm', $post['npm'])
                                                ->delete();
        if($request->organisasi_dalam_kemahasiswaan != null){
            $request_organisasi_dalam_kemahasiswaan = count($request->organisasi_dalam_kemahasiswaan);
            // dd($request_organisasi_dalam_kemahasiswaan);
            for($a_organisasi=0; $a_organisasi < $request_organisasi_dalam_kemahasiswaan ;$a_organisasi++){
                DB::table('tb_organisasi_kemahasiswaan_yang_diikuti')
                ->insert([
                    'npm'        => $request->npm,
                    'organisasi' => $request->organisasi_dalam_kemahasiswaan[$a_organisasi]
                    ]);
            }
        }

        //----------------------------kedudukan saudara sebagai pengurus kegiatan---------------------

        $replace_pengurus_kegiatan = DB::Table('tb_pengurus_kegiatan_organisasi')
                    ->where('npm', $post['npm'])
                    ->delete();

        DB::table('tb_pengurus_kegiatan_organisasi')
        ->insert([
            'npm'                           => $request->npm,
            'kedudukan_saudara'             => $request->kedudukansaudara

            ]);


        //----------------------------kedudukan saudara sebagai panitia kegiatan---------------------

        $replace_panitia_kegiatan_organisasi = DB::Table('tb_panitia_kegiatan_organisasi')
        ->where('npm', $post['npm'])
        ->delete();

        DB::table('tb_panitia_kegiatan_organisasi')
            ->insert([
            'npm'                           => $request->npm,
            'panitia_kegiatan'             => $request->panitiakegiatan

        ]);

        //----------------------------Apakah Saudara mengikuti organisasi kemahasiswaan berbasis ke NU an? ---------------------

        $replace_panitia_kegiatan_organisasi = DB::Table('tb_organisasi_nu')
        ->where('npm', $post['npm'])
        ->delete();

        DB::table('tb_organisasi_nu')
            ->insert([
            'npm'                           => $request->npm,
            'organisasi_nu'             => $request->organisasikemahasiswaanNU

        ]);

        //----------------------------Jika YA     ---------------------

        $replace_panitia_kegiatan_organisasi = DB::Table('tb_ya_organisasi_nu')
        ->where('npm', $post['npm'])
        ->delete();

        DB::table('tb_ya_organisasi_nu')
            ->insert([
            'npm'                           => $request->npm,
            'ya_nu'             => $request->organisasiNU

        ]);

         //----------------------------tb_pengurus_kegiatan_organisasi_nu    ---------------------

         $replace_tb_pengurus_kegiatan_organisasi_nu = DB::Table('tb_pengurus_kegiatan_organisasi_nu')
         ->where('npm', $post['npm'])
         ->delete();

         DB::table('tb_pengurus_kegiatan_organisasi_nu')
             ->insert([
             'npm'                           => $request->npm,
             'organisasi'             => $request->kemukakankedudukanpengurusorganisasi

         ]);

           //----------------------------tb_panitia_kegiatan_organisasi_nu    ---------------------

           $replace_tb_panitia_kegiatan_organisasi_nu = DB::Table('tb_panitia_kegiatan_organisasi_nu')
           ->where('npm', $post['npm'])
           ->delete();

           DB::table('tb_panitia_kegiatan_organisasi_nu')
               ->insert([
               'npm'                           => $request->npm,
               'organisasi'             => $request->BerapakaliSaudaramenjadipanitiadalamorganisasi

           ]);

        //-------------------------------pertanyaan f3-----------------------
        DB::Table('tb_waktu_mulai_mencari_pekerjaan')
        ->where('npm', $post['npm'])
        ->delete();
        if($request->pertanyaanf3_input_sebelum != ''){
            DB::table('tb_waktu_mulai_mencari_pekerjaan')
            ->insert([
                'npm'                           => $request->npm,
                'waktu_mulai_mencari_pekerjaan' => $request->pertanyaan_f3,
                'bulan'                         => $request->pertanyaanf3_input_sebelum
                ]);
        }else{
            DB::table('tb_waktu_mulai_mencari_pekerjaan')
            ->insert([
                'npm'                           => $request->npm,
                'waktu_mulai_mencari_pekerjaan' => $request->pertanyaan_f3,
                'bulan'                         => $request->pertanyaanf3_input_setelah
                ]);
        }

        //--------------------------pertanyaan f2---------------------
        DB::Table('tb_penekanan_metode_pembelajaran')
        ->where('npm', $post['npm'])
        ->delete();
        DB::table('tb_penekanan_metode_pembelajaran')
        ->insert([
            'npm'                        => $request->npm,
            'perkuliahan'                     => $request->kuliah,
            'Responsidantutorial'        => $request->responsi,
            'Seminar'                    => $request->seminar,
            'praktikum'                  => $request->praktikum_praktik,
            'praktek_lapangan'           => $request->praktek_lapangan,
            'penelitian'                 => $request->penelitian,
            'pelatihan'                  => $request->pelatihan_militer,
            'pertukaran_pelajar'         => $request->pertukaran_pelajar,
            'magang'                     => $request->magang,
            'Wirausaha'                  => $request->wirausaha,
            'pengabdiankepadamasyarakat' => $request->pengabdian,
             ]);
        //---------------------------pertanyaan f4--------------------------------

        DB::Table('tb_cara_memperoleh_pekerjaan')
        ->where('npm', $post['npm'])
        ->delete();
        DB::table('tb_cara_memperoleh_pekerjaan')
        ->insert([
            'npm'                           => $request->npm,
            'melalui_iklan'                 => $request->pertanyaanf4_iklan,
            'melamar_keperusahaan'          => $request->pertanyaanf4_melamar,
            'pergi_kebursa'                 => $request->pertanyaanf4_pergi,
            'mencari_lewat_internet'        => $request->pertanyaanf4_mencari,
            'dihubungi_oleh_perusahaan'     => $request->pertanyaanf4_dihubungi,
            'menghubungi_kemenakertrans'    => $request->pertanyaanf4_menghubungi_kemenakertrans,
            'memeroleh_informasi_dari_pusat'    => $request->pertanyaanf4_memeroleh,
            'menghubungi_kantor_kemahasiswaan'  => $request->pertanyaanf4_menghubungi_kantor,
            'membangun_jejaring'            => $request->pertanyaanf4_membangun_jejaring,
            'melalui_relasi'                => $request->pertanyaanf4_melalui,
            'membangun_bisnis_sendiri'      => $request->pertanyaanf4_membangun_bisnis,
            'melalui_penempatan_kerja_magang'=> $request->pertanyaanf4_melalui_magang,
            'bekerja_ditempat_yang_sama'    => $request->pertanyaanf4_bekerja_tempat_sama,
            'lainnya'                       => $request->pertanyaanf4_lainnya,

            ]);
             //pertanyaan f5
             DB::Table('tb_masa_tunggu')
                ->where('npm', $post['npm'])
                ->delete();
                if($request->pertanyaanf5input != ''){
                    DB::table('tb_masa_tunggu')
                    ->insert([
                        'npm'                           => $request->npm,
                        'masa_tunggu' => $request->pertanyaan2_f5,
                        'bulan'                         => $request->pertanyaanf5input
                        ]);
                }else{
                    DB::table('tb_masa_tunggu')
                    ->insert([
                        'npm'                           => $request->npm,
                        'masa_tunggu' => $request->pertanyaan2_f5,
                        'bulan'                         => $request->pertanyaanf5input2
                        ]);
                }


     //---------------------pertanyaan f6 - f7a------------------------

        DB::Table('tb_kemulusan_transisi')
            ->where('npm', $post['npm'])
            ->delete();
        DB::table('tb_kemulusan_transisi')
        ->insert([
            'npm'                           => $request->npm,
            'perusahaan_dilamar' => $request->pertanyaanf6,
            'perusahaan_merespon' => $request->pertanyaanf7,
            'perusahaan_mengundang_wawancara' => $request->pertanyaanf7a

            ]);
            //------------------------alumni sudah bekerja--------------

        DB::Table('tb_data_alumni_sudah_bekerja')
            ->where('npm', $post['npm'])
            ->delete();
        DB::table('tb_data_alumni_sudah_bekerja')
        ->insert([
            'npm'                           => $request->npm,
            'nama_perusahaan'               => $request->nama_perusahaan,
            'alamat_perusahaan'             => $request->alamat_tempat_bekerja,
            'no_telp_perusahaan'            => $request->no_telp_perusahaan,
            'nama_atasan'                   => $request->nama_atasan_langsung,
            'nomor_hp_atasan'               => $request->no_hp_atasan,

            ]);
        //------pertanyaan f8-----------------------------
        DB::Table('tb_situasi_saat_ini_1')
        ->where('npm', $post['npm'])
        ->delete();
        DB::table('tb_situasi_saat_ini_1')
        ->insert([
            'npm'                           => $request->npm,
            'bekerja_saat_ini' => $request->pertanyaanf8,

            ]);

            //pertanyaan f9
        DB::Table('tb_situasi_saat_ini_2')
        ->where('npm', $post['npm'])
        ->delete();
        DB::table('tb_situasi_saat_ini_2')
        ->insert([
            'npm'                           => $request->npm,
            'menikah' => $request->pertanyaanf9_menikah,
            'melanjutkan_pendidikan' => $request->pertanyaanf9_belajar,
            'sibuk_dengan_keluarga' => $request->pertanyaanf9_sibuk_keluarga,
            'sedang_mencari_pekerjaan' => $request->pertanyaanf9_sedang_mencari_pekerjaan,
            'lainnya' => $request->pertanyaanf9_lainnya,

            ]);
              //pertanyaan f10

        $check_input_f10 = '';
        if($request->pertanyaanf10 != null){
            if($request->pertanyaanf10 == 1){
                $check_input_f10 = 'tidak';
                $request->pertanyaanf10 = 1;
            }else if($request->pertanyaanf10 == 2){
                $check_input_f10 = 'tidak_tapi_saya_sedang_menunggu_hasil_lamaran';
                $request->pertanyaanf10 = 1;
            }else if($request->pertanyaanf10 == 3){
                $check_input_f10 = 'ya_saya_akan_mulai_bekerja_2_minggu_kedepan';
                $request->pertanyaanf10 = 1;
            }else if($request->pertanyaanf10 == 4){
                $check_input_f10 = 'ya_tapi_saya_belum_pasti_akan_bekerja_dalam_2_minggu';
                $request->pertanyaanf10 = 1;
            }else if($request->pertanyaanf10 == 5){
                $check_input_f10 = 'lainnya';
                $request->pertanyaanf10 = 1;
            }
            DB::Table('tb_pengangguran_terbuka')
            ->where('npm', $post['npm'])
            ->delete();
            DB::table('tb_pengangguran_terbuka')
            ->insert([
                    'npm'          => $request->npm,
                    $check_input_f10 => $request->pertanyaanf10,

            ]);
        }



          //pertanyaan f11

                DB::Table('tb_jenis_tempat_bekerja_saat_ini')
                ->where('npm', $post['npm'])
                ->delete();
                DB::table('tb_jenis_tempat_bekerja_saat_ini')
                ->insert([
                    'npm'          => $request->npm,
                    'wirausaha_ijin' =>$request->wiraswastaijintidakberijin == null ? null : implode(',',$request->wiraswastaijintidakberijin),
                    'wirausaha_lokal' => $request->wiraswastalokal_nasional == null ? null : implode(',',$request->wiraswastalokal_nasional),
                    'perusahaan_swasta_ijin' => $request->perusahaanswasta == null ? null : implode(',',$request->perusahaanswasta),
                    'perusahaan_lokal' => $request->perusahaanlokalnasional == null ? null : implode(',',$request->perusahaanlokalnasional),
                    'instansi_pemerintah_bumn' => $request->bumn == null ? null : implode(',',$request->bumn),
                    'organisasi_non_profit' => $request->organisasi_non_profit == null ? null : implode(',',$request->organisasi_non_profit),

                    ]);
          //pertanyaan f12

          DB::Table('tb_pembiayaan_kuliah')
          ->where('npm', $post['npm'])
          ->delete();
          DB::table('tb_pembiayaan_kuliah')
          ->insert([
              'npm'          => $request->npm,
              'pembiayaan'          => $request->pertanyaanf12,

              ]);

         //pertanyaan f13
         DB::Table('tb_pendapatan_setiap_bulan')
         ->where('npm', $post['npm'])
         ->delete();
         DB::table('tb_pendapatan_setiap_bulan')
         ->insert([
             'npm'                           => $request->npm,
             'dari_pekerjaan_utama' => str_replace(",","",$request->pekerjaan_utama),
             'dari_lembur' => str_replace(",","",$request->lembur_tips),
             'dari_pekerjaan_lainnya' => str_replace(",","",$request->pekerjaan_lainnya)

             ]);
        //pertanyaan f14
        $check_input_f14 = '';
        if($request->pertanyaanf14 != null){
            if($request->pertanyaanf14 == 1){
                $check_input_f14 = 'sangat_erat';
                $request->pertanyaanf14 = 1;
            }else if($request->pertanyaanf14 == 2){
                $check_input_f14 = 'erat';
                $request->pertanyaanf14 = 1;
            }else if($request->pertanyaanf14 == 3){
                $check_input_f14 = 'cukup_erat';
                $request->pertanyaanf14 = 1;
            }else if($request->pertanyaanf14 == 4){
                $check_input_f14 = 'kurang_erat';
                $request->pertanyaanf14 = 1;
            }else if($request->pertanyaanf14 == 5){
                $check_input_f14 = 'tidak_sama_sekali';
                $request->pertanyaanf14 = 1;
            }
            DB::Table('tb_keselarasan_horizontal')
            ->where('npm', $post['npm'])
            ->delete();
            DB::table('tb_keselarasan_horizontal')
            ->insert([
                'npm'          => $request->npm,
                $check_input_f14 => $request->pertanyaanf14,

                ]);
        }

         //pertanyaan f15
         $check_input_f15 = '';
         if($request->pertanyaanf15 != null){
             if($request->pertanyaanf15 == 1){
                 $check_input_f15 = 'setingkat_lebih_tinggi';
                 $request->pertanyaanf15 = 1;
             }else if($request->pertanyaanf15 == 2){
                 $check_input_f15 = 'tingkat_yang_sama';
                 $request->pertanyaanf15 = 1;
             }else if($request->pertanyaanf15 == 3){
                 $check_input_f15 = 'setingkat_lebih_rendah';
                 $request->pertanyaanf15 = 1;
             }else if($request->pertanyaanf15 == 4){
                 $check_input_f15 = 'tidak_perlu_pendidikan_tinggi';
                 $request->pertanyaanf15 = 1;
             }
             DB::Table('tb_keselarasan_vertical')
            ->where('npm', $post['npm'])
            ->delete();
             DB::table('tb_keselarasan_vertical')
             ->insert([
                 'npm'          => $request->npm,
                 $check_input_f15 => $request->pertanyaanf15,

                 ]);
         }
         ///profil karakter

         DB::Table('tb_profil_karakter_kepribadian')
            ->where('npm', $post['npm'])
            ->delete();
        DB::table('tb_profil_karakter_kepribadian')
        ->insert([
            'npm'                           => $request->npm,
            'pekerjaandenganpenuhtanggungjawab' => $request->tanggung_jawab,
            'Mampubekerjasamadalamtim' => $request->bekerjasama,
            'Bersungguh_sungguh' => $request->bersungguhsungguh,
            'Bekerjakerassesuaidengankompetensi' => $request->bekerjakeras,
            'Tolerandanmampumenerima' => $request->toleran,
            'Meletakkansegalasesuatu' => $request->meletakkansegalasesuatu,
            'Kreatifdaninovatif' => $request->kreatifdaninovatif,
            'Mampumembuatkeputusanterbaik' => $request->keputusanterbaik,


            ]);

             //pertanyaan f16
        DB::Table('tb_pengambilan_pekerjaan_tidak_sesuai')
        ->where('npm', $post['npm'])
        ->delete();
        DB::table('tb_pengambilan_pekerjaan_tidak_sesuai')
        ->insert([
            'npm'                           => $request->npm,
            'pertanyaan_tidak_sesuai_pekerjaan' => $request->pertanyaanf16_pertanyaan_tidak_sesuai_pekerjaan,
            'Saya_belum_mendapatkan_pekerjaan_yang_lebih_sesuai' => $request->pertanyaanf16_Saya_belum_mendapatkan_pekerjaan_yang_lebih_sesuai,
            'di_pekerjaan_ini_saya_memeroleh_prospek_karir_yang_baik' => $request->pertanyaanf16_di_pekerjaan_ini_saya_memeroleh_prospek_karir_yang_baik,
            'saya_lebih_suka_bekerja_di_area_pekerjaan' => $request->pertanyaanf16_saya_lebih_suka_bekerja_di_area_pekerjaan,
            'saya_dipromosikan_ke_posisi_yang_kurang' => $request->pertanyaanf16_saya_dipromosikan_ke_posisi_yang_kurang,
            'Saya_dapat_memeroleh_pendapatan' => $request->pertanyaanf16_Saya_dapat_memeroleh_pendapatan,
            'Pekerjaan_saya_saat_ini_lebih_aman_terjamin_secure' => $request->pertanyaanf16_Pekerjaan_saya_saat_ini_lebih_aman_terjamin_secure,
            'Pekerjaan_saya_saat_ini_lebih_menarik' => $request->pertanyaanf16_Pekerjaan_saya_saat_ini_lebih_menarik,
            'Pekerjaan_saya_saat_ini_lebih_memungkinkan' => $request->pertanyaanf16_Pekerjaan_saya_saat_ini_lebih_memungkinkan,
            'Pekerjaan_saya_saat_ini_lokasinya_lebih_dekat' => $request->pertanyaanf16_Pekerjaan_saya_saat_ini_lokasinya_lebih_dekat,
            'Pekerjaan_saya_saat_ini_dapat_lebih' => $request->pertanyaanf16_Pekerjaan_saya_saat_ini_dapat_lebih,
            'Pada_awal_meniti_karir_ini' => $request->pertanyaanf16_Pada_awal_meniti_karir_ini,
            'Lainnya' => $request->pertanyaanf16_Lainnya,
            ]);

             //---------------------pertanyaan f6 - f7a------------------------

        DB::Table('tb_kompetensia')
        ->where('npm', $post['npm'])
        ->delete();

            DB::table('tb_kompetensia')
            ->insert([
                'npm'                           => $request->npm,
                'PengetahuandibidangataudisiplinilmuAnda'      =>$request->pengetahuandibidang,
                                        'PengetahuandiluarbidangataudisiplinilmuAnda' =>$request->pengetahuandiluarbidang,
                                        'Pengetahuanumum'                           => $request->pengetahuanumum,
                                        'BahasaInggris'                           => $request->bahasainggris,
                                        'Ketrampilaninternet'                           => $request->ketrampilaninternet,
                                        'Ketrampilankomputer'                           => $request->ketrampilankomputer,
                                        'Berpikirkritis'                           => $request->berpikirkritis,
                                        'KeterampilanRiset'                  => $request->ketrampilanriset,
                                        'Kemampuanbelajar'                   => $request->kemampuanbelajar,
                                        'Kemampuanberkomunikasi'             => $request->kemampuanberkomunikasi,
                                        'Bekerjadibawahtekanan'              => $request->bekerjadibawahtekanan,
                                        'Manajemenwaktu'                     => $request->manajemenwaktu,
                                        'Bekerjasecaramandiri'               => $request->bekerjasecaramandiri,
                                        'Bekerjadalamtimbekerjasama'         => $request->bekerjadalamtim,
                                        'Kemampuandalammemecahkanmasalah'    => $request->kemampuandalammemecahkanmasalah,
                                        'Negosiasi'                          => $request->negoisasi,
                                        'Kemampuananalisis'                  => $request->kemampuanalisis,
                                        'Toleransi'                          => $request->toleransi,
                                        'Kemampuanadaptasi'                  => $request->kemampuanadaptasi,
                                        'Loyalitas'                          => $request->loyalitas,
                                        'Integritas'                         => $request->integritas,
                                        'Bekerjadenganorangyangberbedabudayamaupunlatarbelakang'     => $request->bekerjadengancaraberbeda,
                                        'Kepemimpinan'                           => $request->kepemimpinan,
                                        'Kemampuandalammemegangtanggungjawab'                           => $request->kemampuandalammemegangtanggungjawab,
                                        'Inisiatif'                           => $request->inisiatif,
                                        'Manajemenproyekprogram'                           => $request->manajemenproyek,
                                        'Kemampuanuntukmemresentasikanide'                           => $request->kemampuanmemresentasikanide,
                                        'Kemampuandalammenulislaporan'                           => $request->kemampuandalammenulislaporan,
                                        'Kemampuanuntukterusbelajarsepanjanghayat'                           => $request->kemampuanuntukterusbelajar,

                ]);

                //------------------------------------kompetensi B -----------------------
                DB::Table('tb_kompetensib')
                ->where('npm', $post['npm'])
                ->delete();

                    DB::table('tb_kompetensib')
                    ->insert([
                        'npm'                           => $request->npm,
                        'PengetahuandibidangataudisiplinilmuAnda'      =>$request->pengetahuandibidang_b,
                                                'PengetahuandiluarbidangataudisiplinilmuAnda' =>$request->pengetahuandiluarbidang_b,
                                                'Pengetahuanumum'                           => $request->pengetahuanumum_b,
                                                'BahasaInggris'                           => $request->bahasainggris_b,
                                                'Ketrampilaninternet'                           => $request->ketrampilaninternet_b,
                                                'Ketrampilankomputer'                           => $request->ketrampilankomputer_b,
                                                'Berpikirkritis'                           => $request->berpikirkritis_b,
                                                'KeterampilanRiset'                  => $request->ketrampilanriset_b,
                                                'Kemampuanbelajar'                   => $request->kemampuanbelajar_b,
                                                'Kemampuanberkomunikasi'             => $request->kemampuanberkomunikasi_b,
                                                'Bekerjadibawahtekanan'              => $request->bekerjadibawahtekanan_b,
                                                'Manajemenwaktu'                     => $request->manajemenwaktu_b,
                                                'Bekerjasecaramandiri'               => $request->bekerjasecaramandiri_b,
                                                'Bekerjadalamtimbekerjasama'         => $request->bekerjadalamtim_b,
                                                'Kemampuandalammemecahkanmasalah'    => $request->kemampuandalammemecahkanmasalah_b,
                                                'Negosiasi'                          => $request->negosisasi_b,
                                                'Kemampuananalisis'                  => $request->kemampuanalisis_b,
                                                'Toleransi'                          => $request->toleransi_b,
                                                'Kemampuanadaptasi'                  => $request->kemampuanadaptasi_b,
                                                'Loyalitas'                          => $request->loyalitas_b,
                                                'Integritas'                         => $request->integritas_b,
                                                'Bekerjadenganorangyangberbedabudayamaupunlatarbelakang'     => $request->bekerjadenganlatarbelakang_b2,
                                                'Kepemimpinan'                           => $request->kepemimpinan_b,
                                                'Kemampuandalammemegangtanggungjawab'                           => $request->kemampuandalamtanggungjawab_b,
                                                'Inisiatif'                           => $request->inisiatif_b,
                                                'Manajemenproyekprogram'                           => $request->manajemenproyek_b,
                                                'Kemampuanuntukmemresentasikanide'                           => $request->mempresentasikanideproduk_b,
                                                'Kemampuandalammenulislaporan'                           => $request->kemampuandalammenulislaporan_b,
                                                'Kemampuanuntukterusbelajarsepanjanghayat'                           => $request->kemampuanuntukbelajarsepanjanghayat_b,

                        ]);


        return redirect('view_finish');
    }

}
