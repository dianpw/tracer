<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class PenekananMetodePembelajaranController extends Controller
{
    public function index()
    {
        if(Auth::user()->role_id == 2){
            $auth_user = DB::table('users')
            ->leftJoin('tm_fakultas', 'users.fakultas_user_id', 'tm_fakultas.id')
            ->where('users.id', Auth::user()->id)
            ->first();
        }else if(Auth::user()->role_id == 3){
            $auth_user = DB::table('users')
            ->leftJoin('tm_kode_prodi', 'users.prodi_id', 'tm_kode_prodi.kode')
            ->where('id', Auth::user()->id)
            ->first();
        }else{
            $auth_user = DB::table('users')
            ->where('id', Auth::user()->id)
            ->first();
        }
        return view('penekanan_metode_pembelajaran.index', compact('auth_user'));
    }
    public function graph(){
        $prodi_id = '';
        if(Auth::user()->role_id == 1){
           $prodi_id = ' and tb_mahasiswa.npm is not null ';
        }else if(Auth::user()->role_id == 2){
            $prodi_id = ' and mhs_fakultas_id= "'.Auth::user()->fakultas_user_id.'" and tb_mahasiswa.npm is not null ';
        }else if(Auth::user()->role_id == 3){
            $prodi_id = ' and kode_prodi_id = "'.Auth::user()->prodi_id.'" and tb_mahasiswa.npm is not null ';
        }

        $data['perkuliahan'] = [];
        $data['Responsidantutorial'] = [];
        $data['Seminar'] = [];
        $data['praktikum'] = [];
        $data['praktek_lapangan'] = [];
        $data['penelitian'] = [];
        $data['pelatihan'] = [];
        $data['pertukaran_pelajar'] = [];
        $data['magang'] = [];
        $data['Wirausaha'] = [];
        $data['pengabdiankepadamasyarakat'] = [];

        // ======================== perkuliahan sangat besar========================
        $query_perkuliahan_sangat_besar = DB::select('SELECT perkuliahan, kode_prodi_id,
        COUNT(perkuliahan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`

        JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
        where perkuliahan = "sangat besar"'.$prodi_id.'' );


        foreach ($query_perkuliahan_sangat_besar as $key => $value) {
            array_push($data['perkuliahan'], ['sangatbesar' => (int)$value->jumlah]);
        }

        // ======================== perkuliahan besar========================
        $query_perkuliahan_besar = DB::select('SELECT perkuliahan,
        COUNT(perkuliahan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
        JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
          where perkuliahan = "besar"'.$prodi_id.'');

        foreach ($query_perkuliahan_besar as $key => $value) {
            array_push($data['perkuliahan'], ['besar' => (int)$value->jumlah]);
        }

        // ======================== perkuliahan cukup_besar========================
        $query_perkuliahan_cukup_besar = DB::select('SELECT perkuliahan,
        COUNT(perkuliahan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
        JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
          where perkuliahan = "cukup besar"'.$prodi_id.'');

        foreach ($query_perkuliahan_cukup_besar as $key => $value) {
            array_push($data['perkuliahan'], ['cukupbesar' => (int)$value->jumlah]);
        }

        // ======================== perkuliahan kurang========================
        $query_perkuliahan_kurang = DB::select('SELECT perkuliahan,
        COUNT(perkuliahan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
        JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
          where perkuliahan = "kurang"'.$prodi_id.'');

        foreach ($query_perkuliahan_kurang as $key => $value) {
            array_push($data['perkuliahan'], ['kurang' => (int)$value->jumlah]);
        }

        // ======================== perkuliahan tidak sama sekali========================
        $query_perkuliahan_tidak_sama_sekali = DB::select('SELECT perkuliahan,
        COUNT(perkuliahan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
        JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
          where perkuliahan = "tidak sama sekali"'.$prodi_id.'');

        foreach ($query_perkuliahan_tidak_sama_sekali as $key => $value) {
            array_push($data['perkuliahan'], ['tidak_sama_sekali' => (int)$value->jumlah]);
        }

//---------------------------------------------------------------------------------------------------


        // ======================== Responsidantutorial sangat besar========================
        $query_Responsidantutorial_sangat_besar = DB::select('SELECT Responsidantutorial,
        COUNT(Responsidantutorial) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
        JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
          where Responsidantutorial = "sangat besar"'.$prodi_id.'');

        foreach ($query_Responsidantutorial_sangat_besar as $key => $value) {
            array_push($data['Responsidantutorial'], ['sangatbesar' => (int)$value->jumlah]);
        }

          // ======================== Responsidantutorial besar========================
          $query_Responsidantutorial_besar = DB::select('SELECT Responsidantutorial,
          COUNT(Responsidantutorial) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
          JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
            where Responsidantutorial = "besar"'.$prodi_id.'');

          foreach ($query_Responsidantutorial_besar as $key => $value) {
              array_push($data['Responsidantutorial'], ['besar' => (int)$value->jumlah]);
          }

          // ======================== Responsidantutorial cukup besar========================
          $query_Responsidantutorial_cukup_besar = DB::select('SELECT Responsidantutorial,
          COUNT(Responsidantutorial) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
          JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
            where Responsidantutorial = "cukup besar"'.$prodi_id.'');

          foreach ($query_Responsidantutorial_cukup_besar as $key => $value) {
              array_push($data['Responsidantutorial'], ['cukupbesar' => (int)$value->jumlah]);
          }

           // ======================== Responsidantutorial kurang========================
           $query_Responsidantutorial_kurang = DB::select('SELECT Responsidantutorial,
           COUNT(Responsidantutorial) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
           JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
             where Responsidantutorial = "kurang"'.$prodi_id.'');

           foreach ($query_Responsidantutorial_kurang as $key => $value) {
               array_push($data['Responsidantutorial'], ['kurang' => (int)$value->jumlah]);
           }

           // ======================== Responsidantutorial tidak sama sekali========================
           $query_Responsidantutorial_tidak_sama_sekali = DB::select('SELECT Responsidantutorial,
           COUNT(Responsidantutorial) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
           JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
             where Responsidantutorial = "tidak sama sekali"'.$prodi_id.'');

           foreach ($query_Responsidantutorial_tidak_sama_sekali as $key => $value) {
               array_push($data['Responsidantutorial'], ['tidak_sama_sekali' => (int)$value->jumlah]);
           }

        //--------------------------------------------------------------------------

          // ======================== Seminar dalam proyek sangat besar========================
          $query_Seminar_sangat_besar = DB::select('SELECT Seminar,
          COUNT(Seminar) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
          JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
            where Seminar = "sangat besar"'.$prodi_id.'');

          foreach ($query_Seminar_sangat_besar as $key => $value) {
              array_push($data['Seminar'], ['sangatbesar' => (int)$value->jumlah]);
          }

            // ======================== Seminar dalam proyek besar========================
            $query_Seminar_besar = DB::select('SELECT Seminar,
            COUNT(Seminar) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where Seminar = "besar"'.$prodi_id.'');

            foreach ($query_Seminar_besar as $key => $value) {
                array_push($data['Seminar'], ['besar' => (int)$value->jumlah]);
            }

            // ======================== Seminar dalam proyek cukup besar========================
            $query_Seminar_cukup_besar = DB::select('SELECT Seminar,
            COUNT(Seminar) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where Seminar = "cukup besar"'.$prodi_id.'');

            foreach ($query_Seminar_cukup_besar as $key => $value) {
                array_push($data['Seminar'], ['cukupbesar' => (int)$value->jumlah]);
            }

             // ======================== Seminar dalam proyek kurang========================
             $query_Seminar_kurang = DB::select('SELECT Seminar,
             COUNT(Seminar) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where Seminar = "kurang"'.$prodi_id.'');

             foreach ($query_Seminar_kurang as $key => $value) {
                 array_push($data['Seminar'], ['kurang' => (int)$value->jumlah]);
             }

             // ======================== Seminar dalam proyek tidak sama sekali========================
             $query_Seminar_tidak_sama_sekali = DB::select('SELECT Seminar,
             COUNT(Seminar) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where Seminar = "tidak sama sekali"'.$prodi_id.'');

             foreach ($query_Seminar_tidak_sama_sekali as $key => $value) {
                 array_push($data['Seminar'], ['tidak_sama_sekali' => (int)$value->jumlah]);
             }

   //--------------------------------------------------------------------------

          // ======================== praktikum sangat besar========================
          $query_praktikum_sangat_besar = DB::select('SELECT praktikum,
          COUNT(praktikum) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
          JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
            where praktikum = "sangat besar"'.$prodi_id.'');

          foreach ($query_praktikum_sangat_besar as $key => $value) {
              array_push($data['praktikum'], ['sangatbesar' => (int)$value->jumlah]);
          }

            // ======================== praktikum besar========================
            $query_praktikum_besar = DB::select('SELECT praktikum,
            COUNT(praktikum) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where praktikum = "besar"'.$prodi_id.'');

            foreach ($query_praktikum_besar as $key => $value) {
                array_push($data['praktikum'], ['besar' => (int)$value->jumlah]);
            }

            // ======================== praktikum cukup besar========================
            $query_praktikum_cukup_besar = DB::select('SELECT praktikum,
            COUNT(praktikum) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where praktikum = "cukup besar"'.$prodi_id.'');

            foreach ($query_praktikum_cukup_besar as $key => $value) {
                array_push($data['praktikum'], ['cukupbesar' => (int)$value->jumlah]);
            }

             // ======================== praktikum kurang========================
             $query_praktikum_kurang = DB::select('SELECT praktikum,
             COUNT(praktikum) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where praktikum = "kurang"'.$prodi_id.'');

             foreach ($query_praktikum_kurang as $key => $value) {
                 array_push($data['praktikum'], ['kurang' => (int)$value->jumlah]);
             }

             // ======================== praktikum tidak sama sekali========================
             $query_praktikum_tidak_sama_sekali = DB::select('SELECT praktikum,
             COUNT(praktikum) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where praktikum = "tidak sama sekali"'.$prodi_id.'');

             foreach ($query_praktikum_tidak_sama_sekali as $key => $value) {
                 array_push($data['praktikum'], ['tidak_sama_sekali' => (int)$value->jumlah]);
             }

              //--------------------------------------------------------------------------

          // ======================== praktek_lapangan sangat besar========================
          $query_praktek_lapangan_sangat_besar = DB::select('SELECT praktek_lapangan,
          COUNT(praktek_lapangan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
          JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
            where praktek_lapangan = "sangat besar"'.$prodi_id.'');

          foreach ($query_praktek_lapangan_sangat_besar as $key => $value) {
              array_push($data['praktek_lapangan'], ['sangatbesar' => (int)$value->jumlah]);
          }

            // ======================== praktek_lapangan besar========================
            $query_praktek_lapangan_besar = DB::select('SELECT praktek_lapangan,
            COUNT(praktek_lapangan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where praktek_lapangan = "besar"'.$prodi_id.'');

            foreach ($query_praktek_lapangan_besar as $key => $value) {
                array_push($data['praktek_lapangan'], ['besar' => (int)$value->jumlah]);
            }

            // ======================== praktek_lapangan cukup besar========================
            $query_praktek_lapangan_cukup_besar = DB::select('SELECT praktek_lapangan,
            COUNT(praktek_lapangan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where praktek_lapangan = "cukup besar"'.$prodi_id.'');

            foreach ($query_praktek_lapangan_cukup_besar as $key => $value) {
                array_push($data['praktek_lapangan'], ['cukupbesar' => (int)$value->jumlah]);
            }

             // ======================== praktek_lapangan kurang========================
             $query_praktek_lapangan_kurang = DB::select('SELECT praktek_lapangan,
             COUNT(praktek_lapangan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where praktek_lapangan = "kurang"'.$prodi_id.'');

             foreach ($query_praktek_lapangan_kurang as $key => $value) {
                 array_push($data['praktek_lapangan'], ['kurang' => (int)$value->jumlah]);
             }

             // ======================== praktek_lapangan tidak sama sekali========================
             $query_praktek_lapangan_tidak_sama_sekali = DB::select('SELECT praktek_lapangan,
             COUNT(praktek_lapangan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where praktek_lapangan = "tidak sama sekali"'.$prodi_id.'');

             foreach ($query_praktek_lapangan_tidak_sama_sekali as $key => $value) {
                 array_push($data['praktek_lapangan'], ['tidak_sama_sekali' => (int)$value->jumlah]);
             }

                   //--------------------------------------------------------------------------

          // ======================== penelitian sangat besar========================
          $query_penelitian_sangat_besar = DB::select('SELECT penelitian,
          COUNT(penelitian) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
          JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
            where penelitian = "sangat besar"'.$prodi_id.'');

          foreach ($query_penelitian_sangat_besar as $key => $value) {
              array_push($data['penelitian'], ['sangatbesar' => (int)$value->jumlah]);
          }

            // ======================== Kerja lapangan besar========================
            $query_penelitian_besar = DB::select('SELECT penelitian,
            COUNT(penelitian) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where penelitian = "besar"'.$prodi_id.'');

            foreach ($query_penelitian_besar as $key => $value) {
                array_push($data['penelitian'], ['besar' => (int)$value->jumlah]);
            }

            // ======================== Kerja lapangan cukup besar========================
            $query_penelitian_cukup_besar = DB::select('SELECT penelitian,
            COUNT(penelitian) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where penelitian = "cukup besar"'.$prodi_id.'');

            foreach ($query_penelitian_cukup_besar as $key => $value) {
                array_push($data['penelitian'], ['cukupbesar' => (int)$value->jumlah]);
            }

             // ======================== Kerja lapangan kurang========================
             $query_penelitian_kurang = DB::select('SELECT penelitian,
             COUNT(penelitian) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where penelitian = "kurang"'.$prodi_id.'');

             foreach ($query_penelitian_kurang as $key => $value) {
                 array_push($data['penelitian'], ['kurang' => (int)$value->jumlah]);
             }

             // ======================== Kerja lapangan tidak sama sekali========================
             $query_penelitian_tidak_sama_sekali = DB::select('SELECT penelitian,
             COUNT(penelitian) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where penelitian = "tidak sama sekali"'.$prodi_id.'');

             foreach ($query_penelitian_tidak_sama_sekali as $key => $value) {
                 array_push($data['penelitian'], ['tidak_sama_sekali' => (int)$value->jumlah]);
             }

                       //--------------------------------------------------------------------------

          // ======================== pelatihan sangat besar========================
          $query_pelatihan_sangat_besar = DB::select('SELECT pelatihan,
          COUNT(pelatihan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
          JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
            where pelatihan = "sangat besar"'.$prodi_id.'');

          foreach ($query_pelatihan_sangat_besar as $key => $value) {
              array_push($data['pelatihan'], ['sangatbesar' => (int)$value->jumlah]);
          }

            // ======================== pelatihan besar========================
            $query_pelatihan_besar = DB::select('SELECT pelatihan,
            COUNT(pelatihan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where pelatihan = "besar"'.$prodi_id.'');

            foreach ($query_pelatihan_besar as $key => $value) {
                array_push($data['pelatihan'], ['besar' => (int)$value->jumlah]);
            }

            // ======================== pelatihan cukup besar========================
            $query_pelatihan_cukup_besar = DB::select('SELECT pelatihan,
            COUNT(pelatihan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where pelatihan = "cukup besar"'.$prodi_id.'');

            foreach ($query_pelatihan_cukup_besar as $key => $value) {
                array_push($data['pelatihan'], ['cukupbesar' => (int)$value->jumlah]);
            }

             // ======================== pelatihan kurang========================
             $query_pelatihan_kurang = DB::select('SELECT pelatihan,
             COUNT(pelatihan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where pelatihan = "kurang"'.$prodi_id.'');

             foreach ($query_pelatihan_kurang as $key => $value) {
                 array_push($data['pelatihan'], ['kurang' => (int)$value->jumlah]);
             }

             // ======================== pelatihan tidak sama sekali========================
             $query_pelatihan_tidak_sama_sekali = DB::select('SELECT pelatihan,
             COUNT(pelatihan) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where pelatihan = "tidak sama sekali"'.$prodi_id.'');

             foreach ($query_pelatihan_tidak_sama_sekali as $key => $value) {
                 array_push($data['pelatihan'], ['tidak_sama_sekali' => (int)$value->jumlah]);
             }

                            //--------------------------------------------------------------------------

          // ======================== pertukaran_pelajar sangat besar========================
          $query_pertukaran_pelajar_sangat_besar = DB::select('SELECT pertukaran_pelajar,
          COUNT(pertukaran_pelajar) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
          JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
            where pertukaran_pelajar = "sangat besar"'.$prodi_id.'');

          foreach ($query_pertukaran_pelajar_sangat_besar as $key => $value) {
              array_push($data['pertukaran_pelajar'], ['sangatbesar' => (int)$value->jumlah]);
          }

            // ======================== pertukaran_pelajar besar========================
            $query_pertukaran_pelajar_besar = DB::select('SELECT pertukaran_pelajar,
            COUNT(pertukaran_pelajar) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where pertukaran_pelajar = "besar"'.$prodi_id.'');

            foreach ($query_pertukaran_pelajar_besar as $key => $value) {
                array_push($data['pertukaran_pelajar'], ['besar' => (int)$value->jumlah]);
            }

            // ======================== pertukaran_pelajar cukup besar========================
            $query_pertukaran_pelajar_cukup_besar = DB::select('SELECT pertukaran_pelajar,
            COUNT(pertukaran_pelajar) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where pertukaran_pelajar = "cukup besar"'.$prodi_id.'');

            foreach ($query_pertukaran_pelajar_cukup_besar as $key => $value) {
                array_push($data['pertukaran_pelajar'], ['cukupbesar' => (int)$value->jumlah]);
            }

             // ======================== pertukaran_pelajar kurang========================
             $query_pertukaran_pelajar_kurang = DB::select('SELECT pertukaran_pelajar,
             COUNT(pertukaran_pelajar) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where pertukaran_pelajar = "kurang"'.$prodi_id.'');

             foreach ($query_pertukaran_pelajar_kurang as $key => $value) {
                 array_push($data['pertukaran_pelajar'], ['kurang' => (int)$value->jumlah]);
             }

             // ======================== pertukaran_pelajar tidak sama sekali========================
             $query_pertukaran_pelajar_tidak_sama_sekali = DB::select('SELECT pertukaran_pelajar,
             COUNT(pertukaran_pelajar) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where pertukaran_pelajar = "tidak sama sekali"'.$prodi_id.'');

             foreach ($query_pertukaran_pelajar_tidak_sama_sekali as $key => $value) {
                 array_push($data['pertukaran_pelajar'], ['tidak_sama_sekali' => (int)$value->jumlah]);
             }

                               //--------------------------------------------------------------------------

          // ======================== magang sangat besar========================
          $query_magang_sangat_besar = DB::select('SELECT magang,
          COUNT(magang) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
          JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
            where magang = "sangat besar"'.$prodi_id.'');

          foreach ($query_magang_sangat_besar as $key => $value) {
              array_push($data['magang'], ['sangatbesar' => (int)$value->jumlah]);
          }

            // ======================== magang besar========================
            $query_magang_besar = DB::select('SELECT magang,
            COUNT(magang) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where magang = "besar"'.$prodi_id.'');

            foreach ($query_magang_besar as $key => $value) {
                array_push($data['magang'], ['besar' => (int)$value->jumlah]);
            }

            // ======================== magang cukup besar========================
            $query_magang_cukup_besar = DB::select('SELECT magang,
            COUNT(magang) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where magang = "cukup besar"'.$prodi_id.'');

            foreach ($query_magang_cukup_besar as $key => $value) {
                array_push($data['magang'], ['cukupbesar' => (int)$value->jumlah]);
            }

             // ======================== magang kurang========================
             $query_magang_kurang = DB::select('SELECT magang,
             COUNT(magang) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where magang = "kurang"'.$prodi_id.'');

             foreach ($query_magang_kurang as $key => $value) {
                 array_push($data['magang'], ['kurang' => (int)$value->jumlah]);
             }

             // ======================== magang tidak sama sekali========================
             $query_magang_tidak_sama_sekali = DB::select('SELECT magang,
             COUNT(magang) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where magang = "tidak sama sekali"'.$prodi_id.'');

             foreach ($query_magang_tidak_sama_sekali as $key => $value) {
                 array_push($data['magang'], ['tidak_sama_sekali' => (int)$value->jumlah]);
             }

                                       //--------------------------------------------------------------------------

          // ======================== Wirausaha sangat besar========================
          $query_Wirausaha_sangat_besar = DB::select('SELECT Wirausaha,
          COUNT(Wirausaha) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
          JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
            where Wirausaha = "sangat besar"'.$prodi_id.'');

          foreach ($query_Wirausaha_sangat_besar as $key => $value) {
              array_push($data['Wirausaha'], ['sangatbesar' => (int)$value->jumlah]);
          }

            // ======================== Wirausaha besar========================
            $query_Wirausaha_besar = DB::select('SELECT Wirausaha,
            COUNT(Wirausaha) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where Wirausaha = "besar"'.$prodi_id.'');

            foreach ($query_Wirausaha_besar as $key => $value) {
                array_push($data['Wirausaha'], ['besar' => (int)$value->jumlah]);
            }

            // ======================== Wirausaha cukup besar========================
            $query_Wirausaha_cukup_besar = DB::select('SELECT Wirausaha,
            COUNT(Wirausaha) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where Wirausaha = "cukup besar"'.$prodi_id.'');

            foreach ($query_Wirausaha_cukup_besar as $key => $value) {
                array_push($data['Wirausaha'], ['cukupbesar' => (int)$value->jumlah]);
            }

             // ======================== Wirausaha kurang========================
             $query_Wirausaha_kurang = DB::select('SELECT Wirausaha,
             COUNT(Wirausaha) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where Wirausaha = "kurang"'.$prodi_id.'');

             foreach ($query_Wirausaha_kurang as $key => $value) {
                 array_push($data['Wirausaha'], ['kurang' => (int)$value->jumlah]);
             }

             // ======================== Wirausaha tidak sama sekali========================
             $query_Wirausaha_tidak_sama_sekali = DB::select('SELECT Wirausaha,
             COUNT(Wirausaha) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where Wirausaha = "tidak sama sekali"'.$prodi_id.'');

             foreach ($query_Wirausaha_tidak_sama_sekali as $key => $value) {
                 array_push($data['Wirausaha'], ['tidak_sama_sekali' => (int)$value->jumlah]);
             }



                                       //--------------------------------------------------------------------------

          // ======================== pengabdiankepadamasyarakat sangat besar========================
          $query_pengabdiankepadamasyarakat_sangat_besar = DB::select('SELECT pengabdiankepadamasyarakat,
          COUNT(pengabdiankepadamasyarakat) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
          JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
            where pengabdiankepadamasyarakat = "sangat besar"'.$prodi_id.'');

          foreach ($query_pengabdiankepadamasyarakat_sangat_besar as $key => $value) {
              array_push($data['pengabdiankepadamasyarakat'], ['sangatbesar' => (int)$value->jumlah]);
          }

            // ======================== pengabdiankepadamasyarakat besar========================
            $query_pengabdiankepadamasyarakat_besar = DB::select('SELECT pengabdiankepadamasyarakat,
            COUNT(pengabdiankepadamasyarakat) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where pengabdiankepadamasyarakat = "besar"'.$prodi_id.'');

            foreach ($query_pengabdiankepadamasyarakat_besar as $key => $value) {
                array_push($data['pengabdiankepadamasyarakat'], ['besar' => (int)$value->jumlah]);
            }

            // ======================== pengabdiankepadamasyarakat cukup besar========================
            $query_pengabdiankepadamasyarakat_cukup_besar = DB::select('SELECT pengabdiankepadamasyarakat,
            COUNT(pengabdiankepadamasyarakat) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
            JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
              where pengabdiankepadamasyarakat = "cukup besar"'.$prodi_id.'');

            foreach ($query_pengabdiankepadamasyarakat_cukup_besar as $key => $value) {
                array_push($data['pengabdiankepadamasyarakat'], ['cukupbesar' => (int)$value->jumlah]);
            }

             // ======================== pengabdiankepadamasyarakat kurang========================
             $query_pengabdiankepadamasyarakat_kurang = DB::select('SELECT pengabdiankepadamasyarakat,
             COUNT(pengabdiankepadamasyarakat) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where pengabdiankepadamasyarakat = "kurang"'.$prodi_id.'');

             foreach ($query_pengabdiankepadamasyarakat_kurang as $key => $value) {
                 array_push($data['pengabdiankepadamasyarakat'], ['kurang' => (int)$value->jumlah]);
             }

             // ======================== pengabdiankepadamasyarakat tidak sama sekali========================
             $query_pengabdiankepadamasyarakat_tidak_sama_sekali = DB::select('SELECT pengabdiankepadamasyarakat,
             COUNT(pengabdiankepadamasyarakat) AS jumlah  FROM `tb_penekanan_metode_pembelajaran`
             JOIN tb_mahasiswa ON tb_penekanan_metode_pembelajaran.npm = tb_mahasiswa.npm
               where pengabdiankepadamasyarakat = "tidak sama sekali"'.$prodi_id.'');

             foreach ($query_pengabdiankepadamasyarakat_tidak_sama_sekali as $key => $value) {
                 array_push($data['pengabdiankepadamasyarakat'], ['tidak_sama_sekali' => (int)$value->jumlah]);
             }




        // dd($data);
        return $data;

    }

    public function show_data(){
        try {
            $result = [];
            $count = 1;


            if(Auth::user()->role_id == 1){
                $query = DB::table('tb_penekanan_metode_pembelajaran')
                ->Leftjoin('tb_mahasiswa', 'tb_penekanan_metode_pembelajaran.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                 ->whereNotNull('tb_mahasiswa.npm')
                ->get();
            }else if(Auth::user()->role_id == 2){
                $query = DB::table('tb_penekanan_metode_pembelajaran')
                ->Leftjoin('tb_mahasiswa', 'tb_penekanan_metode_pembelajaran.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                ->where('mhs_fakultas_id', Auth::user()->fakultas_user_id)
                 ->whereNotNull('tb_mahasiswa.npm')
                ->get();
            }
            else{
                $query = DB::table('tb_penekanan_metode_pembelajaran')
                ->Leftjoin('tb_mahasiswa', 'tb_penekanan_metode_pembelajaran.npm',  'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
                ->where('kode_prodi_id', Auth::user()->prodi_id)
                 ->whereNotNull('tb_mahasiswa.npm')
                ->get();
            }
            // dd($query);

            foreach ($query as $user) {
                $action_edit = '<center>
                <a href="#" class="btn btn-success btn-sm m-btn  m-btn m-btn--icon"
                data-toggle="modal"
                data-id= "'. $user->id.'"
                data-target="#modal-edit" id="btn_update_surat">
                <span>
                    <i class="la la-edit"></i>
                    <span>Ubah</span>
                </span>
                </a>';

                $roless = "";

                $update = $user->created_at;
                $data = [];
                $data[] = $count++;
                $data[] = strtoupper($user->npm);
                $data[] = ($user->nama);
                $data[] = ($user->prodi);
                $data[] = ($user->tahun_lulus);
                $data[] = $user->perkuliahan;
                $data[] = $user->Responsidantutorial;
                $data[] = $user->Seminar;
                $data[] = $user->praktikum;
                $data[] = $user->praktek_lapangan;
                $data[] = $user->penelitian;
                $data[] = $user->pelatihan;
                $data[] = $user->pertukaran_pelajar;
                $data[] = $user->magang;
                $data[] = $user->Wirausaha;
                $data[] = $user->pengabdiankepadamasyarakat;
                $data[] = $update;
                // $data[] = $action_edit;
                $result[] = $data;
            }
            return response()->json(['result' => $result]);
        } catch (\Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 406);
        }
    }

    public function exportExcel(){

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $i = 5;
        $no=1;
        $query = '';

        if(Auth::user()->role_id == 1){
            $query = DB::table('tb_penekanan_metode_pembelajaran')
            ->Leftjoin('tb_mahasiswa', 'tb_penekanan_metode_pembelajaran.npm',  'tb_mahasiswa.npm')
            ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
            ->get();
        }else if(Auth::user()->role_id == 2){
            $query = DB::table('tb_penekanan_metode_pembelajaran')
            ->Leftjoin('tb_mahasiswa', 'tb_penekanan_metode_pembelajaran.npm',  'tb_mahasiswa.npm')
            ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
            ->where('mhs_fakultas_id', Auth::user()->fakultas_user_id)
            ->get();
        }
        else{
            $query = DB::table('tb_penekanan_metode_pembelajaran')
            ->Leftjoin('tb_mahasiswa', 'tb_penekanan_metode_pembelajaran.npm',  'tb_mahasiswa.npm')
            ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id',  'tm_kode_prodi.kode')
            ->where('kode_prodi_id', Auth::user()->prodi_id)
            ->get();
        }

        // dd($query);

        $sheet->setCellValue('B2', 'LAPORAN TRACER STUDY - PENEKANAN METODE PEMBELAJARAN');

        $sheet->setCellValue('A3', 'NO');
        $sheet->setCellValue('B3', 'NPM');
        $sheet->setCellValue('C3', 'NAMA');
        $sheet->setCellValue('D3', 'PRODI');
        $sheet->setCellValue('E3', 'TAHUN LULUS');
        $sheet->setCellValue('F3', 'PERKULIAHAN');
        $sheet->setCellValue('G3', 'RESPONSI');
        $sheet->setCellValue('H3', 'SEMINAR');
        $sheet->setCellValue('I3', 'PRAKTIKUM');
        $sheet->setCellValue('J3', 'PRAKTEK LAP.');
        $sheet->setCellValue('K3', 'PENELITIAN');
        $sheet->setCellValue('L3', 'PELATIHAN');
        $sheet->setCellValue('M3', 'PERTUKARAN PELAJAR');
        $sheet->setCellValue('N3', 'MAGANG');
        $sheet->setCellValue('O3', 'WIRAUSAHA');
        $sheet->setCellValue('P3', 'PENGABDIAN');


        //filte
        $sheet->setAutoFilter('A1:E1');
        //color cell
            //warna nomer

            //warna depart

        //freeze pane

        $sheet->freezePaneByColumnAndRow(1,'D1');
        $sheet->freezePane('D5');

        //merge cells
        $sheet->mergeCells("B2:I2");
        $sheet->mergeCells("A3:A4");
        $sheet->mergeCells("B3:B4");
        $sheet->mergeCells("C3:C4");
        $sheet->mergeCells("D3:D4");
        $sheet->mergeCells("E3:E4");
        $sheet->mergeCells("F3:F4");
        $sheet->mergeCells("G3:G4");
        $sheet->mergeCells("H3:H4");
        $sheet->mergeCells("I3:I4");
        $sheet->mergeCells("J3:J4");
        $sheet->mergeCells("K3:K4");
        $sheet->mergeCells("L3:L4");
        $sheet->mergeCells("M3:M4");
        $sheet->mergeCells("N3:N4");
        $sheet->mergeCells("O3:O4");
        $sheet->mergeCells("P3:P4");


        //size cells
        $sheet->getColumnDimension('A')->setWidth(5);
        $sheet->getColumnDimension('B')->setWidth(20);
        $sheet->getColumnDimension('C')->setWidth(23);
        $sheet->getColumnDimension('D')->setWidth(20);
        $sheet->getColumnDimension('E')->setWidth(15);
        $sheet->getColumnDimension('F')->setWidth(15);
        $sheet->getColumnDimension('G')->setWidth(15);
        $sheet->getColumnDimension('H')->setWidth(15);
        $sheet->getColumnDimension('I')->setWidth(15);
        $sheet->getColumnDimension('J')->setWidth(15);
        $sheet->getColumnDimension('K')->setWidth(15);
        $sheet->getColumnDimension('L')->setWidth(15);
        $sheet->getColumnDimension('M')->setWidth(15);
        $sheet->getColumnDimension('N')->setWidth(15);
        $sheet->getColumnDimension('O')->setWidth(15);
        $sheet->getColumnDimension('P')->setWidth(15);



        $styleArray = [
            'alignment' => [
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
                'wrapText' => true,
             ],
             'borders' => [
                'allBorders' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                ],
            ],

        ];
        $styleHeader = [
            'alignment' => [
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
                'wrapText' => true,
             ],
             'borders' => [
                'allBorders' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                ],
            ],

        ];
        $styletitle = [

            'font' => [
                'name' => 'Century Gothic',
                'size' => 14,
                'bold' => true,
                'color' => ['argb' => '000000'],
            ],

        ];
        $styleheader = [

            'font' => [
                'size' => 11,
                'bold' => true,
                'color' => ['argb' => '000000'],
            ],

        ];
        $count = count($query);
        $sheet->getStyle('A5:P50')->applyFromArray($styleArray);
        $sheet->getStyle('A3:P4')->applyFromArray($styleHeader);
        $sheet->getStyle('A2:D2')->applyFromArray($styletitle);
        $sheet->getStyle('A3:P3')->applyFromArray($styleheader);

        foreach ($query as $key => $value) {
            $sheet->setCellValue('A'.$i, $no++);
            $sheet->setCellValue('B'.$i, $value->npm);
            $sheet->setCellValue('C'.$i, $value->nama);
            $sheet->setCellValue('D'.$i, $value->prodi);
            $sheet->setCellValue('E'.$i, $value->tahun_lulus);
            $sheet->setCellValue('F'.$i, $value->perkuliahan);
            $sheet->setCellValue('G'.$i, $value->Responsidantutorial);
            $sheet->setCellValue('H'.$i, $value->Seminar);
            $sheet->setCellValue('I'.$i, $value->praktikum);
            $sheet->setCellValue('J'.$i, $value->praktek_lapangan);
            $sheet->setCellValue('K'.$i, $value->penelitian);
            $sheet->setCellValue('L'.$i, $value->pelatihan);
            $sheet->setCellValue('M'.$i, $value->pertukaran_pelajar);
            $sheet->setCellValue('N'.$i, $value->magang);
            $sheet->setCellValue('O'.$i, $value->Wirausaha);
            $sheet->setCellValue('P'.$i, $value->pengabdiankepadamasyarakat);

            $i++;
        }

        $writer = new Xlsx($spreadsheet);
        $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, "Xlsx");
        $date = date('d-F-Y');
        $file_name = 'Laporan Penekanan Metode Pembelajaran - '. $date.'.xlsx';
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="'.$file_name.'"');
        $writer->save("php://output");
        }
}
