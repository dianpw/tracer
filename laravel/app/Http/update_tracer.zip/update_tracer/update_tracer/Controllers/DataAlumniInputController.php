<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;
use Carbon;

class DataAlumniInputController extends Controller
{
    public function index()
    {
        $show_tahun = DB::table('tb_mahasiswa')
                    ->select('tahun_lulus')
                    ->groupBy('tahun_lulus')
                    ->get();

        if(Auth::user()->role_id == 2){
            $auth_user = DB::table('users')
            ->leftJoin('tm_fakultas', 'users.fakultas_user_id', 'tm_fakultas.id')
            ->where('users.id', Auth::user()->id)
            ->first();
        }else if(Auth::user()->role_id == 3){
            $auth_user = DB::table('users')
            ->leftJoin('tm_kode_prodi', 'users.prodi_id', 'tm_kode_prodi.kode')
            ->where('id', Auth::user()->id)
            ->first();
        }else{
            $auth_user = DB::table('users')
            ->where('id', Auth::user()->id)
            ->first();
        }

        return view('alumni_sudah_input.index',compact('auth_user', 'show_tahun'));
    }

    public function show_data(){
        try {
            $ex_prodi = explode(',', Auth::user()->prodi_id);
            $result = [];
            $count = 1;
            $role = Auth::user()->role_id;
            if($role == 1){
                $query = DB::table('tb_biodata')
                ->Leftjoin('tb_mahasiswa', 'tb_biodata.npm', 'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id', 'tm_kode_prodi.kode')
                ->whereNotNull('tb_mahasiswa.npm')
                ->select('*', 'tb_biodata.created_at')
                ->get();
            }else if($role == 2){
                $query = DB::table('tb_biodata')
                ->Leftjoin('tb_mahasiswa', 'tb_biodata.npm', 'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id', 'tm_kode_prodi.kode')
                ->whereNotNull('tb_mahasiswa.npm')
                ->select('*', 'tb_biodata.created_at')
                ->whereIn('kode_prodi_id', $ex_prodi)
                ->get();
            }else if($role == 3){
                $query = DB::table('tb_biodata')
                ->Leftjoin('tb_mahasiswa', 'tb_biodata.npm', 'tb_mahasiswa.npm')
                ->Leftjoin('tm_kode_prodi', 'tb_mahasiswa.kode_prodi_id', 'tm_kode_prodi.kode')
                ->whereNotNull('tb_mahasiswa.npm')
                ->select('*', 'tb_biodata.created_at')
                ->where('kode_prodi_id', Auth::user()->prodi_id)
                ->get();
            }
            // dd($query);

            foreach ($query as $user) {
                $action_edit = '<center>
                <a href="#" class="btn btn-success btn-sm m-btn  m-btn m-btn--icon"
                data-toggle="modal"
                data-id= "'. $user->id.'"
                data-target="#modal-edit" id="btn_update_surat">
                <span>
                    <i class="la la-edit"></i>
                    <span>Ubah</span>
                </span>
                </a>';


                $roless = "";

                $update = date('d-m-Y, H:i', strtotime($user->created_at));
                $data = [];
                $data[] = $count++;
                $data[] = strtoupper($user->npm);
                $data[] = ($user->nama);
                $data[] = $user->prodi == null ? '-' : '<b>'.$user->prodi.'</b>';
                $data[] = ($user->tahun_lulus);
                $data[] = $update;
                // $data[] = $action_edit;
                $result[] = $data;
            }
            return response()->json(['result' => $result]);
        } catch (\Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 406);
        }
    }

    public function simpan(Request $request){

        DB::table('users')->insert([
                            'name'          => $request->name,
                            'username'      => $request->username,
                            'email'         => $request->email,
                            'prodi_id'    => $request->prodi_id,
                            'password'      => bcrypt($request->password),
                            'role_id'       => 2

                ]);
        // dd($query);
        return response()->json(['success'=>'User berhasil ditambahkan']);
    }

    public function update(Request $request)
    {
    try {
        DB::table('users')->where('id', $request->id)
                                  ->update([
                                        'name'          => $request->name,
                                        'username'      => $request->username,
                                        'email'         => $request->email,
                                        'prodi_id'      => $request->prodi_id,
                                        'password'      => bcrypt($request->password),

                                    ]);
        // dd($request->all());
        return response()->json(['status' => 'success', 'result' => 'User berhasil diubah'], 200);
    } catch (\Exception $exception) {
        return response()->json(['status' => 'error', 'message' => $exception->getMessage()], 406);
    }

    }

    public function destroy(Request $request)
    {
        try {
           DB::table('users')->where('id', '=', $request->id)->delete();

        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage()], 404);
        }
        return response()->json(['status' => 'success', 'result' => 'User berhasil dihapus'], 200);
    }

    public function AjaxDetail($id_user)
    {
        $users = \DB::table('users')
            ->Leftjoin('tm_kode_prodi', 'users.prodi_id', 'tm_kode_prodi.kode')
            ->select('users.id','users.username', 'users.name', 'users.email', 'users.password', 'users.prodi_id', 'tm_kode_prodi.kode', 'tm_kode_prodi.prodi')
            ->where('users.id', $id_user)
            ->first();
        // dd($users);
        // dd($suratmasuk);
        return response()->json(['status'=> 'success', 'result'=> $users], 200);

    }
}
